/*! For license information please see My QuickTable.js.LICENSE.txt */ ! function(e, t) {
    if ("object" == typeof exports && "object" == typeof module) module.exports = t(require("qlik"), require("require"));
    else if ("function" == typeof define && define.amd) define(["qlik", "require"], t);
    else {
        var n = "object" == typeof exports ? t(require("qlik"), require("require")) : t(e.qlik, e.require);
        for (var o in n)("object" == typeof exports ? exports : e)[o] = n[o]
    }
}(self, (function(e, t) {
    return function() {
        "use strict";
        var n = {
                479: function(e, t) {
                    t.A = (e, t) => {
                        const n = e.__vccOpts || e;
                        for (const [e, o] of t) n[e] = o;
                        return n
                    }
                },
                461: function(t) {
                    t.exports = e
                },
                883: function(e) {
                    e.exports = t
                }
            },
            o = {};

        function r(e) {
            var t = o[e];
            if (void 0 !== t) return t.exports;
            var i = o[e] = {
                exports: {}
            };
            return n[e](i, i.exports, r), i.exports
        }
        r.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return r.d(t, {
                a: t
            }), t
        }, r.d = function(e, t) {
            for (var n in t) r.o(t, n) && !r.o(e, n) && Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }, r.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" == typeof window) return window
            }
        }(), r.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, r.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        };
        var i = {};
        r.r(i), r.d(i, {
            default: function() {
                return hx
            }
        });
        var l = r(883),
            a = r.n(l),
            s = {
                type: "items",
                component: "accordion",
                items: {
                    about: {
                        component: "items",
                        label: "About",
                        items: {
                            name: {
                                component: "text",
                                label: "My QuickTable"
                            },
                            version: {
                                component: "text",
                                label: "v1.3.0"
                            },
                            wiki: {
                                component: "icon-button",
                                iconClass: "lui-icon--insert",
                                title: "Wiki",
                                action: function() {
                                    window.open("#", "_blank").focus()
                                }
                            }
                        }
                    }
                }
            };

        function c(e, t) {
            const n = new Set(e.split(","));
            return t ? e => n.has(e.toLowerCase()) : e => n.has(e)
        }
        const u = {},
            d = [],
            f = () => {},
            p = () => !1,
            h = e => 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97),
            v = e => e.startsWith("onUpdate:"),
            g = Object.assign,
            b = (e, t) => {
                const n = e.indexOf(t);
                n > -1 && e.splice(n, 1)
            },
            m = Object.prototype.hasOwnProperty,
            y = (e, t) => m.call(e, t),
            x = Array.isArray,
            w = e => "[object Map]" === P(e),
            C = e => "[object Set]" === P(e),
            S = e => "function" == typeof e,
            k = e => "string" == typeof e,
            $ = e => "symbol" == typeof e,
            _ = e => null !== e && "object" == typeof e,
            z = e => (_(e) || S(e)) && S(e.then) && S(e.catch),
            T = Object.prototype.toString,
            P = e => T.call(e),
            F = e => P(e).slice(8, -1),
            M = e => "[object Object]" === P(e),
            R = e => k(e) && "NaN" !== e && "-" !== e[0] && "" + parseInt(e, 10) === e,
            E = c(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
            O = e => {
                const t = Object.create(null);
                return n => t[n] || (t[n] = e(n))
            },
            B = /-(\w)/g,
            A = O((e => e.replace(B, ((e, t) => t ? t.toUpperCase() : "")))),
            I = /\B([A-Z])/g,
            D = O((e => e.replace(I, "-$1").toLowerCase())),
            L = O((e => e.charAt(0).toUpperCase() + e.slice(1))),
            j = O((e => e ? `on${L(e)}` : "")),
            N = (e, t) => !Object.is(e, t),
            H = (e, ...t) => {
                for (let n = 0; n < e.length; n++) e[n](...t)
            },
            W = (e, t, n, o = !1) => {
                Object.defineProperty(e, t, {
                    configurable: !0,
                    enumerable: !1,
                    writable: o,
                    value: n
                })
            },
            V = e => {
                const t = parseFloat(e);
                return isNaN(t) ? e : t
            },
            q = e => {
                const t = k(e) ? Number(e) : NaN;
                return isNaN(t) ? e : t
            };
        let U;
        const K = () => U || (U = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : void 0 !== r.g ? r.g : {});

        function G(e) {
            if (x(e)) {
                const t = {};
                for (let n = 0; n < e.length; n++) {
                    const o = e[n],
                        r = k(o) ? J(o) : G(o);
                    if (r)
                        for (const e in r) t[e] = r[e]
                }
                return t
            }
            if (k(e) || _(e)) return e
        }
        const X = /;(?![^(]*\))/g,
            Y = /:([^]+)/,
            Z = /\/\*[^]*?\*\//g;

        function J(e) {
            const t = {};
            return e.replace(Z, "").split(X).forEach((e => {
                if (e) {
                    const n = e.split(Y);
                    n.length > 1 && (t[n[0].trim()] = n[1].trim())
                }
            })), t
        }

        function Q(e) {
            let t = "";
            if (k(e)) t = e;
            else if (x(e))
                for (let n = 0; n < e.length; n++) {
                    const o = Q(e[n]);
                    o && (t += o + " ")
                } else if (_(e))
                    for (const n in e) e[n] && (t += n + " ");
            return t.trim()
        }
        const ee = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",
            te = c(ee);

        function ne(e) {
            return !!e || "" === e
        }
        const oe = e => !(!e || !0 !== e.__v_isRef),
            re = e => k(e) ? e : null == e ? "" : x(e) || _(e) && (e.toString === T || !S(e.toString)) ? oe(e) ? re(e.value) : JSON.stringify(e, ie, 2) : String(e),
            ie = (e, t) => oe(t) ? ie(e, t.value) : w(t) ? {
                [`Map(${t.size})`]: [...t.entries()].reduce(((e, [t, n], o) => (e[le(t, o) + " =>"] = n, e)), {})
            } : C(t) ? {
                [`Set(${t.size})`]: [...t.values()].map((e => le(e)))
            } : $(t) ? le(t) : !_(t) || x(t) || M(t) ? t : String(t),
            le = (e, t = "") => {
                var n;
                return $(e) ? `Symbol(${null!=(n=e.description)?n:t})` : e
            };
        let ae, se;
        class ce {
            constructor(e = !1) {
                this.detached = e, this._active = !0, this.effects = [], this.cleanups = [], this.parent = ae, !e && ae && (this.index = (ae.scopes || (ae.scopes = [])).push(this) - 1)
            }
            get active() {
                return this._active
            }
            run(e) {
                if (this._active) {
                    const t = ae;
                    try {
                        return ae = this, e()
                    } finally {
                        ae = t
                    }
                } else 0
            }
            on() {
                ae = this
            }
            off() {
                ae = this.parent
            }
            stop(e) {
                if (this._active) {
                    let t, n;
                    for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
                    for (t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
                    if (this.scopes)
                        for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].stop(!0);
                    if (!this.detached && this.parent && !e) {
                        const e = this.parent.scopes.pop();
                        e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index)
                    }
                    this.parent = void 0, this._active = !1
                }
            }
        }

        function ue(e, t = ae) {
            t && t.active && t.effects.push(e)
        }
        class de {
            constructor(e, t, n, o) {
                this.fn = e, this.trigger = t, this.scheduler = n, this.active = !0, this.deps = [], this._dirtyLevel = 4, this._trackId = 0, this._runnings = 0, this._shouldSchedule = !1, this._depsLength = 0, ue(this, o)
            }
            get dirty() {
                if (2 === this._dirtyLevel || 3 === this._dirtyLevel) {
                    this._dirtyLevel = 1, ye();
                    for (let e = 0; e < this._depsLength; e++) {
                        const t = this.deps[e];
                        if (t.computed && (fe(t.computed), this._dirtyLevel >= 4)) break
                    }
                    1 === this._dirtyLevel && (this._dirtyLevel = 0), xe()
                }
                return this._dirtyLevel >= 4
            }
            set dirty(e) {
                this._dirtyLevel = e ? 4 : 0
            }
            run() {
                if (this._dirtyLevel = 0, !this.active) return this.fn();
                let e = ge,
                    t = se;
                try {
                    return ge = !0, se = this, this._runnings++, pe(this), this.fn()
                } finally {
                    he(this), this._runnings--, se = t, ge = e
                }
            }
            stop() {
                this.active && (pe(this), he(this), this.onStop && this.onStop(), this.active = !1)
            }
        }

        function fe(e) {
            return e.value
        }

        function pe(e) {
            e._trackId++, e._depsLength = 0
        }

        function he(e) {
            if (e.deps.length > e._depsLength) {
                for (let t = e._depsLength; t < e.deps.length; t++) ve(e.deps[t], e);
                e.deps.length = e._depsLength
            }
        }

        function ve(e, t) {
            const n = e.get(t);
            void 0 !== n && t._trackId !== n && (e.delete(t), 0 === e.size && e.cleanup())
        }
        let ge = !0,
            be = 0;
        const me = [];

        function ye() {
            me.push(ge), ge = !1
        }

        function xe() {
            const e = me.pop();
            ge = void 0 === e || e
        }

        function we() {
            be++
        }

        function Ce() {
            for (be--; !be && ke.length;) ke.shift()()
        }

        function Se(e, t, n) {
            if (t.get(e) !== e._trackId) {
                t.set(e, e._trackId);
                const n = e.deps[e._depsLength];
                n !== t ? (n && ve(n, e), e.deps[e._depsLength++] = t) : e._depsLength++
            }
        }
        const ke = [];

        function $e(e, t, n) {
            we();
            for (const n of e.keys()) {
                let o;
                n._dirtyLevel < t && (null != o ? o : o = e.get(n) === n._trackId) && (n._shouldSchedule || (n._shouldSchedule = 0 === n._dirtyLevel), n._dirtyLevel = t), n._shouldSchedule && (null != o ? o : o = e.get(n) === n._trackId) && (n.trigger(), n._runnings && !n.allowRecurse || 2 === n._dirtyLevel || (n._shouldSchedule = !1, n.scheduler && ke.push(n.scheduler)))
            }
            Ce()
        }
        const _e = (e, t) => {
                const n = new Map;
                return n.cleanup = e, n.computed = t, n
            },
            ze = new WeakMap,
            Te = Symbol(""),
            Pe = Symbol("");

        function Fe(e, t, n) {
            if (ge && se) {
                let t = ze.get(e);
                t || ze.set(e, t = new Map);
                let o = t.get(n);
                o || t.set(n, o = _e((() => t.delete(n)))), Se(se, o)
            }
        }

        function Me(e, t, n, o, r, i) {
            const l = ze.get(e);
            if (!l) return;
            let a = [];
            if ("clear" === t) a = [...l.values()];
            else if ("length" === n && x(e)) {
                const e = Number(o);
                l.forEach(((t, n) => {
                    ("length" === n || !$(n) && n >= e) && a.push(t)
                }))
            } else switch (void 0 !== n && a.push(l.get(n)), t) {
                case "add":
                    x(e) ? R(n) && a.push(l.get("length")) : (a.push(l.get(Te)), w(e) && a.push(l.get(Pe)));
                    break;
                case "delete":
                    x(e) || (a.push(l.get(Te)), w(e) && a.push(l.get(Pe)));
                    break;
                case "set":
                    w(e) && a.push(l.get(Te))
            }
            we();
            for (const e of a) e && $e(e, 4);
            Ce()
        }
        const Re = c("__proto__,__v_isRef,__isVue"),
            Ee = new Set(Object.getOwnPropertyNames(Symbol).filter((e => "arguments" !== e && "caller" !== e)).map((e => Symbol[e])).filter($)),
            Oe = Be();

        function Be() {
            const e = {};
            return ["includes", "indexOf", "lastIndexOf"].forEach((t => {
                e[t] = function(...e) {
                    const n = wt(this);
                    for (let e = 0, t = this.length; e < t; e++) Fe(n, 0, e + "");
                    const o = n[t](...e);
                    return -1 === o || !1 === o ? n[t](...e.map(wt)) : o
                }
            })), ["push", "pop", "shift", "unshift", "splice"].forEach((t => {
                e[t] = function(...e) {
                    ye(), we();
                    const n = wt(this)[t].apply(this, e);
                    return Ce(), xe(), n
                }
            })), e
        }

        function Ae(e) {
            $(e) || (e = String(e));
            const t = wt(this);
            return Fe(t, 0, e), t.hasOwnProperty(e)
        }
        class Ie {
            constructor(e = !1, t = !1) {
                this._isReadonly = e, this._isShallow = t
            }
            get(e, t, n) {
                const o = this._isReadonly,
                    r = this._isShallow;
                if ("__v_isReactive" === t) return !o;
                if ("__v_isReadonly" === t) return o;
                if ("__v_isShallow" === t) return r;
                if ("__v_raw" === t) return n === (o ? r ? pt : ft : r ? dt : ut).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
                const i = x(e);
                if (!o) {
                    if (i && y(Oe, t)) return Reflect.get(Oe, t, n);
                    if ("hasOwnProperty" === t) return Ae
                }
                const l = Reflect.get(e, t, n);
                return ($(t) ? Ee.has(t) : Re(t)) ? l : (o || Fe(e, 0, t), r ? l : Pt(l) ? i && R(t) ? l : l.value : _(l) ? o ? vt(l) : ht(l) : l)
            }
        }
        class De extends Ie {
            constructor(e = !1) {
                super(!1, e)
            }
            set(e, t, n, o) {
                let r = e[t];
                if (!this._isShallow) {
                    const t = mt(r);
                    if (yt(n) || mt(n) || (r = wt(r), n = wt(n)), !x(e) && Pt(r) && !Pt(n)) return !t && (r.value = n, !0)
                }
                const i = x(e) && R(t) ? Number(t) < e.length : y(e, t),
                    l = Reflect.set(e, t, n, o);
                return e === wt(o) && (i ? N(n, r) && Me(e, "set", t, n) : Me(e, "add", t, n)), l
            }
            deleteProperty(e, t) {
                const n = y(e, t),
                    o = (e[t], Reflect.deleteProperty(e, t));
                return o && n && Me(e, "delete", t, void 0), o
            }
            has(e, t) {
                const n = Reflect.has(e, t);
                return $(t) && Ee.has(t) || Fe(e, 0, t), n
            }
            ownKeys(e) {
                return Fe(e, 0, x(e) ? "length" : Te), Reflect.ownKeys(e)
            }
        }
        class Le extends Ie {
            constructor(e = !1) {
                super(!0, e)
            }
            set(e, t) {
                return !0
            }
            deleteProperty(e, t) {
                return !0
            }
        }
        const je = new De,
            Ne = new Le,
            He = new De(!0),
            We = e => e,
            Ve = e => Reflect.getPrototypeOf(e);

        function qe(e, t, n = !1, o = !1) {
            const r = wt(e = e.__v_raw),
                i = wt(t);
            n || (N(t, i) && Fe(r, 0, t), Fe(r, 0, i));
            const {
                has: l
            } = Ve(r), a = o ? We : n ? kt : St;
            return l.call(r, t) ? a(e.get(t)) : l.call(r, i) ? a(e.get(i)) : void(e !== r && e.get(t))
        }

        function Ue(e, t = !1) {
            const n = this.__v_raw,
                o = wt(n),
                r = wt(e);
            return t || (N(e, r) && Fe(o, 0, e), Fe(o, 0, r)), e === r ? n.has(e) : n.has(e) || n.has(r)
        }

        function Ke(e, t = !1) {
            return e = e.__v_raw, !t && Fe(wt(e), 0, Te), Reflect.get(e, "size", e)
        }

        function Ge(e, t = !1) {
            t || yt(e) || mt(e) || (e = wt(e));
            const n = wt(this);
            return Ve(n).has.call(n, e) || (n.add(e), Me(n, "add", e, e)), this
        }

        function Xe(e, t, n = !1) {
            n || yt(t) || mt(t) || (t = wt(t));
            const o = wt(this),
                {
                    has: r,
                    get: i
                } = Ve(o);
            let l = r.call(o, e);
            l || (e = wt(e), l = r.call(o, e));
            const a = i.call(o, e);
            return o.set(e, t), l ? N(t, a) && Me(o, "set", e, t) : Me(o, "add", e, t), this
        }

        function Ye(e) {
            const t = wt(this),
                {
                    has: n,
                    get: o
                } = Ve(t);
            let r = n.call(t, e);
            r || (e = wt(e), r = n.call(t, e));
            o && o.call(t, e);
            const i = t.delete(e);
            return r && Me(t, "delete", e, void 0), i
        }

        function Ze() {
            const e = wt(this),
                t = 0 !== e.size,
                n = e.clear();
            return t && Me(e, "clear", void 0, void 0), n
        }

        function Je(e, t) {
            return function(n, o) {
                const r = this,
                    i = r.__v_raw,
                    l = wt(i),
                    a = t ? We : e ? kt : St;
                return !e && Fe(l, 0, Te), i.forEach(((e, t) => n.call(o, a(e), a(t), r)))
            }
        }

        function Qe(e, t, n) {
            return function(...o) {
                const r = this.__v_raw,
                    i = wt(r),
                    l = w(i),
                    a = "entries" === e || e === Symbol.iterator && l,
                    s = "keys" === e && l,
                    c = r[e](...o),
                    u = n ? We : t ? kt : St;
                return !t && Fe(i, 0, s ? Pe : Te), {
                    next() {
                        const {
                            value: e,
                            done: t
                        } = c.next();
                        return t ? {
                            value: e,
                            done: t
                        } : {
                            value: a ? [u(e[0]), u(e[1])] : u(e),
                            done: t
                        }
                    },
                    [Symbol.iterator]() {
                        return this
                    }
                }
            }
        }

        function et(e) {
            return function(...t) {
                return "delete" !== e && ("clear" === e ? void 0 : this)
            }
        }

        function tt() {
            const e = {
                    get(e) {
                        return qe(this, e)
                    },
                    get size() {
                        return Ke(this)
                    },
                    has: Ue,
                    add: Ge,
                    set: Xe,
                    delete: Ye,
                    clear: Ze,
                    forEach: Je(!1, !1)
                },
                t = {
                    get(e) {
                        return qe(this, e, !1, !0)
                    },
                    get size() {
                        return Ke(this)
                    },
                    has: Ue,
                    add(e) {
                        return Ge.call(this, e, !0)
                    },
                    set(e, t) {
                        return Xe.call(this, e, t, !0)
                    },
                    delete: Ye,
                    clear: Ze,
                    forEach: Je(!1, !0)
                },
                n = {
                    get(e) {
                        return qe(this, e, !0)
                    },
                    get size() {
                        return Ke(this, !0)
                    },
                    has(e) {
                        return Ue.call(this, e, !0)
                    },
                    add: et("add"),
                    set: et("set"),
                    delete: et("delete"),
                    clear: et("clear"),
                    forEach: Je(!0, !1)
                },
                o = {
                    get(e) {
                        return qe(this, e, !0, !0)
                    },
                    get size() {
                        return Ke(this, !0)
                    },
                    has(e) {
                        return Ue.call(this, e, !0)
                    },
                    add: et("add"),
                    set: et("set"),
                    delete: et("delete"),
                    clear: et("clear"),
                    forEach: Je(!0, !0)
                };
            return ["keys", "values", "entries", Symbol.iterator].forEach((r => {
                e[r] = Qe(r, !1, !1), n[r] = Qe(r, !0, !1), t[r] = Qe(r, !1, !0), o[r] = Qe(r, !0, !0)
            })), [e, n, t, o]
        }
        const [nt, ot, rt, it] = tt();

        function lt(e, t) {
            const n = t ? e ? it : rt : e ? ot : nt;
            return (t, o, r) => "__v_isReactive" === o ? !e : "__v_isReadonly" === o ? e : "__v_raw" === o ? t : Reflect.get(y(n, o) && o in t ? n : t, o, r)
        }
        const at = {
                get: lt(!1, !1)
            },
            st = {
                get: lt(!1, !0)
            },
            ct = {
                get: lt(!0, !1)
            };
        const ut = new WeakMap,
            dt = new WeakMap,
            ft = new WeakMap,
            pt = new WeakMap;

        function ht(e) {
            return mt(e) ? e : gt(e, !1, je, at, ut)
        }

        function vt(e) {
            return gt(e, !0, Ne, ct, ft)
        }

        function gt(e, t, n, o, r) {
            if (!_(e)) return e;
            if (e.__v_raw && (!t || !e.__v_isReactive)) return e;
            const i = r.get(e);
            if (i) return i;
            const l = (a = e).__v_skip || !Object.isExtensible(a) ? 0 : function(e) {
                switch (e) {
                    case "Object":
                    case "Array":
                        return 1;
                    case "Map":
                    case "Set":
                    case "WeakMap":
                    case "WeakSet":
                        return 2;
                    default:
                        return 0
                }
            }(F(a));
            var a;
            if (0 === l) return e;
            const s = new Proxy(e, 2 === l ? o : n);
            return r.set(e, s), s
        }

        function bt(e) {
            return mt(e) ? bt(e.__v_raw) : !(!e || !e.__v_isReactive)
        }

        function mt(e) {
            return !(!e || !e.__v_isReadonly)
        }

        function yt(e) {
            return !(!e || !e.__v_isShallow)
        }

        function xt(e) {
            return !!e && !!e.__v_raw
        }

        function wt(e) {
            const t = e && e.__v_raw;
            return t ? wt(t) : e
        }

        function Ct(e) {
            return Object.isExtensible(e) && W(e, "__v_skip", !0), e
        }
        const St = e => _(e) ? ht(e) : e,
            kt = e => _(e) ? vt(e) : e;
        class $t {
            constructor(e, t, n, o) {
                this.getter = e, this._setter = t, this.dep = void 0, this.__v_isRef = !0, this.__v_isReadonly = !1, this.effect = new de((() => e(this._value)), (() => Tt(this, 2 === this.effect._dirtyLevel ? 2 : 3))), this.effect.computed = this, this.effect.active = this._cacheable = !o, this.__v_isReadonly = n
            }
            get value() {
                const e = wt(this);
                return e._cacheable && !e.effect.dirty || !N(e._value, e._value = e.effect.run()) || Tt(e, 4), zt(e), e.effect._dirtyLevel >= 2 && Tt(e, 2), e._value
            }
            set value(e) {
                this._setter(e)
            }
            get _dirty() {
                return this.effect.dirty
            }
            set _dirty(e) {
                this.effect.dirty = e
            }
        }

        function _t(e, t, n = !1) {
            let o, r;
            const i = S(e);
            i ? (o = e, r = f) : (o = e.get, r = e.set);
            return new $t(o, r, i || !r, n)
        }

        function zt(e) {
            var t;
            ge && se && (e = wt(e), Se(se, null != (t = e.dep) ? t : e.dep = _e((() => e.dep = void 0), e instanceof $t ? e : void 0)))
        }

        function Tt(e, t = 4, n, o) {
            const r = (e = wt(e)).dep;
            r && $e(r, t)
        }

        function Pt(e) {
            return !(!e || !0 !== e.__v_isRef)
        }

        function Ft(e) {
            return Mt(e, !1)
        }

        function Mt(e, t) {
            return Pt(e) ? e : new Rt(e, t)
        }
        class Rt {
            constructor(e, t) {
                this.__v_isShallow = t, this.dep = void 0, this.__v_isRef = !0, this._rawValue = t ? e : wt(e), this._value = t ? e : St(e)
            }
            get value() {
                return zt(this), this._value
            }
            set value(e) {
                const t = this.__v_isShallow || yt(e) || mt(e);
                if (e = t ? e : wt(e), N(e, this._rawValue)) {
                    this._rawValue;
                    this._rawValue = e, this._value = t ? e : St(e), Tt(this, 4)
                }
            }
        }

        function Et(e) {
            return Pt(e) ? e.value : e
        }
        const Ot = {
            get: (e, t, n) => Et(Reflect.get(e, t, n)),
            set: (e, t, n, o) => {
                const r = e[t];
                return Pt(r) && !Pt(n) ? (r.value = n, !0) : Reflect.set(e, t, n, o)
            }
        };

        function Bt(e) {
            return bt(e) ? e : new Proxy(e, Ot)
        }
        class At {
            constructor(e, t, n) {
                this._object = e, this._key = t, this._defaultValue = n, this.__v_isRef = !0
            }
            get value() {
                const e = this._object[this._key];
                return void 0 === e ? this._defaultValue : e
            }
            set value(e) {
                this._object[this._key] = e
            }
            get dep() {
                return function(e, t) {
                    const n = ze.get(e);
                    return n && n.get(t)
                }(wt(this._object), this._key)
            }
        }
        class It {
            constructor(e) {
                this._getter = e, this.__v_isRef = !0, this.__v_isReadonly = !0
            }
            get value() {
                return this._getter()
            }
        }

        function Dt(e, t, n) {
            return Pt(e) ? e : S(e) ? new It(e) : _(e) && arguments.length > 1 ? Lt(e, t, n) : Ft(e)
        }

        function Lt(e, t, n) {
            const o = e[t];
            return Pt(o) ? o : new At(e, t, n)
        }

        function jt(e, t, n, o) {
            try {
                return o ? e(...o) : e()
            } catch (e) {
                Ht(e, t, n)
            }
        }

        function Nt(e, t, n, o) {
            if (S(e)) {
                const r = jt(e, t, n, o);
                return r && z(r) && r.catch((e => {
                    Ht(e, t, n)
                })), r
            }
            if (x(e)) {
                const r = [];
                for (let i = 0; i < e.length; i++) r.push(Nt(e[i], t, n, o));
                return r
            }
        }

        function Ht(e, t, n, o = !0) {
            t && t.vnode;
            if (t) {
                let o = t.parent;
                const r = t.proxy,
                    i = `https://vuejs.org/error-reference/#runtime-${n}`;
                for (; o;) {
                    const t = o.ec;
                    if (t)
                        for (let n = 0; n < t.length; n++)
                            if (!1 === t[n](e, r, i)) return;
                    o = o.parent
                }
                const l = t.appContext.config.errorHandler;
                if (l) return ye(), jt(l, null, 10, [e, r, i]), void xe()
            }
        }
        let Wt = !1,
            Vt = !1;
        const qt = [];
        let Ut = 0;
        const Kt = [];
        let Gt = null,
            Xt = 0;
        const Yt = Promise.resolve();
        let Zt = null;

        function Jt(e) {
            const t = Zt || Yt;
            return e ? t.then(this ? e.bind(this) : e) : t
        }

        function Qt(e) {
            qt.length && qt.includes(e, Wt && e.allowRecurse ? Ut + 1 : Ut) || (null == e.id ? qt.push(e) : qt.splice(function(e) {
                let t = Ut + 1,
                    n = qt.length;
                for (; t < n;) {
                    const o = t + n >>> 1,
                        r = qt[o],
                        i = rn(r);
                    i < e || i === e && r.pre ? t = o + 1 : n = o
                }
                return t
            }(e.id), 0, e), en())
        }

        function en() {
            Wt || Vt || (Vt = !0, Zt = Yt.then(an))
        }

        function tn(e) {
            x(e) ? Kt.push(...e) : Gt && Gt.includes(e, e.allowRecurse ? Xt + 1 : Xt) || Kt.push(e), en()
        }

        function nn(e, t, n = (Wt ? Ut + 1 : 0)) {
            for (0; n < qt.length; n++) {
                const t = qt[n];
                if (t && t.pre) {
                    if (e && t.id !== e.uid) continue;
                    0, qt.splice(n, 1), n--, t()
                }
            }
        }

        function on(e) {
            if (Kt.length) {
                const e = [...new Set(Kt)].sort(((e, t) => rn(e) - rn(t)));
                if (Kt.length = 0, Gt) return void Gt.push(...e);
                for (Gt = e, Xt = 0; Xt < Gt.length; Xt++) {
                    const e = Gt[Xt];
                    0, !1 !== e.active && e()
                }
                Gt = null, Xt = 0
            }
        }
        const rn = e => null == e.id ? 1 / 0 : e.id,
            ln = (e, t) => {
                const n = rn(e) - rn(t);
                if (0 === n) {
                    if (e.pre && !t.pre) return -1;
                    if (t.pre && !e.pre) return 1
                }
                return n
            };

        function an(e) {
            Vt = !1, Wt = !0, qt.sort(ln);
            try {
                for (Ut = 0; Ut < qt.length; Ut++) {
                    const e = qt[Ut];
                    e && !1 !== e.active && jt(e, e.i, e.i ? 15 : 14)
                }
            } finally {
                Ut = 0, qt.length = 0, on(), Wt = !1, Zt = null, (qt.length || Kt.length) && an(e)
            }
        }
        let sn = null,
            cn = null;

        function un(e) {
            const t = sn;
            return sn = e, cn = e && e.type.__scopeId || null, t
        }

        function dn(e, t = sn, n) {
            if (!t) return e;
            if (e._n) return e;
            const o = (...n) => {
                o._d && jr(-1);
                const r = un(t);
                let i;
                try {
                    i = e(...n)
                } finally {
                    un(r), o._d && jr(1)
                }
                return i
            };
            return o._n = !0, o._c = !0, o._d = !0, o
        }

        function fn(e, t) {
            if (null === sn) return e;
            const n = ki(sn),
                o = e.dirs || (e.dirs = []);
            for (let e = 0; e < t.length; e++) {
                let [r, i, l, a = u] = t[e];
                r && (S(r) && (r = {
                    mounted: r,
                    updated: r
                }), r.deep && yr(i), o.push({
                    dir: r,
                    instance: n,
                    value: i,
                    oldValue: void 0,
                    arg: l,
                    modifiers: a
                }))
            }
            return e
        }

        function pn(e, t, n, o) {
            const r = e.dirs,
                i = t && t.dirs;
            for (let l = 0; l < r.length; l++) {
                const a = r[l];
                i && (a.oldValue = i[l].value);
                let s = a.dir[o];
                s && (ye(), Nt(s, n, 8, [e.el, a, e, t]), xe())
            }
        }
        const hn = Symbol("_leaveCb"),
            vn = Symbol("_enterCb");

        function gn() {
            const e = {
                isMounted: !1,
                isLeaving: !1,
                isUnmounting: !1,
                leavingVNodes: new Map
            };
            return Nn((() => {
                e.isMounted = !0
            })), Vn((() => {
                e.isUnmounting = !0
            })), e
        }
        const bn = [Function, Array],
            mn = {
                mode: String,
                appear: Boolean,
                persisted: Boolean,
                onBeforeEnter: bn,
                onEnter: bn,
                onAfterEnter: bn,
                onEnterCancelled: bn,
                onBeforeLeave: bn,
                onLeave: bn,
                onAfterLeave: bn,
                onLeaveCancelled: bn,
                onBeforeAppear: bn,
                onAppear: bn,
                onAfterAppear: bn,
                onAppearCancelled: bn
            },
            yn = e => {
                const t = e.subTree;
                return t.component ? yn(t.component) : t
            },
            xn = {
                name: "BaseTransition",
                props: mn,
                setup(e, {
                    slots: t
                }) {
                    const n = ui(),
                        o = gn();
                    return () => {
                        const r = t.default && zn(t.default(), !0);
                        if (!r || !r.length) return;
                        let i = r[0];
                        if (r.length > 1) {
                            let e = !1;
                            for (const t of r)
                                if (t.type !== Er) {
                                    0,
                                    i = t,
                                    e = !0;
                                    break
                                }
                        }
                        const l = wt(e),
                            {
                                mode: a
                            } = l;
                        if (o.isLeaving) return kn(i);
                        const s = $n(i);
                        if (!s) return kn(i);
                        let c = Sn(s, l, o, n, (e => c = e));
                        _n(s, c);
                        const u = n.subTree,
                            d = u && $n(u);
                        if (d && d.type !== Er && !qr(s, d) && yn(n).type !== Er) {
                            const e = Sn(d, l, o, n);
                            if (_n(d, e), "out-in" === a && s.type !== Er) return o.isLeaving = !0, e.afterLeave = () => {
                                o.isLeaving = !1, !1 !== n.update.active && (n.effect.dirty = !0, n.update())
                            }, kn(i);
                            "in-out" === a && s.type !== Er && (e.delayLeave = (e, t, n) => {
                                Cn(o, d)[String(d.key)] = d, e[hn] = () => {
                                    t(), e[hn] = void 0, delete c.delayedLeave
                                }, c.delayedLeave = n
                            })
                        }
                        return i
                    }
                }
            },
            wn = xn;

        function Cn(e, t) {
            const {
                leavingVNodes: n
            } = e;
            let o = n.get(t.type);
            return o || (o = Object.create(null), n.set(t.type, o)), o
        }

        function Sn(e, t, n, o, r) {
            const {
                appear: i,
                mode: l,
                persisted: a = !1,
                onBeforeEnter: s,
                onEnter: c,
                onAfterEnter: u,
                onEnterCancelled: d,
                onBeforeLeave: f,
                onLeave: p,
                onAfterLeave: h,
                onLeaveCancelled: v,
                onBeforeAppear: g,
                onAppear: b,
                onAfterAppear: m,
                onAppearCancelled: y
            } = t, w = String(e.key), C = Cn(n, e), S = (e, t) => {
                e && Nt(e, o, 9, t)
            }, k = (e, t) => {
                const n = t[1];
                S(e, t), x(e) ? e.every((e => e.length <= 1)) && n() : e.length <= 1 && n()
            }, $ = {
                mode: l,
                persisted: a,
                beforeEnter(t) {
                    let o = s;
                    if (!n.isMounted) {
                        if (!i) return;
                        o = g || s
                    }
                    t[hn] && t[hn](!0);
                    const r = C[w];
                    r && qr(e, r) && r.el[hn] && r.el[hn](), S(o, [t])
                },
                enter(e) {
                    let t = c,
                        o = u,
                        r = d;
                    if (!n.isMounted) {
                        if (!i) return;
                        t = b || c, o = m || u, r = y || d
                    }
                    let l = !1;
                    const a = e[vn] = t => {
                        l || (l = !0, S(t ? r : o, [e]), $.delayedLeave && $.delayedLeave(), e[vn] = void 0)
                    };
                    t ? k(t, [e, a]) : a()
                },
                leave(t, o) {
                    const r = String(e.key);
                    if (t[vn] && t[vn](!0), n.isUnmounting) return o();
                    S(f, [t]);
                    let i = !1;
                    const l = t[hn] = n => {
                        i || (i = !0, o(), S(n ? v : h, [t]), t[hn] = void 0, C[r] === e && delete C[r])
                    };
                    C[r] = e, p ? k(p, [t, l]) : l()
                },
                clone(e) {
                    const i = Sn(e, t, n, o, r);
                    return r && r(i), i
                }
            };
            return $
        }

        function kn(e) {
            if (Fn(e)) return (e = Jr(e)).children = null, e
        }

        function $n(e) {
            if (!Fn(e)) return e;
            const {
                shapeFlag: t,
                children: n
            } = e;
            if (n) {
                if (16 & t) return n[0];
                if (32 & t && S(n.default)) return n.default()
            }
        }

        function _n(e, t) {
            6 & e.shapeFlag && e.component ? _n(e.component.subTree, t) : 128 & e.shapeFlag ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
        }

        function zn(e, t = !1, n) {
            let o = [],
                r = 0;
            for (let i = 0; i < e.length; i++) {
                let l = e[i];
                const a = null == n ? l.key : String(n) + String(null != l.key ? l.key : i);
                l.type === Mr ? (128 & l.patchFlag && r++, o = o.concat(zn(l.children, t, a))) : (t || l.type !== Er) && o.push(null != a ? Jr(l, {
                    key: a
                }) : l)
            }
            if (r > 1)
                for (let e = 0; e < o.length; e++) o[e].patchFlag = -2;
            return o
        }

        function Tn(e, t) {
            return S(e) ? (() => g({
                name: e.name
            }, t, {
                setup: e
            }))() : e
        }
        const Pn = e => !!e.type.__asyncLoader;
        const Fn = e => e.type.__isKeepAlive;
        RegExp, RegExp;

        function Mn(e, t) {
            return x(e) ? e.some((e => Mn(e, t))) : k(e) ? e.split(",").includes(t) : "[object RegExp]" === P(e) && e.test(t)
        }

        function Rn(e, t) {
            On(e, "a", t)
        }

        function En(e, t) {
            On(e, "da", t)
        }

        function On(e, t, n = ci) {
            const o = e.__wdc || (e.__wdc = () => {
                let t = n;
                for (; t;) {
                    if (t.isDeactivated) return;
                    t = t.parent
                }
                return e()
            });
            if (Dn(t, o, n), n) {
                let e = n.parent;
                for (; e && e.parent;) Fn(e.parent.vnode) && Bn(o, t, n, e), e = e.parent
            }
        }

        function Bn(e, t, n, o) {
            const r = Dn(t, e, o, !0);
            qn((() => {
                b(o[t], r)
            }), n)
        }

        function An(e) {
            e.shapeFlag &= -257, e.shapeFlag &= -513
        }

        function In(e) {
            return 128 & e.shapeFlag ? e.ssContent : e
        }

        function Dn(e, t, n = ci, o = !1) {
            if (n) {
                const r = n[e] || (n[e] = []),
                    i = t.__weh || (t.__weh = (...o) => {
                        ye();
                        const r = pi(n),
                            i = Nt(t, n, e, o);
                        return r(), xe(), i
                    });
                return o ? r.unshift(i) : r.push(i), i
            }
        }
        const Ln = e => (t, n = ci) => {
                mi && "sp" !== e || Dn(e, ((...e) => t(...e)), n)
            },
            jn = Ln("bm"),
            Nn = Ln("m"),
            Hn = Ln("bu"),
            Wn = Ln("u"),
            Vn = Ln("bum"),
            qn = Ln("um"),
            Un = Ln("sp"),
            Kn = Ln("rtg"),
            Gn = Ln("rtc");

        function Xn(e, t = ci) {
            Dn("ec", e, t)
        }
        const Yn = "components";
        const Zn = Symbol.for("v-ndc");

        function Jn(e, t, n = !0, o = !1) {
            const r = sn || ci;
            if (r) {
                const n = r.type;
                if (e === Yn) {
                    const e = $i(n, !1);
                    if (e && (e === t || e === A(t) || e === L(A(t)))) return n
                }
                const i = Qn(r[e] || n[e], t) || Qn(r.appContext[e], t);
                return !i && o ? n : i
            }
        }

        function Qn(e, t) {
            return e && (e[t] || e[A(t)] || e[L(A(t))])
        }

        function eo(e, t, n, o) {
            let r;
            const i = n && n[o];
            if (x(e) || k(e)) {
                r = new Array(e.length);
                for (let n = 0, o = e.length; n < o; n++) r[n] = t(e[n], n, void 0, i && i[n])
            } else if ("number" == typeof e) {
                0,
                r = new Array(e);
                for (let n = 0; n < e; n++) r[n] = t(n + 1, n, void 0, i && i[n])
            }
            else if (_(e))
                if (e[Symbol.iterator]) r = Array.from(e, ((e, n) => t(e, n, void 0, i && i[n])));
                else {
                    const n = Object.keys(e);
                    r = new Array(n.length);
                    for (let o = 0, l = n.length; o < l; o++) {
                        const l = n[o];
                        r[o] = t(e[l], l, o, i && i[o])
                    }
                }
            else r = [];
            return n && (n[o] = r), r
        }

        function to(e, t, n = {}, o, r) {
            if (sn.isCE || sn.parent && Pn(sn.parent) && sn.parent.isCE) return "default" !== t && (n.name = t), Xr("slot", n, o && o());
            let i = e[t];
            i && i._c && (i._d = !1), Ir();
            const l = i && no(i(n)),
                a = Wr(Mr, {
                    key: (n.key || l && l.key || `_${t}`) + (!l && o ? "_fb" : "")
                }, l || (o ? o() : []), l && 1 === e._ ? 64 : -2);
            return !r && a.scopeId && (a.slotScopeIds = [a.scopeId + "-s"]), i && i._c && (i._d = !0), a
        }

        function no(e) {
            return e.some((e => !Vr(e) || e.type !== Er && !(e.type === Mr && !no(e.children)))) ? e : null
        }
        const oo = e => e ? vi(e) ? ki(e) : oo(e.parent) : null,
            ro = g(Object.create(null), {
                $: e => e,
                $el: e => e.vnode.el,
                $data: e => e.data,
                $props: e => e.props,
                $attrs: e => e.attrs,
                $slots: e => e.slots,
                $refs: e => e.refs,
                $parent: e => oo(e.parent),
                $root: e => oo(e.root),
                $emit: e => e.emit,
                $options: e => po(e),
                $forceUpdate: e => e.f || (e.f = () => {
                    e.effect.dirty = !0, Qt(e.update)
                }),
                $nextTick: e => e.n || (e.n = Jt.bind(e.proxy)),
                $watch: e => br.bind(e)
            }),
            io = (e, t) => e !== u && !e.__isScriptSetup && y(e, t),
            lo = {
                get({
                    _: e
                }, t) {
                    if ("__v_skip" === t) return !0;
                    const {
                        ctx: n,
                        setupState: o,
                        data: r,
                        props: i,
                        accessCache: l,
                        type: a,
                        appContext: s
                    } = e;
                    let c;
                    if ("$" !== t[0]) {
                        const a = l[t];
                        if (void 0 !== a) switch (a) {
                            case 1:
                                return o[t];
                            case 2:
                                return r[t];
                            case 4:
                                return n[t];
                            case 3:
                                return i[t]
                        } else {
                            if (io(o, t)) return l[t] = 1, o[t];
                            if (r !== u && y(r, t)) return l[t] = 2, r[t];
                            if ((c = e.propsOptions[0]) && y(c, t)) return l[t] = 3, i[t];
                            if (n !== u && y(n, t)) return l[t] = 4, n[t];
                            so && (l[t] = 0)
                        }
                    }
                    const d = ro[t];
                    let f, p;
                    return d ? ("$attrs" === t && Fe(e.attrs, 0, ""), d(e)) : (f = a.__cssModules) && (f = f[t]) ? f : n !== u && y(n, t) ? (l[t] = 4, n[t]) : (p = s.config.globalProperties, y(p, t) ? p[t] : void 0)
                },
                set({
                    _: e
                }, t, n) {
                    const {
                        data: o,
                        setupState: r,
                        ctx: i
                    } = e;
                    return io(r, t) ? (r[t] = n, !0) : o !== u && y(o, t) ? (o[t] = n, !0) : !y(e.props, t) && (("$" !== t[0] || !(t.slice(1) in e)) && (i[t] = n, !0))
                },
                has({
                    _: {
                        data: e,
                        setupState: t,
                        accessCache: n,
                        ctx: o,
                        appContext: r,
                        propsOptions: i
                    }
                }, l) {
                    let a;
                    return !!n[l] || e !== u && y(e, l) || io(t, l) || (a = i[0]) && y(a, l) || y(o, l) || y(ro, l) || y(r.config.globalProperties, l)
                },
                defineProperty(e, t, n) {
                    return null != n.get ? e._.accessCache[t] = 0 : y(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n)
                }
            };

        function ao(e) {
            return x(e) ? e.reduce(((e, t) => (e[t] = null, e)), {}) : e
        }
        let so = !0;

        function co(e) {
            const t = po(e),
                n = e.proxy,
                o = e.ctx;
            so = !1, t.beforeCreate && uo(t.beforeCreate, e, "bc");
            const {
                data: r,
                computed: i,
                methods: l,
                watch: a,
                provide: s,
                inject: c,
                created: u,
                beforeMount: d,
                mounted: p,
                beforeUpdate: h,
                updated: v,
                activated: g,
                deactivated: b,
                beforeDestroy: m,
                beforeUnmount: y,
                destroyed: w,
                unmounted: C,
                render: k,
                renderTracked: $,
                renderTriggered: z,
                errorCaptured: T,
                serverPrefetch: P,
                expose: F,
                inheritAttrs: M,
                components: R,
                directives: E,
                filters: O
            } = t;
            if (c && function(e, t) {
                    x(e) && (e = bo(e));
                    for (const n in e) {
                        const o = e[n];
                        let r;
                        r = _(o) ? "default" in o ? _o(o.from || n, o.default, !0) : _o(o.from || n) : _o(o), Pt(r) ? Object.defineProperty(t, n, {
                            enumerable: !0,
                            configurable: !0,
                            get: () => r.value,
                            set: e => r.value = e
                        }) : t[n] = r
                    }
                }(c, o, null), l)
                for (const e in l) {
                    const t = l[e];
                    S(t) && (o[e] = t.bind(n))
                }
            if (r) {
                0;
                const t = r.call(n, n);
                0, _(t) && (e.data = ht(t))
            }
            if (so = !0, i)
                for (const e in i) {
                    const t = i[e],
                        r = S(t) ? t.bind(n, n) : S(t.get) ? t.get.bind(n, n) : f;
                    0;
                    const l = !S(t) && S(t.set) ? t.set.bind(n) : f,
                        a = zi({
                            get: r,
                            set: l
                        });
                    Object.defineProperty(o, e, {
                        enumerable: !0,
                        configurable: !0,
                        get: () => a.value,
                        set: e => a.value = e
                    })
                }
            if (a)
                for (const e in a) fo(a[e], o, n, e);
            if (s) {
                const e = S(s) ? s.call(n) : s;
                Reflect.ownKeys(e).forEach((t => {
                    $o(t, e[t])
                }))
            }

            function B(e, t) {
                x(t) ? t.forEach((t => e(t.bind(n)))) : t && e(t.bind(n))
            }
            if (u && uo(u, e, "c"), B(jn, d), B(Nn, p), B(Hn, h), B(Wn, v), B(Rn, g), B(En, b), B(Xn, T), B(Gn, $), B(Kn, z), B(Vn, y), B(qn, C), B(Un, P), x(F))
                if (F.length) {
                    const t = e.exposed || (e.exposed = {});
                    F.forEach((e => {
                        Object.defineProperty(t, e, {
                            get: () => n[e],
                            set: t => n[e] = t
                        })
                    }))
                } else e.exposed || (e.exposed = {});
            k && e.render === f && (e.render = k), null != M && (e.inheritAttrs = M), R && (e.components = R), E && (e.directives = E)
        }

        function uo(e, t, n) {
            Nt(x(e) ? e.map((e => e.bind(t.proxy))) : e.bind(t.proxy), t, n)
        }

        function fo(e, t, n, o) {
            const r = o.includes(".") ? mr(n, o) : () => n[o];
            if (k(e)) {
                const n = t[e];
                S(n) && vr(r, n)
            } else if (S(e)) vr(r, e.bind(n));
            else if (_(e))
                if (x(e)) e.forEach((e => fo(e, t, n, o)));
                else {
                    const o = S(e.handler) ? e.handler.bind(n) : t[e.handler];
                    S(o) && vr(r, o, e)
                }
            else 0
        }

        function po(e) {
            const t = e.type,
                {
                    mixins: n,
                    extends: o
                } = t,
                {
                    mixins: r,
                    optionsCache: i,
                    config: {
                        optionMergeStrategies: l
                    }
                } = e.appContext,
                a = i.get(t);
            let s;
            return a ? s = a : r.length || n || o ? (s = {}, r.length && r.forEach((e => ho(s, e, l, !0))), ho(s, t, l)) : s = t, _(t) && i.set(t, s), s
        }

        function ho(e, t, n, o = !1) {
            const {
                mixins: r,
                extends: i
            } = t;
            i && ho(e, i, n, !0), r && r.forEach((t => ho(e, t, n, !0)));
            for (const r in t)
                if (o && "expose" === r);
                else {
                    const o = vo[r] || n && n[r];
                    e[r] = o ? o(e[r], t[r]) : t[r]
                } return e
        }
        const vo = {
            data: go,
            props: xo,
            emits: xo,
            methods: yo,
            computed: yo,
            beforeCreate: mo,
            created: mo,
            beforeMount: mo,
            mounted: mo,
            beforeUpdate: mo,
            updated: mo,
            beforeDestroy: mo,
            beforeUnmount: mo,
            destroyed: mo,
            unmounted: mo,
            activated: mo,
            deactivated: mo,
            errorCaptured: mo,
            serverPrefetch: mo,
            components: yo,
            directives: yo,
            watch: function(e, t) {
                if (!e) return t;
                if (!t) return e;
                const n = g(Object.create(null), e);
                for (const o in t) n[o] = mo(e[o], t[o]);
                return n
            },
            provide: go,
            inject: function(e, t) {
                return yo(bo(e), bo(t))
            }
        };

        function go(e, t) {
            return t ? e ? function() {
                return g(S(e) ? e.call(this, this) : e, S(t) ? t.call(this, this) : t)
            } : t : e
        }

        function bo(e) {
            if (x(e)) {
                const t = {};
                for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
                return t
            }
            return e
        }

        function mo(e, t) {
            return e ? [...new Set([].concat(e, t))] : t
        }

        function yo(e, t) {
            return e ? g(Object.create(null), e, t) : t
        }

        function xo(e, t) {
            return e ? x(e) && x(t) ? [...new Set([...e, ...t])] : g(Object.create(null), ao(e), ao(null != t ? t : {})) : t
        }

        function wo() {
            return {
                app: null,
                config: {
                    isNativeTag: p,
                    performance: !1,
                    globalProperties: {},
                    optionMergeStrategies: {},
                    errorHandler: void 0,
                    warnHandler: void 0,
                    compilerOptions: {}
                },
                mixins: [],
                components: {},
                directives: {},
                provides: Object.create(null),
                optionsCache: new WeakMap,
                propsCache: new WeakMap,
                emitsCache: new WeakMap
            }
        }
        let Co = 0;

        function So(e, t) {
            return function(n, o = null) {
                S(n) || (n = g({}, n)), null == o || _(o) || (o = null);
                const r = wo(),
                    i = new WeakSet;
                let l = !1;
                const a = r.app = {
                    _uid: Co++,
                    _component: n,
                    _props: o,
                    _container: null,
                    _context: r,
                    _instance: null,
                    version: Pi,
                    get config() {
                        return r.config
                    },
                    set config(e) {
                        0
                    },
                    use(e, ...t) {
                        return i.has(e) || (e && S(e.install) ? (i.add(e), e.install(a, ...t)) : S(e) && (i.add(e), e(a, ...t))), a
                    },
                    mixin(e) {
                        return r.mixins.includes(e) || r.mixins.push(e), a
                    },
                    component(e, t) {
                        return t ? (r.components[e] = t, a) : r.components[e]
                    },
                    directive(e, t) {
                        return t ? (r.directives[e] = t, a) : r.directives[e]
                    },
                    mount(i, s, c) {
                        if (!l) {
                            0;
                            const u = Xr(n, o);
                            return u.appContext = r, !0 === c ? c = "svg" : !1 === c && (c = void 0), s && t ? t(u, i) : e(u, i, c), l = !0, a._container = i, i.__vue_app__ = a, ki(u.component)
                        }
                    },
                    unmount() {
                        l && (e(null, a._container), delete a._container.__vue_app__)
                    },
                    provide(e, t) {
                        return r.provides[e] = t, a
                    },
                    runWithContext(e) {
                        const t = ko;
                        ko = a;
                        try {
                            return e()
                        } finally {
                            ko = t
                        }
                    }
                };
                return a
            }
        }
        let ko = null;

        function $o(e, t) {
            if (ci) {
                let n = ci.provides;
                const o = ci.parent && ci.parent.provides;
                o === n && (n = ci.provides = Object.create(o)), n[e] = t
            } else 0
        }

        function _o(e, t, n = !1) {
            const o = ci || sn;
            if (o || ko) {
                const r = o ? null == o.parent ? o.vnode.appContext && o.vnode.appContext.provides : o.parent.provides : ko._context.provides;
                if (r && e in r) return r[e];
                if (arguments.length > 1) return n && S(t) ? t.call(o && o.proxy) : t
            } else 0
        }
        const zo = {},
            To = () => Object.create(zo),
            Po = e => Object.getPrototypeOf(e) === zo;

        function Fo(e, t, n, o = !1) {
            const r = {},
                i = To();
            e.propsDefaults = Object.create(null), Mo(e, t, r, i);
            for (const t in e.propsOptions[0]) t in r || (r[t] = void 0);
            n ? e.props = o ? r : gt(r, !1, He, st, dt) : e.type.props ? e.props = r : e.props = i, e.attrs = i
        }

        function Mo(e, t, n, o) {
            const [r, i] = e.propsOptions;
            let l, a = !1;
            if (t)
                for (let s in t) {
                    if (E(s)) continue;
                    const c = t[s];
                    let u;
                    r && y(r, u = A(s)) ? i && i.includes(u) ? (l || (l = {}))[u] = c : n[u] = c : Sr(e.emitsOptions, s) || s in o && c === o[s] || (o[s] = c, a = !0)
                }
            if (i) {
                const t = wt(n),
                    o = l || u;
                for (let l = 0; l < i.length; l++) {
                    const a = i[l];
                    n[a] = Ro(r, t, a, o[a], e, !y(o, a))
                }
            }
            return a
        }

        function Ro(e, t, n, o, r, i) {
            const l = e[n];
            if (null != l) {
                const e = y(l, "default");
                if (e && void 0 === o) {
                    const e = l.default;
                    if (l.type !== Function && !l.skipFactory && S(e)) {
                        const {
                            propsDefaults: i
                        } = r;
                        if (n in i) o = i[n];
                        else {
                            const l = pi(r);
                            o = i[n] = e.call(null, t), l()
                        }
                    } else o = e
                }
                l[0] && (i && !e ? o = !1 : !l[1] || "" !== o && o !== D(n) || (o = !0))
            }
            return o
        }
        const Eo = new WeakMap;

        function Oo(e, t, n = !1) {
            const o = n ? Eo : t.propsCache,
                r = o.get(e);
            if (r) return r;
            const i = e.props,
                l = {},
                a = [];
            let s = !1;
            if (!S(e)) {
                const o = e => {
                    s = !0;
                    const [n, o] = Oo(e, t, !0);
                    g(l, n), o && a.push(...o)
                };
                !n && t.mixins.length && t.mixins.forEach(o), e.extends && o(e.extends), e.mixins && e.mixins.forEach(o)
            }
            if (!i && !s) return _(e) && o.set(e, d), d;
            if (x(i))
                for (let e = 0; e < i.length; e++) {
                    0;
                    const t = A(i[e]);
                    Bo(t) && (l[t] = u)
                } else if (i) {
                    0;
                    for (const e in i) {
                        const t = A(e);
                        if (Bo(t)) {
                            const n = i[e],
                                o = l[t] = x(n) || S(n) ? {
                                    type: n
                                } : g({}, n);
                            if (o) {
                                const e = Do(Boolean, o.type),
                                    n = Do(String, o.type);
                                o[0] = e > -1, o[1] = n < 0 || e < n, (e > -1 || y(o, "default")) && a.push(t)
                            }
                        }
                    }
                } const c = [l, a];
            return _(e) && o.set(e, c), c
        }

        function Bo(e) {
            return "$" !== e[0] && !E(e)
        }

        function Ao(e) {
            if (null === e) return "null";
            if ("function" == typeof e) return e.name || "";
            if ("object" == typeof e) {
                return e.constructor && e.constructor.name || ""
            }
            return ""
        }

        function Io(e, t) {
            return Ao(e) === Ao(t)
        }

        function Do(e, t) {
            return x(t) ? t.findIndex((t => Io(t, e))) : S(t) && Io(t, e) ? 0 : -1
        }
        const Lo = e => "_" === e[0] || "$stable" === e,
            jo = e => x(e) ? e.map(ti) : [ti(e)],
            No = (e, t, n) => {
                if (t._n) return t;
                const o = dn(((...e) => jo(t(...e))), n);
                return o._c = !1, o
            },
            Ho = (e, t, n) => {
                const o = e._ctx;
                for (const n in e) {
                    if (Lo(n)) continue;
                    const r = e[n];
                    if (S(r)) t[n] = No(0, r, o);
                    else if (null != r) {
                        0;
                        const e = jo(r);
                        t[n] = () => e
                    }
                }
            },
            Wo = (e, t) => {
                const n = jo(t);
                e.slots.default = () => n
            },
            Vo = (e, t, n) => {
                for (const o in t)(n || "_" !== o) && (e[o] = t[o])
            },
            qo = (e, t, n) => {
                const o = e.slots = To();
                if (32 & e.vnode.shapeFlag) {
                    const e = t._;
                    e ? (Vo(o, t, n), n && W(o, "_", e, !0)) : Ho(t, o)
                } else t && Wo(e, t)
            },
            Uo = (e, t, n) => {
                const {
                    vnode: o,
                    slots: r
                } = e;
                let i = !0,
                    l = u;
                if (32 & o.shapeFlag) {
                    const e = t._;
                    e ? n && 1 === e ? i = !1 : Vo(r, t, n) : (i = !t.$stable, Ho(t, r)), l = t
                } else t && (Wo(e, t), l = {
                    default: 1
                });
                if (i)
                    for (const e in r) Lo(e) || null != l[e] || delete r[e]
            };

        function Ko(e, t, n, o, r = !1) {
            if (x(e)) return void e.forEach(((e, i) => Ko(e, t && (x(t) ? t[i] : t), n, o, r)));
            if (Pn(o) && !r) return;
            const i = 4 & o.shapeFlag ? ki(o.component) : o.el,
                l = r ? null : i,
                {
                    i: a,
                    r: s
                } = e;
            const c = t && t.r,
                d = a.refs === u ? a.refs = {} : a.refs,
                f = a.setupState;
            if (null != c && c !== s && (k(c) ? (d[c] = null, y(f, c) && (f[c] = null)) : Pt(c) && (c.value = null)), S(s)) jt(s, a, 12, [l, d]);
            else {
                const t = k(s),
                    o = Pt(s);
                if (t || o) {
                    const a = () => {
                        if (e.f) {
                            const n = t ? y(f, s) ? f[s] : d[s] : s.value;
                            r ? x(n) && b(n, i) : x(n) ? n.includes(i) || n.push(i) : t ? (d[s] = [i], y(f, s) && (f[s] = d[s])) : (s.value = [i], e.k && (d[e.k] = s.value))
                        } else t ? (d[s] = l, y(f, s) && (f[s] = l)) : o && (s.value = l, e.k && (d[e.k] = l))
                    };
                    l ? (a.id = -1, or(a, n)) : a()
                } else 0
            }
        }
        const Go = Symbol("_vte"),
            Xo = e => e && (e.disabled || "" === e.disabled),
            Yo = e => "undefined" != typeof SVGElement && e instanceof SVGElement,
            Zo = e => "function" == typeof MathMLElement && e instanceof MathMLElement,
            Jo = (e, t) => {
                const n = e && e.to;
                if (k(n)) {
                    if (t) {
                        return t(n)
                    }
                    return null
                }
                return n
            },
            Qo = {
                name: "Teleport",
                __isTeleport: !0,
                process(e, t, n, o, r, i, l, a, s, c) {
                    const {
                        mc: u,
                        pc: d,
                        pbc: f,
                        o: {
                            insert: p,
                            querySelector: h,
                            createText: v,
                            createComment: g
                        }
                    } = c, b = Xo(t.props);
                    let {
                        shapeFlag: m,
                        children: y,
                        dynamicChildren: x
                    } = t;
                    if (null == e) {
                        const e = t.el = v(""),
                            c = t.anchor = v(""),
                            d = t.target = Jo(t.props, h),
                            f = t.targetStart = v(""),
                            g = t.targetAnchor = v("");
                        p(e, n, o), p(c, n, o), f[Go] = g, d && (p(f, d), p(g, d), "svg" === l || Yo(d) ? l = "svg" : ("mathml" === l || Zo(d)) && (l = "mathml"));
                        const x = (e, t) => {
                            16 & m && u(y, e, t, r, i, l, a, s)
                        };
                        b ? x(n, c) : d && x(d, g)
                    } else {
                        t.el = e.el, t.targetStart = e.targetStart;
                        const o = t.anchor = e.anchor,
                            u = t.target = e.target,
                            p = t.targetAnchor = e.targetAnchor,
                            v = Xo(e.props),
                            g = v ? n : u,
                            m = v ? o : p;
                        if ("svg" === l || Yo(u) ? l = "svg" : ("mathml" === l || Zo(u)) && (l = "mathml"), x ? (f(e.dynamicChildren, x, g, r, i, l, a), sr(e, t, !0)) : s || d(e, t, g, m, r, i, l, a, !1), b) v ? t.props && e.props && t.props.to !== e.props.to && (t.props.to = e.props.to) : er(t, n, o, c, 1);
                        else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
                            const e = t.target = Jo(t.props, h);
                            e && er(t, e, null, c, 0)
                        } else v && er(t, u, p, c, 1)
                    }
                    nr(t)
                },
                remove(e, t, n, {
                    um: o,
                    o: {
                        remove: r
                    }
                }, i) {
                    const {
                        shapeFlag: l,
                        children: a,
                        anchor: s,
                        targetStart: c,
                        targetAnchor: u,
                        target: d,
                        props: f
                    } = e;
                    if (d && (r(c), r(u)), i && r(s), 16 & l) {
                        const e = i || !Xo(f);
                        for (let r = 0; r < a.length; r++) {
                            const i = a[r];
                            o(i, t, n, e, !!i.dynamicChildren)
                        }
                    }
                },
                move: er,
                hydrate: function(e, t, n, o, r, i, {
                    o: {
                        nextSibling: l,
                        parentNode: a,
                        querySelector: s
                    }
                }, c) {
                    const u = t.target = Jo(t.props, s);
                    if (u) {
                        const s = u._lpa || u.firstChild;
                        if (16 & t.shapeFlag)
                            if (Xo(t.props)) t.anchor = c(l(e), t, a(e), n, o, r, i), t.targetAnchor = s;
                            else {
                                t.anchor = l(e);
                                let a = s;
                                for (; a;)
                                    if (a = l(a), a && 8 === a.nodeType && "teleport anchor" === a.data) {
                                        t.targetAnchor = a, u._lpa = t.targetAnchor && l(t.targetAnchor);
                                        break
                                    } c(s, t, u, n, o, r, i)
                            } nr(t)
                    }
                    return t.anchor && l(t.anchor)
                }
            };

        function er(e, t, n, {
            o: {
                insert: o
            },
            m: r
        }, i = 2) {
            0 === i && o(e.targetAnchor, t, n);
            const {
                el: l,
                anchor: a,
                shapeFlag: s,
                children: c,
                props: u
            } = e, d = 2 === i;
            if (d && o(l, t, n), (!d || Xo(u)) && 16 & s)
                for (let e = 0; e < c.length; e++) r(c[e], t, n, 2);
            d && o(a, t, n)
        }
        const tr = Qo;

        function nr(e) {
            const t = e.ctx;
            if (t && t.ut) {
                let n = e.children[0].el;
                for (; n && n !== e.targetAnchor;) 1 === n.nodeType && n.setAttribute("data-v-owner", t.uid), n = n.nextSibling;
                t.ut()
            }
        }
        const or = Fr;

        function rr(e, t) {
            "boolean" != typeof __VUE_PROD_HYDRATION_MISMATCH_DETAILS__ && (K().__VUE_PROD_HYDRATION_MISMATCH_DETAILS__ = !1);
            K().__VUE__ = !0;
            const {
                insert: n,
                remove: o,
                patchProp: r,
                createElement: i,
                createText: l,
                createComment: a,
                setText: s,
                setElementText: c,
                parentNode: p,
                nextSibling: h,
                setScopeId: v = f,
                insertStaticContent: g
            } = e, b = (e, t, n, o = null, r = null, i = null, l = void 0, a = null, s = !!t.dynamicChildren) => {
                if (e === t) return;
                e && !qr(e, t) && (o = Y(e), V(e, r, i, !0), e = null), -2 === t.patchFlag && (s = !1, t.dynamicChildren = null);
                const {
                    type: c,
                    ref: u,
                    shapeFlag: d
                } = t;
                switch (c) {
                    case Rr:
                        m(e, t, n, o);
                        break;
                    case Er:
                        x(e, t, n, o);
                        break;
                    case Or:
                        null == e && w(t, n, o, l);
                        break;
                    case Mr:
                        F(e, t, n, o, r, i, l, a, s);
                        break;
                    default:
                        1 & d ? S(e, t, n, o, r, i, l, a, s) : 6 & d ? M(e, t, n, o, r, i, l, a, s) : (64 & d || 128 & d) && c.process(e, t, n, o, r, i, l, a, s, Q)
                }
                null != u && r && Ko(u, e && e.ref, i, t || e, !t)
            }, m = (e, t, o, r) => {
                if (null == e) n(t.el = l(t.children), o, r);
                else {
                    const n = t.el = e.el;
                    t.children !== e.children && s(n, t.children)
                }
            }, x = (e, t, o, r) => {
                null == e ? n(t.el = a(t.children || ""), o, r) : t.el = e.el
            }, w = (e, t, n, o) => {
                [e.el, e.anchor] = g(e.children, t, n, o, e.el, e.anchor)
            }, C = ({
                el: e,
                anchor: t
            }) => {
                let n;
                for (; e && e !== t;) n = h(e), o(e), e = n;
                o(t)
            }, S = (e, t, n, o, r, i, l, a, s) => {
                "svg" === t.type ? l = "svg" : "math" === t.type && (l = "mathml"), null == e ? k(t, n, o, r, i, l, a, s) : z(e, t, r, i, l, a, s)
            }, k = (e, t, o, l, a, s, u, d) => {
                let f, p;
                const {
                    props: h,
                    shapeFlag: v,
                    transition: g,
                    dirs: b
                } = e;
                if (f = e.el = i(e.type, s, h && h.is, h), 8 & v ? c(f, e.children) : 16 & v && _(e.children, f, null, l, a, ir(e, s), u, d), b && pn(e, null, l, "created"), $(f, e, e.scopeId, u, l), h) {
                    for (const e in h) "value" === e || E(e) || r(f, e, null, h[e], s, l);
                    "value" in h && r(f, "value", null, h.value, s), (p = h.onVnodeBeforeMount) && ii(p, l, e)
                }
                b && pn(e, null, l, "beforeMount");
                const m = ar(a, g);
                m && g.beforeEnter(f), n(f, t, o), ((p = h && h.onVnodeMounted) || m || b) && or((() => {
                    p && ii(p, l, e), m && g.enter(f), b && pn(e, null, l, "mounted")
                }), a)
            }, $ = (e, t, n, o, r) => {
                if (n && v(e, n), o)
                    for (let t = 0; t < o.length; t++) v(e, o[t]);
                if (r) {
                    if (t === r.subTree) {
                        const t = r.vnode;
                        $(e, t, t.scopeId, t.slotScopeIds, r.parent)
                    }
                }
            }, _ = (e, t, n, o, r, i, l, a, s = 0) => {
                for (let c = s; c < e.length; c++) {
                    const s = e[c] = a ? ni(e[c]) : ti(e[c]);
                    b(null, s, t, n, o, r, i, l, a)
                }
            }, z = (e, t, n, o, i, l, a) => {
                const s = t.el = e.el;
                let {
                    patchFlag: d,
                    dynamicChildren: f,
                    dirs: p
                } = t;
                d |= 16 & e.patchFlag;
                const h = e.props || u,
                    v = t.props || u;
                let g;
                if (n && lr(n, !1), (g = v.onVnodeBeforeUpdate) && ii(g, n, t, e), p && pn(t, e, n, "beforeUpdate"), n && lr(n, !0), (h.innerHTML && null == v.innerHTML || h.textContent && null == v.textContent) && c(s, ""), f ? T(e.dynamicChildren, f, s, n, o, ir(t, i), l) : a || L(e, t, s, null, n, o, ir(t, i), l, !1), d > 0) {
                    if (16 & d) P(s, h, v, n, i);
                    else if (2 & d && h.class !== v.class && r(s, "class", null, v.class, i), 4 & d && r(s, "style", h.style, v.style, i), 8 & d) {
                        const e = t.dynamicProps;
                        for (let t = 0; t < e.length; t++) {
                            const o = e[t],
                                l = h[o],
                                a = v[o];
                            a === l && "value" !== o || r(s, o, l, a, i, n)
                        }
                    }
                    1 & d && e.children !== t.children && c(s, t.children)
                } else a || null != f || P(s, h, v, n, i);
                ((g = v.onVnodeUpdated) || p) && or((() => {
                    g && ii(g, n, t, e), p && pn(t, e, n, "updated")
                }), o)
            }, T = (e, t, n, o, r, i, l) => {
                for (let a = 0; a < t.length; a++) {
                    const s = e[a],
                        c = t[a],
                        u = s.el && (s.type === Mr || !qr(s, c) || 70 & s.shapeFlag) ? p(s.el) : n;
                    b(s, c, u, null, o, r, i, l, !0)
                }
            }, P = (e, t, n, o, i) => {
                if (t !== n) {
                    if (t !== u)
                        for (const l in t) E(l) || l in n || r(e, l, t[l], null, i, o);
                    for (const l in n) {
                        if (E(l)) continue;
                        const a = n[l],
                            s = t[l];
                        a !== s && "value" !== l && r(e, l, s, a, i, o)
                    }
                    "value" in n && r(e, "value", t.value, n.value, i)
                }
            }, F = (e, t, o, r, i, a, s, c, u) => {
                const d = t.el = e ? e.el : l(""),
                    f = t.anchor = e ? e.anchor : l("");
                let {
                    patchFlag: p,
                    dynamicChildren: h,
                    slotScopeIds: v
                } = t;
                v && (c = c ? c.concat(v) : v), null == e ? (n(d, o, r), n(f, o, r), _(t.children || [], o, f, i, a, s, c, u)) : p > 0 && 64 & p && h && e.dynamicChildren ? (T(e.dynamicChildren, h, o, i, a, s, c), (null != t.key || i && t === i.subTree) && sr(e, t, !0)) : L(e, t, o, f, i, a, s, c, u)
            }, M = (e, t, n, o, r, i, l, a, s) => {
                t.slotScopeIds = a, null == e ? 512 & t.shapeFlag ? r.ctx.activate(t, n, o, l, s) : R(t, n, o, r, i, l, s) : O(e, t, s)
            }, R = (e, t, n, o, r, i, l) => {
                const a = e.component = si(e, o, r);
                if (Fn(e) && (a.ctx.renderer = Q), yi(a, !1, l), a.asyncDep) {
                    if (r && r.registerDep(a, B, l), !e.el) {
                        const e = a.subTree = Xr(Er);
                        x(null, e, t, n)
                    }
                } else B(a, e, t, n, r, i, l)
            }, O = (e, t, n) => {
                const o = t.component = e.component;
                if (function(e, t, n) {
                        const {
                            props: o,
                            children: r,
                            component: i
                        } = e, {
                            props: l,
                            children: a,
                            patchFlag: s
                        } = t, c = i.emitsOptions;
                        0;
                        if (t.dirs || t.transition) return !0;
                        if (!(n && s >= 0)) return !(!r && !a || a && a.$stable) || o !== l && (o ? !l || zr(o, l, c) : !!l);
                        if (1024 & s) return !0;
                        if (16 & s) return o ? zr(o, l, c) : !!l;
                        if (8 & s) {
                            const e = t.dynamicProps;
                            for (let t = 0; t < e.length; t++) {
                                const n = e[t];
                                if (l[n] !== o[n] && !Sr(c, n)) return !0
                            }
                        }
                        return !1
                    }(e, t, n)) {
                    if (o.asyncDep && !o.asyncResolved) return void I(o, t, n);
                    o.next = t,
                        function(e) {
                            const t = qt.indexOf(e);
                            t > Ut && qt.splice(t, 1)
                        }(o.update), o.effect.dirty = !0, o.update()
                } else t.el = e.el, o.vnode = t
            }, B = (e, t, n, o, r, i, l) => {
                const a = () => {
                        if (e.isMounted) {
                            let {
                                next: t,
                                bu: n,
                                u: o,
                                parent: s,
                                vnode: c
                            } = e;
                            {
                                const n = cr(e);
                                if (n) return t && (t.el = c.el, I(e, t, l)), void n.asyncDep.then((() => {
                                    e.isUnmounted || a()
                                }))
                            }
                            let u, d = t;
                            0, lr(e, !1), t ? (t.el = c.el, I(e, t, l)) : t = c, n && H(n), (u = t.props && t.props.onVnodeBeforeUpdate) && ii(u, s, t, c), lr(e, !0);
                            const f = kr(e);
                            0;
                            const h = e.subTree;
                            e.subTree = f, b(h, f, p(h.el), Y(h), e, r, i), t.el = f.el, null === d && Tr(e, f.el), o && or(o, r), (u = t.props && t.props.onVnodeUpdated) && or((() => ii(u, s, t, c)), r)
                        } else {
                            let l;
                            const {
                                el: a,
                                props: s
                            } = t, {
                                bm: c,
                                m: u,
                                parent: d
                            } = e, f = Pn(t);
                            if (lr(e, !1), c && H(c), !f && (l = s && s.onVnodeBeforeMount) && ii(l, d, t), lr(e, !0), a && te) {
                                const n = () => {
                                    e.subTree = kr(e), te(a, e.subTree, e, r, null)
                                };
                                f ? t.type.__asyncLoader().then((() => !e.isUnmounted && n())) : n()
                            } else {
                                0;
                                const l = e.subTree = kr(e);
                                0, b(null, l, n, o, e, r, i), t.el = l.el
                            }
                            if (u && or(u, r), !f && (l = s && s.onVnodeMounted)) {
                                const e = t;
                                or((() => ii(l, d, e)), r)
                            }(256 & t.shapeFlag || d && Pn(d.vnode) && 256 & d.vnode.shapeFlag) && e.a && or(e.a, r), e.isMounted = !0, t = n = o = null
                        }
                    },
                    s = e.effect = new de(a, f, (() => Qt(c)), e.scope),
                    c = e.update = () => {
                        s.dirty && s.run()
                    };
                c.i = e, c.id = e.uid, lr(e, !0), c()
            }, I = (e, t, n) => {
                t.component = e;
                const o = e.vnode.props;
                e.vnode = t, e.next = null,
                    function(e, t, n, o) {
                        const {
                            props: r,
                            attrs: i,
                            vnode: {
                                patchFlag: l
                            }
                        } = e, a = wt(r), [s] = e.propsOptions;
                        let c = !1;
                        if (!(o || l > 0) || 16 & l) {
                            let o;
                            Mo(e, t, r, i) && (c = !0);
                            for (const i in a) t && (y(t, i) || (o = D(i)) !== i && y(t, o)) || (s ? !n || void 0 === n[i] && void 0 === n[o] || (r[i] = Ro(s, a, i, void 0, e, !0)) : delete r[i]);
                            if (i !== a)
                                for (const e in i) t && y(t, e) || (delete i[e], c = !0)
                        } else if (8 & l) {
                            const n = e.vnode.dynamicProps;
                            for (let o = 0; o < n.length; o++) {
                                let l = n[o];
                                if (Sr(e.emitsOptions, l)) continue;
                                const u = t[l];
                                if (s)
                                    if (y(i, l)) u !== i[l] && (i[l] = u, c = !0);
                                    else {
                                        const t = A(l);
                                        r[t] = Ro(s, a, t, u, e, !1)
                                    }
                                else u !== i[l] && (i[l] = u, c = !0)
                            }
                        }
                        c && Me(e.attrs, "set", "")
                    }(e, t.props, o, n), Uo(e, t.children, n), ye(), nn(e), xe()
            }, L = (e, t, n, o, r, i, l, a, s = !1) => {
                const u = e && e.children,
                    d = e ? e.shapeFlag : 0,
                    f = t.children,
                    {
                        patchFlag: p,
                        shapeFlag: h
                    } = t;
                if (p > 0) {
                    if (128 & p) return void N(u, f, n, o, r, i, l, a, s);
                    if (256 & p) return void j(u, f, n, o, r, i, l, a, s)
                }
                8 & h ? (16 & d && X(u, r, i), f !== u && c(n, f)) : 16 & d ? 16 & h ? N(u, f, n, o, r, i, l, a, s) : X(u, r, i, !0) : (8 & d && c(n, ""), 16 & h && _(f, n, o, r, i, l, a, s))
            }, j = (e, t, n, o, r, i, l, a, s) => {
                t = t || d;
                const c = (e = e || d).length,
                    u = t.length,
                    f = Math.min(c, u);
                let p;
                for (p = 0; p < f; p++) {
                    const o = t[p] = s ? ni(t[p]) : ti(t[p]);
                    b(e[p], o, n, null, r, i, l, a, s)
                }
                c > u ? X(e, r, i, !0, !1, f) : _(t, n, o, r, i, l, a, s, f)
            }, N = (e, t, n, o, r, i, l, a, s) => {
                let c = 0;
                const u = t.length;
                let f = e.length - 1,
                    p = u - 1;
                for (; c <= f && c <= p;) {
                    const o = e[c],
                        u = t[c] = s ? ni(t[c]) : ti(t[c]);
                    if (!qr(o, u)) break;
                    b(o, u, n, null, r, i, l, a, s), c++
                }
                for (; c <= f && c <= p;) {
                    const o = e[f],
                        c = t[p] = s ? ni(t[p]) : ti(t[p]);
                    if (!qr(o, c)) break;
                    b(o, c, n, null, r, i, l, a, s), f--, p--
                }
                if (c > f) {
                    if (c <= p) {
                        const e = p + 1,
                            d = e < u ? t[e].el : o;
                        for (; c <= p;) b(null, t[c] = s ? ni(t[c]) : ti(t[c]), n, d, r, i, l, a, s), c++
                    }
                } else if (c > p)
                    for (; c <= f;) V(e[c], r, i, !0), c++;
                else {
                    const h = c,
                        v = c,
                        g = new Map;
                    for (c = v; c <= p; c++) {
                        const e = t[c] = s ? ni(t[c]) : ti(t[c]);
                        null != e.key && g.set(e.key, c)
                    }
                    let m, y = 0;
                    const x = p - v + 1;
                    let w = !1,
                        C = 0;
                    const S = new Array(x);
                    for (c = 0; c < x; c++) S[c] = 0;
                    for (c = h; c <= f; c++) {
                        const o = e[c];
                        if (y >= x) {
                            V(o, r, i, !0);
                            continue
                        }
                        let u;
                        if (null != o.key) u = g.get(o.key);
                        else
                            for (m = v; m <= p; m++)
                                if (0 === S[m - v] && qr(o, t[m])) {
                                    u = m;
                                    break
                                } void 0 === u ? V(o, r, i, !0) : (S[u - v] = c + 1, u >= C ? C = u : w = !0, b(o, t[u], n, null, r, i, l, a, s), y++)
                    }
                    const k = w ? function(e) {
                        const t = e.slice(),
                            n = [0];
                        let o, r, i, l, a;
                        const s = e.length;
                        for (o = 0; o < s; o++) {
                            const s = e[o];
                            if (0 !== s) {
                                if (r = n[n.length - 1], e[r] < s) {
                                    t[o] = r, n.push(o);
                                    continue
                                }
                                for (i = 0, l = n.length - 1; i < l;) a = i + l >> 1, e[n[a]] < s ? i = a + 1 : l = a;
                                s < e[n[i]] && (i > 0 && (t[o] = n[i - 1]), n[i] = o)
                            }
                        }
                        i = n.length, l = n[i - 1];
                        for (; i-- > 0;) n[i] = l, l = t[l];
                        return n
                    }(S) : d;
                    for (m = k.length - 1, c = x - 1; c >= 0; c--) {
                        const e = v + c,
                            d = t[e],
                            f = e + 1 < u ? t[e + 1].el : o;
                        0 === S[c] ? b(null, d, n, f, r, i, l, a, s) : w && (m < 0 || c !== k[m] ? W(d, n, f, 2) : m--)
                    }
                }
            }, W = (e, t, o, r, i = null) => {
                const {
                    el: l,
                    type: a,
                    transition: s,
                    children: c,
                    shapeFlag: u
                } = e;
                if (6 & u) return void W(e.component.subTree, t, o, r);
                if (128 & u) return void e.suspense.move(t, o, r);
                if (64 & u) return void a.move(e, t, o, Q);
                if (a === Mr) {
                    n(l, t, o);
                    for (let e = 0; e < c.length; e++) W(c[e], t, o, r);
                    return void n(e.anchor, t, o)
                }
                if (a === Or) return void(({
                    el: e,
                    anchor: t
                }, o, r) => {
                    let i;
                    for (; e && e !== t;) i = h(e), n(e, o, r), e = i;
                    n(t, o, r)
                })(e, t, o);
                if (2 !== r && 1 & u && s)
                    if (0 === r) s.beforeEnter(l), n(l, t, o), or((() => s.enter(l)), i);
                    else {
                        const {
                            leave: e,
                            delayLeave: r,
                            afterLeave: i
                        } = s, a = () => n(l, t, o), c = () => {
                            e(l, (() => {
                                a(), i && i()
                            }))
                        };
                        r ? r(l, a, c) : c()
                    }
                else n(l, t, o)
            }, V = (e, t, n, o = !1, r = !1) => {
                const {
                    type: i,
                    props: l,
                    ref: a,
                    children: s,
                    dynamicChildren: c,
                    shapeFlag: u,
                    patchFlag: d,
                    dirs: f,
                    cacheIndex: p
                } = e;
                if (-2 === d && (r = !1), null != a && Ko(a, null, n, e, !0), null != p && (t.renderCache[p] = void 0), 256 & u) return void t.ctx.deactivate(e);
                const h = 1 & u && f,
                    v = !Pn(e);
                let g;
                if (v && (g = l && l.onVnodeBeforeUnmount) && ii(g, t, e), 6 & u) G(e.component, n, o);
                else {
                    if (128 & u) return void e.suspense.unmount(n, o);
                    h && pn(e, null, t, "beforeUnmount"), 64 & u ? e.type.remove(e, t, n, Q, o) : c && !c.hasOnce && (i !== Mr || d > 0 && 64 & d) ? X(c, t, n, !1, !0) : (i === Mr && 384 & d || !r && 16 & u) && X(s, t, n), o && q(e)
                }(v && (g = l && l.onVnodeUnmounted) || h) && or((() => {
                    g && ii(g, t, e), h && pn(e, null, t, "unmounted")
                }), n)
            }, q = e => {
                const {
                    type: t,
                    el: n,
                    anchor: r,
                    transition: i
                } = e;
                if (t === Mr) return void U(n, r);
                if (t === Or) return void C(e);
                const l = () => {
                    o(n), i && !i.persisted && i.afterLeave && i.afterLeave()
                };
                if (1 & e.shapeFlag && i && !i.persisted) {
                    const {
                        leave: t,
                        delayLeave: o
                    } = i, r = () => t(n, l);
                    o ? o(e.el, l, r) : r()
                } else l()
            }, U = (e, t) => {
                let n;
                for (; e !== t;) n = h(e), o(e), e = n;
                o(t)
            }, G = (e, t, n) => {
                const {
                    bum: o,
                    scope: r,
                    update: i,
                    subTree: l,
                    um: a,
                    m: s,
                    a: c
                } = e;
                ur(s), ur(c), o && H(o), r.stop(), i && (i.active = !1, V(l, e, t, n)), a && or(a, t), or((() => {
                    e.isUnmounted = !0
                }), t), t && t.pendingBranch && !t.isUnmounted && e.asyncDep && !e.asyncResolved && e.suspenseId === t.pendingId && (t.deps--, 0 === t.deps && t.resolve())
            }, X = (e, t, n, o = !1, r = !1, i = 0) => {
                for (let l = i; l < e.length; l++) V(e[l], t, n, o, r)
            }, Y = e => {
                if (6 & e.shapeFlag) return Y(e.component.subTree);
                if (128 & e.shapeFlag) return e.suspense.next();
                const t = h(e.anchor || e.el),
                    n = t && t[Go];
                return n ? h(n) : t
            };
            let Z = !1;
            const J = (e, t, n) => {
                    null == e ? t._vnode && V(t._vnode, null, null, !0) : b(t._vnode || null, e, t, null, null, null, n), Z || (Z = !0, nn(), on(), Z = !1), t._vnode = e
                },
                Q = {
                    p: b,
                    um: V,
                    m: W,
                    r: q,
                    mt: R,
                    mc: _,
                    pc: L,
                    pbc: T,
                    n: Y,
                    o: e
                };
            let ee, te;
            return t && ([ee, te] = t(Q)), {
                render: J,
                hydrate: ee,
                createApp: So(J, ee)
            }
        }

        function ir({
            type: e,
            props: t
        }, n) {
            return "svg" === n && "foreignObject" === e || "mathml" === n && "annotation-xml" === e && t && t.encoding && t.encoding.includes("html") ? void 0 : n
        }

        function lr({
            effect: e,
            update: t
        }, n) {
            e.allowRecurse = t.allowRecurse = n
        }

        function ar(e, t) {
            return (!e || e && !e.pendingBranch) && t && !t.persisted
        }

        function sr(e, t, n = !1) {
            const o = e.children,
                r = t.children;
            if (x(o) && x(r))
                for (let e = 0; e < o.length; e++) {
                    const t = o[e];
                    let i = r[e];
                    1 & i.shapeFlag && !i.dynamicChildren && ((i.patchFlag <= 0 || 32 === i.patchFlag) && (i = r[e] = ni(r[e]), i.el = t.el), n || -2 === i.patchFlag || sr(t, i)), i.type === Rr && (i.el = t.el)
                }
        }

        function cr(e) {
            const t = e.subTree.component;
            if (t) return t.asyncDep && !t.asyncResolved ? t : cr(t)
        }

        function ur(e) {
            if (e)
                for (let t = 0; t < e.length; t++) e[t].active = !1
        }
        const dr = Symbol.for("v-scx"),
            fr = () => {
                {
                    const e = _o(dr);
                    return e
                }
            };

        function pr(e, t) {
            return gr(e, null, t)
        }
        const hr = {};

        function vr(e, t, n) {
            return gr(e, t, n)
        }

        function gr(e, t, {
            immediate: n,
            deep: o,
            flush: r,
            once: i,
            onTrack: l,
            onTrigger: a
        } = u) {
            if (t && i) {
                const e = t;
                t = (...t) => {
                    e(...t), _()
                }
            }
            const s = ci,
                c = e => !0 === o ? e : yr(e, !1 === o ? 1 : void 0);
            let d, p, h = !1,
                v = !1;
            if (Pt(e) ? (d = () => e.value, h = yt(e)) : bt(e) ? (d = () => c(e), h = !0) : x(e) ? (v = !0, h = e.some((e => bt(e) || yt(e))), d = () => e.map((e => Pt(e) ? e.value : bt(e) ? c(e) : S(e) ? jt(e, s, 2) : void 0))) : d = S(e) ? t ? () => jt(e, s, 2) : () => (p && p(), Nt(e, s, 3, [m])) : f, t && o) {
                const e = d;
                d = () => yr(e())
            }
            let g, m = e => {
                p = k.onStop = () => {
                    jt(e, s, 4), p = k.onStop = void 0
                }
            };
            if (mi) {
                if (m = f, t ? n && Nt(t, s, 3, [d(), v ? [] : void 0, m]) : d(), "sync" !== r) return f;
                {
                    const e = fr();
                    g = e.__watcherHandles || (e.__watcherHandles = [])
                }
            }
            let y = v ? new Array(e.length).fill(hr) : hr;
            const w = () => {
                if (k.active && k.dirty)
                    if (t) {
                        const e = k.run();
                        (o || h || (v ? e.some(((e, t) => N(e, y[t]))) : N(e, y))) && (p && p(), Nt(t, s, 3, [e, y === hr ? void 0 : v && y[0] === hr ? [] : y, m]), y = e)
                    } else k.run()
            };
            let C;
            w.allowRecurse = !!t, "sync" === r ? C = w : "post" === r ? C = () => or(w, s && s.suspense) : (w.pre = !0, s && (w.id = s.uid), C = () => Qt(w));
            const k = new de(d, f, C),
                $ = ae,
                _ = () => {
                    k.stop(), $ && b($.effects, k)
                };
            return t ? n ? w() : y = k.run() : "post" === r ? or(k.run.bind(k), s && s.suspense) : k.run(), g && g.push(_), _
        }

        function br(e, t, n) {
            const o = this.proxy,
                r = k(e) ? e.includes(".") ? mr(o, e) : () => o[e] : e.bind(o, o);
            let i;
            S(t) ? i = t : (i = t.handler, n = t);
            const l = pi(this),
                a = gr(r, i.bind(o), n);
            return l(), a
        }

        function mr(e, t) {
            const n = t.split(".");
            return () => {
                let t = e;
                for (let e = 0; e < n.length && t; e++) t = t[n[e]];
                return t
            }
        }

        function yr(e, t = 1 / 0, n) {
            if (t <= 0 || !_(e) || e.__v_skip) return e;
            if ((n = n || new Set).has(e)) return e;
            if (n.add(e), t--, Pt(e)) yr(e.value, t, n);
            else if (x(e))
                for (let o = 0; o < e.length; o++) yr(e[o], t, n);
            else if (C(e) || w(e)) e.forEach((e => {
                yr(e, t, n)
            }));
            else if (M(e)) {
                for (const o in e) yr(e[o], t, n);
                for (const o of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, o) && yr(e[o], t, n)
            }
            return e
        }
        const xr = (e, t) => "modelValue" === t || "model-value" === t ? e.modelModifiers : e[`${t}Modifiers`] || e[`${A(t)}Modifiers`] || e[`${D(t)}Modifiers`];

        function wr(e, t, ...n) {
            if (e.isUnmounted) return;
            const o = e.vnode.props || u;
            let r = n;
            const i = t.startsWith("update:"),
                l = i && xr(o, t.slice(7));
            let a;
            l && (l.trim && (r = n.map((e => k(e) ? e.trim() : e))), l.number && (r = n.map(V)));
            let s = o[a = j(t)] || o[a = j(A(t))];
            !s && i && (s = o[a = j(D(t))]), s && Nt(s, e, 6, r);
            const c = o[a + "Once"];
            if (c) {
                if (e.emitted) {
                    if (e.emitted[a]) return
                } else e.emitted = {};
                e.emitted[a] = !0, Nt(c, e, 6, r)
            }
        }

        function Cr(e, t, n = !1) {
            const o = t.emitsCache,
                r = o.get(e);
            if (void 0 !== r) return r;
            const i = e.emits;
            let l = {},
                a = !1;
            if (!S(e)) {
                const o = e => {
                    const n = Cr(e, t, !0);
                    n && (a = !0, g(l, n))
                };
                !n && t.mixins.length && t.mixins.forEach(o), e.extends && o(e.extends), e.mixins && e.mixins.forEach(o)
            }
            return i || a ? (x(i) ? i.forEach((e => l[e] = null)) : g(l, i), _(e) && o.set(e, l), l) : (_(e) && o.set(e, null), null)
        }

        function Sr(e, t) {
            return !(!e || !h(t)) && (t = t.slice(2).replace(/Once$/, ""), y(e, t[0].toLowerCase() + t.slice(1)) || y(e, D(t)) || y(e, t))
        }

        function kr(e) {
            const {
                type: t,
                vnode: n,
                proxy: o,
                withProxy: r,
                propsOptions: [i],
                slots: l,
                attrs: a,
                emit: s,
                render: c,
                renderCache: u,
                props: d,
                data: f,
                setupState: p,
                ctx: h,
                inheritAttrs: g
            } = e, b = un(e);
            let m, y;
            try {
                if (4 & n.shapeFlag) {
                    const e = r || o,
                        t = e;
                    m = ti(c.call(t, e, u, d, p, f, h)), y = a
                } else {
                    const e = t;
                    0, m = ti(e.length > 1 ? e(d, {
                        attrs: a,
                        slots: l,
                        emit: s
                    }) : e(d, null)), y = t.props ? a : $r(a)
                }
            } catch (t) {
                Br.length = 0, Ht(t, e, 1), m = Xr(Er)
            }
            let x = m;
            if (y && !1 !== g) {
                const e = Object.keys(y),
                    {
                        shapeFlag: t
                    } = x;
                e.length && 7 & t && (i && e.some(v) && (y = _r(y, i)), x = Jr(x, y, !1, !0))
            }
            return n.dirs && (x = Jr(x, null, !1, !0), x.dirs = x.dirs ? x.dirs.concat(n.dirs) : n.dirs), n.transition && (x.transition = n.transition), m = x, un(b), m
        }
        const $r = e => {
                let t;
                for (const n in e)("class" === n || "style" === n || h(n)) && ((t || (t = {}))[n] = e[n]);
                return t
            },
            _r = (e, t) => {
                const n = {};
                for (const o in e) v(o) && o.slice(9) in t || (n[o] = e[o]);
                return n
            };

        function zr(e, t, n) {
            const o = Object.keys(t);
            if (o.length !== Object.keys(e).length) return !0;
            for (let r = 0; r < o.length; r++) {
                const i = o[r];
                if (t[i] !== e[i] && !Sr(n, i)) return !0
            }
            return !1
        }

        function Tr({
            vnode: e,
            parent: t
        }, n) {
            for (; t;) {
                const o = t.subTree;
                if (o.suspense && o.suspense.activeBranch === e && (o.el = e.el), o !== e) break;
                (e = t.vnode).el = n, t = t.parent
            }
        }
        const Pr = e => e.__isSuspense;

        function Fr(e, t) {
            t && t.pendingBranch ? x(e) ? t.effects.push(...e) : t.effects.push(e) : tn(e)
        }
        const Mr = Symbol.for("v-fgt"),
            Rr = Symbol.for("v-txt"),
            Er = Symbol.for("v-cmt"),
            Or = Symbol.for("v-stc"),
            Br = [];
        let Ar = null;

        function Ir(e = !1) {
            Br.push(Ar = e ? null : [])
        }

        function Dr() {
            Br.pop(), Ar = Br[Br.length - 1] || null
        }
        let Lr = 1;

        function jr(e) {
            Lr += e, e < 0 && Ar && (Ar.hasOnce = !0)
        }

        function Nr(e) {
            return e.dynamicChildren = Lr > 0 ? Ar || d : null, Dr(), Lr > 0 && Ar && Ar.push(e), e
        }

        function Hr(e, t, n, o, r, i) {
            return Nr(Gr(e, t, n, o, r, i, !0))
        }

        function Wr(e, t, n, o, r) {
            return Nr(Xr(e, t, n, o, r, !0))
        }

        function Vr(e) {
            return !!e && !0 === e.__v_isVNode
        }

        function qr(e, t) {
            return e.type === t.type && e.key === t.key
        }
        const Ur = ({
                key: e
            }) => null != e ? e : null,
            Kr = ({
                ref: e,
                ref_key: t,
                ref_for: n
            }) => ("number" == typeof e && (e = "" + e), null != e ? k(e) || Pt(e) || S(e) ? {
                i: sn,
                r: e,
                k: t,
                f: !!n
            } : e : null);

        function Gr(e, t = null, n = null, o = 0, r = null, i = (e === Mr ? 0 : 1), l = !1, a = !1) {
            const s = {
                __v_isVNode: !0,
                __v_skip: !0,
                type: e,
                props: t,
                key: t && Ur(t),
                ref: t && Kr(t),
                scopeId: cn,
                slotScopeIds: null,
                children: n,
                component: null,
                suspense: null,
                ssContent: null,
                ssFallback: null,
                dirs: null,
                transition: null,
                el: null,
                anchor: null,
                target: null,
                targetStart: null,
                targetAnchor: null,
                staticCount: 0,
                shapeFlag: i,
                patchFlag: o,
                dynamicProps: r,
                dynamicChildren: null,
                appContext: null,
                ctx: sn
            };
            return a ? (oi(s, n), 128 & i && e.normalize(s)) : n && (s.shapeFlag |= k(n) ? 8 : 16), Lr > 0 && !l && Ar && (s.patchFlag > 0 || 6 & i) && 32 !== s.patchFlag && Ar.push(s), s
        }
        const Xr = Yr;

        function Yr(e, t = null, n = null, o = 0, r = null, i = !1) {
            if (e && e !== Zn || (e = Er), Vr(e)) {
                const o = Jr(e, t, !0);
                return n && oi(o, n), Lr > 0 && !i && Ar && (6 & o.shapeFlag ? Ar[Ar.indexOf(e)] = o : Ar.push(o)), o.patchFlag = -2, o
            }
            if (_i(e) && (e = e.__vccOpts), t) {
                t = Zr(t);
                let {
                    class: e,
                    style: n
                } = t;
                e && !k(e) && (t.class = Q(e)), _(n) && (xt(n) && !x(n) && (n = g({}, n)), t.style = G(n))
            }
            return Gr(e, t, n, o, r, k(e) ? 1 : Pr(e) ? 128 : (e => e.__isTeleport)(e) ? 64 : _(e) ? 4 : S(e) ? 2 : 0, i, !0)
        }

        function Zr(e) {
            return e ? xt(e) || Po(e) ? g({}, e) : e : null
        }

        function Jr(e, t, n = !1, o = !1) {
            const {
                props: r,
                ref: i,
                patchFlag: l,
                children: a,
                transition: s
            } = e, c = t ? ri(r || {}, t) : r, u = {
                __v_isVNode: !0,
                __v_skip: !0,
                type: e.type,
                props: c,
                key: c && Ur(c),
                ref: t && t.ref ? n && i ? x(i) ? i.concat(Kr(t)) : [i, Kr(t)] : Kr(t) : i,
                scopeId: e.scopeId,
                slotScopeIds: e.slotScopeIds,
                children: a,
                target: e.target,
                targetStart: e.targetStart,
                targetAnchor: e.targetAnchor,
                staticCount: e.staticCount,
                shapeFlag: e.shapeFlag,
                patchFlag: t && e.type !== Mr ? -1 === l ? 16 : 16 | l : l,
                dynamicProps: e.dynamicProps,
                dynamicChildren: e.dynamicChildren,
                appContext: e.appContext,
                dirs: e.dirs,
                transition: s,
                component: e.component,
                suspense: e.suspense,
                ssContent: e.ssContent && Jr(e.ssContent),
                ssFallback: e.ssFallback && Jr(e.ssFallback),
                el: e.el,
                anchor: e.anchor,
                ctx: e.ctx,
                ce: e.ce
            };
            return s && o && _n(u, s.clone(u)), u
        }

        function Qr(e = " ", t = 0) {
            return Xr(Rr, null, e, t)
        }

        function ei(e = "", t = !1) {
            return t ? (Ir(), Wr(Er, null, e)) : Xr(Er, null, e)
        }

        function ti(e) {
            return null == e || "boolean" == typeof e ? Xr(Er) : x(e) ? Xr(Mr, null, e.slice()) : "object" == typeof e ? ni(e) : Xr(Rr, null, String(e))
        }

        function ni(e) {
            return null === e.el && -1 !== e.patchFlag || e.memo ? e : Jr(e)
        }

        function oi(e, t) {
            let n = 0;
            const {
                shapeFlag: o
            } = e;
            if (null == t) t = null;
            else if (x(t)) n = 16;
            else if ("object" == typeof t) {
                if (65 & o) {
                    const n = t.default;
                    return void(n && (n._c && (n._d = !1), oi(e, n()), n._c && (n._d = !0)))
                } {
                    n = 32;
                    const o = t._;
                    o || Po(t) ? 3 === o && sn && (1 === sn.slots._ ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024)) : t._ctx = sn
                }
            } else S(t) ? (t = {
                default: t,
                _ctx: sn
            }, n = 32) : (t = String(t), 64 & o ? (n = 16, t = [Qr(t)]) : n = 8);
            e.children = t, e.shapeFlag |= n
        }

        function ri(...e) {
            const t = {};
            for (let n = 0; n < e.length; n++) {
                const o = e[n];
                for (const e in o)
                    if ("class" === e) t.class !== o.class && (t.class = Q([t.class, o.class]));
                    else if ("style" === e) t.style = G([t.style, o.style]);
                else if (h(e)) {
                    const n = t[e],
                        r = o[e];
                    !r || n === r || x(n) && n.includes(r) || (t[e] = n ? [].concat(n, r) : r)
                } else "" !== e && (t[e] = o[e])
            }
            return t
        }

        function ii(e, t, n, o = null) {
            Nt(e, t, 7, [n, o])
        }
        const li = wo();
        let ai = 0;

        function si(e, t, n) {
            const o = e.type,
                r = (t ? t.appContext : e.appContext) || li,
                i = {
                    uid: ai++,
                    vnode: e,
                    type: o,
                    parent: t,
                    appContext: r,
                    root: null,
                    next: null,
                    subTree: null,
                    effect: null,
                    update: null,
                    scope: new ce(!0),
                    render: null,
                    proxy: null,
                    exposed: null,
                    exposeProxy: null,
                    withProxy: null,
                    provides: t ? t.provides : Object.create(r.provides),
                    accessCache: null,
                    renderCache: [],
                    components: null,
                    directives: null,
                    propsOptions: Oo(o, r),
                    emitsOptions: Cr(o, r),
                    emit: null,
                    emitted: null,
                    propsDefaults: u,
                    inheritAttrs: o.inheritAttrs,
                    ctx: u,
                    data: u,
                    props: u,
                    attrs: u,
                    slots: u,
                    refs: u,
                    setupState: u,
                    setupContext: null,
                    attrsProxy: null,
                    slotsProxy: null,
                    suspense: n,
                    suspenseId: n ? n.pendingId : 0,
                    asyncDep: null,
                    asyncResolved: !1,
                    isMounted: !1,
                    isUnmounted: !1,
                    isDeactivated: !1,
                    bc: null,
                    c: null,
                    bm: null,
                    m: null,
                    bu: null,
                    u: null,
                    um: null,
                    bum: null,
                    da: null,
                    a: null,
                    rtg: null,
                    rtc: null,
                    ec: null,
                    sp: null
                };
            return i.ctx = {
                _: i
            }, i.root = t ? t.root : i, i.emit = wr.bind(null, i), e.ce && e.ce(i), i
        }
        let ci = null;
        const ui = () => ci || sn;
        let di, fi;
        {
            const e = K(),
                t = (t, n) => {
                    let o;
                    return (o = e[t]) || (o = e[t] = []), o.push(n), e => {
                        o.length > 1 ? o.forEach((t => t(e))) : o[0](e)
                    }
                };
            di = t("__VUE_INSTANCE_SETTERS__", (e => ci = e)), fi = t("__VUE_SSR_SETTERS__", (e => mi = e))
        }
        const pi = e => {
                const t = ci;
                return di(e), e.scope.on(), () => {
                    e.scope.off(), di(t)
                }
            },
            hi = () => {
                ci && ci.scope.off(), di(null)
            };

        function vi(e) {
            return 4 & e.vnode.shapeFlag
        }
        let gi, bi, mi = !1;

        function yi(e, t = !1, n = !1) {
            t && fi(t);
            const {
                props: o,
                children: r
            } = e.vnode, i = vi(e);
            Fo(e, o, i, t), qo(e, r, n);
            const l = i ? function(e, t) {
                const n = e.type;
                0;
                e.accessCache = Object.create(null), e.proxy = new Proxy(e.ctx, lo), !1;
                const {
                    setup: o
                } = n;
                if (o) {
                    const n = e.setupContext = o.length > 1 ? Si(e) : null,
                        r = pi(e);
                    ye();
                    const i = jt(o, e, 0, [e.props, n]);
                    if (xe(), r(), z(i)) {
                        if (i.then(hi, hi), t) return i.then((n => {
                            xi(e, n, t)
                        })).catch((t => {
                            Ht(t, e, 0)
                        }));
                        e.asyncDep = i
                    } else xi(e, i, t)
                } else wi(e, t)
            }(e, t) : void 0;
            return t && fi(!1), l
        }

        function xi(e, t, n) {
            S(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : _(t) && (e.setupState = Bt(t)), wi(e, n)
        }

        function wi(e, t, n) {
            const o = e.type;
            if (!e.render) {
                if (!t && gi && !o.render) {
                    const t = o.template || po(e).template;
                    if (t) {
                        0;
                        const {
                            isCustomElement: n,
                            compilerOptions: r
                        } = e.appContext.config, {
                            delimiters: i,
                            compilerOptions: l
                        } = o, a = g(g({
                            isCustomElement: n,
                            delimiters: i
                        }, r), l);
                        o.render = gi(t, a)
                    }
                }
                e.render = o.render || f, bi && bi(e)
            } {
                const t = pi(e);
                ye();
                try {
                    co(e)
                } finally {
                    xe(), t()
                }
            }
        }
        const Ci = {
            get(e, t) {
                return Fe(e, 0, ""), e[t]
            }
        };

        function Si(e) {
            const t = t => {
                e.exposed = t || {}
            };
            return {
                attrs: new Proxy(e.attrs, Ci),
                slots: e.slots,
                emit: e.emit,
                expose: t
            }
        }

        function ki(e) {
            return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(Bt(Ct(e.exposed)), {
                get(t, n) {
                    return n in t ? t[n] : n in ro ? ro[n](e) : void 0
                },
                has(e, t) {
                    return t in e || t in ro
                }
            })) : e.proxy
        }

        function $i(e, t = !0) {
            return S(e) ? e.displayName || e.name : e.name || t && e.__name
        }

        function _i(e) {
            return S(e) && "__vccOpts" in e
        }
        const zi = (e, t) => _t(e, 0, mi);

        function Ti(e, t, n) {
            const o = arguments.length;
            return 2 === o ? _(t) && !x(t) ? Vr(t) ? Xr(e, null, [t]) : Xr(e, t) : Xr(e, null, t) : (o > 3 ? n = Array.prototype.slice.call(arguments, 2) : 3 === o && Vr(n) && (n = [n]), Xr(e, t, n))
        }
        const Pi = "3.4.32",
            Fi = "undefined" != typeof document ? document : null,
            Mi = Fi && Fi.createElement("template"),
            Ri = {
                insert: (e, t, n) => {
                    t.insertBefore(e, n || null)
                },
                remove: e => {
                    const t = e.parentNode;
                    t && t.removeChild(e)
                },
                createElement: (e, t, n, o) => {
                    const r = "svg" === t ? Fi.createElementNS("http://www.w3.org/2000/svg", e) : "mathml" === t ? Fi.createElementNS("http://www.w3.org/1998/Math/MathML", e) : n ? Fi.createElement(e, {
                        is: n
                    }) : Fi.createElement(e);
                    return "select" === e && o && null != o.multiple && r.setAttribute("multiple", o.multiple), r
                },
                createText: e => Fi.createTextNode(e),
                createComment: e => Fi.createComment(e),
                setText: (e, t) => {
                    e.nodeValue = t
                },
                setElementText: (e, t) => {
                    e.textContent = t
                },
                parentNode: e => e.parentNode,
                nextSibling: e => e.nextSibling,
                querySelector: e => Fi.querySelector(e),
                setScopeId(e, t) {
                    e.setAttribute(t, "")
                },
                insertStaticContent(e, t, n, o, r, i) {
                    const l = n ? n.previousSibling : t.lastChild;
                    if (r && (r === i || r.nextSibling))
                        for (; t.insertBefore(r.cloneNode(!0), n), r !== i && (r = r.nextSibling););
                    else {
                        Mi.innerHTML = "svg" === o ? `<svg>${e}</svg>` : "mathml" === o ? `<math>${e}</math>` : e;
                        const r = Mi.content;
                        if ("svg" === o || "mathml" === o) {
                            const e = r.firstChild;
                            for (; e.firstChild;) r.appendChild(e.firstChild);
                            r.removeChild(e)
                        }
                        t.insertBefore(r, n)
                    }
                    return [l ? l.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
                }
            },
            Ei = "transition",
            Oi = "animation",
            Bi = Symbol("_vtc"),
            Ai = (e, {
                slots: t
            }) => Ti(wn, Ni(e), t);
        Ai.displayName = "Transition";
        const Ii = {
                name: String,
                type: String,
                css: {
                    type: Boolean,
                    default: !0
                },
                duration: [String, Number, Object],
                enterFromClass: String,
                enterActiveClass: String,
                enterToClass: String,
                appearFromClass: String,
                appearActiveClass: String,
                appearToClass: String,
                leaveFromClass: String,
                leaveActiveClass: String,
                leaveToClass: String
            },
            Di = Ai.props = g({}, mn, Ii),
            Li = (e, t = []) => {
                x(e) ? e.forEach((e => e(...t))) : e && e(...t)
            },
            ji = e => !!e && (x(e) ? e.some((e => e.length > 1)) : e.length > 1);

        function Ni(e) {
            const t = {};
            for (const n in e) n in Ii || (t[n] = e[n]);
            if (!1 === e.css) return t;
            const {
                name: n = "v",
                type: o,
                duration: r,
                enterFromClass: i = `${n}-enter-from`,
                enterActiveClass: l = `${n}-enter-active`,
                enterToClass: a = `${n}-enter-to`,
                appearFromClass: s = i,
                appearActiveClass: c = l,
                appearToClass: u = a,
                leaveFromClass: d = `${n}-leave-from`,
                leaveActiveClass: f = `${n}-leave-active`,
                leaveToClass: p = `${n}-leave-to`
            } = e, h = function(e) {
                if (null == e) return null;
                if (_(e)) return [Hi(e.enter), Hi(e.leave)];
                {
                    const t = Hi(e);
                    return [t, t]
                }
            }(r), v = h && h[0], b = h && h[1], {
                onBeforeEnter: m,
                onEnter: y,
                onEnterCancelled: x,
                onLeave: w,
                onLeaveCancelled: C,
                onBeforeAppear: S = m,
                onAppear: k = y,
                onAppearCancelled: $ = x
            } = t, z = (e, t, n) => {
                Vi(e, t ? u : a), Vi(e, t ? c : l), n && n()
            }, T = (e, t) => {
                e._isLeaving = !1, Vi(e, d), Vi(e, p), Vi(e, f), t && t()
            }, P = e => (t, n) => {
                const r = e ? k : y,
                    l = () => z(t, e, n);
                Li(r, [t, l]), qi((() => {
                    Vi(t, e ? s : i), Wi(t, e ? u : a), ji(r) || Ki(t, o, v, l)
                }))
            };
            return g(t, {
                onBeforeEnter(e) {
                    Li(m, [e]), Wi(e, i), Wi(e, l)
                },
                onBeforeAppear(e) {
                    Li(S, [e]), Wi(e, s), Wi(e, c)
                },
                onEnter: P(!1),
                onAppear: P(!0),
                onLeave(e, t) {
                    e._isLeaving = !0;
                    const n = () => T(e, t);
                    Wi(e, d), Wi(e, f), Zi(), qi((() => {
                        e._isLeaving && (Vi(e, d), Wi(e, p), ji(w) || Ki(e, o, b, n))
                    })), Li(w, [e, n])
                },
                onEnterCancelled(e) {
                    z(e, !1), Li(x, [e])
                },
                onAppearCancelled(e) {
                    z(e, !0), Li($, [e])
                },
                onLeaveCancelled(e) {
                    T(e), Li(C, [e])
                }
            })
        }

        function Hi(e) {
            return q(e)
        }

        function Wi(e, t) {
            t.split(/\s+/).forEach((t => t && e.classList.add(t))), (e[Bi] || (e[Bi] = new Set)).add(t)
        }

        function Vi(e, t) {
            t.split(/\s+/).forEach((t => t && e.classList.remove(t)));
            const n = e[Bi];
            n && (n.delete(t), n.size || (e[Bi] = void 0))
        }

        function qi(e) {
            requestAnimationFrame((() => {
                requestAnimationFrame(e)
            }))
        }
        let Ui = 0;

        function Ki(e, t, n, o) {
            const r = e._endId = ++Ui,
                i = () => {
                    r === e._endId && o()
                };
            if (n) return setTimeout(i, n);
            const {
                type: l,
                timeout: a,
                propCount: s
            } = Gi(e, t);
            if (!l) return o();
            const c = l + "end";
            let u = 0;
            const d = () => {
                    e.removeEventListener(c, f), i()
                },
                f = t => {
                    t.target === e && ++u >= s && d()
                };
            setTimeout((() => {
                u < s && d()
            }), a + 1), e.addEventListener(c, f)
        }

        function Gi(e, t) {
            const n = window.getComputedStyle(e),
                o = e => (n[e] || "").split(", "),
                r = o(`${Ei}Delay`),
                i = o(`${Ei}Duration`),
                l = Xi(r, i),
                a = o(`${Oi}Delay`),
                s = o(`${Oi}Duration`),
                c = Xi(a, s);
            let u = null,
                d = 0,
                f = 0;
            t === Ei ? l > 0 && (u = Ei, d = l, f = i.length) : t === Oi ? c > 0 && (u = Oi, d = c, f = s.length) : (d = Math.max(l, c), u = d > 0 ? l > c ? Ei : Oi : null, f = u ? u === Ei ? i.length : s.length : 0);
            return {
                type: u,
                timeout: d,
                propCount: f,
                hasTransform: u === Ei && /\b(transform|all)(,|$)/.test(o(`${Ei}Property`).toString())
            }
        }

        function Xi(e, t) {
            for (; e.length < t.length;) e = e.concat(e);
            return Math.max(...t.map(((t, n) => Yi(t) + Yi(e[n]))))
        }

        function Yi(e) {
            return "auto" === e ? 0 : 1e3 * Number(e.slice(0, -1).replace(",", "."))
        }

        function Zi() {
            return document.body.offsetHeight
        }
        const Ji = Symbol("_vod"),
            Qi = Symbol("_vsh"),
            el = {
                beforeMount(e, {
                    value: t
                }, {
                    transition: n
                }) {
                    e[Ji] = "none" === e.style.display ? "" : e.style.display, n && t ? n.beforeEnter(e) : tl(e, t)
                },
                mounted(e, {
                    value: t
                }, {
                    transition: n
                }) {
                    n && t && n.enter(e)
                },
                updated(e, {
                    value: t,
                    oldValue: n
                }, {
                    transition: o
                }) {
                    !t != !n && (o ? t ? (o.beforeEnter(e), tl(e, !0), o.enter(e)) : o.leave(e, (() => {
                        tl(e, !1)
                    })) : tl(e, t))
                },
                beforeUnmount(e, {
                    value: t
                }) {
                    tl(e, t)
                }
            };

        function tl(e, t) {
            e.style.display = t ? e[Ji] : "none", e[Qi] = !t
        }
        const nl = Symbol("");
        const ol = /(^|;)\s*display\s*:/;
        const rl = /\s*!important$/;

        function il(e, t, n) {
            if (x(n)) n.forEach((n => il(e, t, n)));
            else if (null == n && (n = ""), t.startsWith("--")) e.setProperty(t, n);
            else {
                const o = function(e, t) {
                    const n = al[t];
                    if (n) return n;
                    let o = A(t);
                    if ("filter" !== o && o in e) return al[t] = o;
                    o = L(o);
                    for (let n = 0; n < ll.length; n++) {
                        const r = ll[n] + o;
                        if (r in e) return al[t] = r
                    }
                    return t
                }(e, t);
                rl.test(n) ? e.setProperty(D(o), n.replace(rl, ""), "important") : e[o] = n
            }
        }
        const ll = ["Webkit", "Moz", "ms"],
            al = {};
        const sl = "http://www.w3.org/1999/xlink";

        function cl(e, t, n, o, r, i = te(t)) {
            o && t.startsWith("xlink:") ? null == n ? e.removeAttributeNS(sl, t.slice(6, t.length)) : e.setAttributeNS(sl, t, n) : null == n || i && !ne(n) ? e.removeAttribute(t) : e.setAttribute(t, i ? "" : $(n) ? String(n) : n)
        }

        function ul(e, t, n, o) {
            e.addEventListener(t, n, o)
        }
        const dl = Symbol("_vei");

        function fl(e, t, n, o, r = null) {
            const i = e[dl] || (e[dl] = {}),
                l = i[t];
            if (o && l) l.value = o;
            else {
                const [n, a] = function(e) {
                    let t;
                    if (pl.test(e)) {
                        let n;
                        for (t = {}; n = e.match(pl);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0
                    }
                    const n = ":" === e[2] ? e.slice(3) : D(e.slice(2));
                    return [n, t]
                }(t);
                if (o) {
                    const l = i[t] = function(e, t) {
                        const n = e => {
                            if (e._vts) {
                                if (e._vts <= n.attached) return
                            } else e._vts = Date.now();
                            Nt(function(e, t) {
                                if (x(t)) {
                                    const n = e.stopImmediatePropagation;
                                    return e.stopImmediatePropagation = () => {
                                        n.call(e), e._stopped = !0
                                    }, t.map((e => t => !t._stopped && e && e(t)))
                                }
                                return t
                            }(e, n.value), t, 5, [e])
                        };
                        return n.value = e, n.attached = gl(), n
                    }(o, r);
                    ul(e, n, l, a)
                } else l && (! function(e, t, n, o) {
                    e.removeEventListener(t, n, o)
                }(e, n, l, a), i[t] = void 0)
            }
        }
        const pl = /(?:Once|Passive|Capture)$/;
        let hl = 0;
        const vl = Promise.resolve(),
            gl = () => hl || (vl.then((() => hl = 0)), hl = Date.now());
        const bl = e => 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123;
        "undefined" != typeof HTMLElement && HTMLElement;
        const ml = new WeakMap,
            yl = new WeakMap,
            xl = Symbol("_moveCb"),
            wl = Symbol("_enterCb"),
            Cl = {
                name: "TransitionGroup",
                props: g({}, Di, {
                    tag: String,
                    moveClass: String
                }),
                setup(e, {
                    slots: t
                }) {
                    const n = ui(),
                        o = gn();
                    let r, i;
                    return Wn((() => {
                        if (!r.length) return;
                        const t = e.moveClass || `${e.name||"v"}-move`;
                        if (! function(e, t, n) {
                                const o = e.cloneNode(),
                                    r = e[Bi];
                                r && r.forEach((e => {
                                    e.split(/\s+/).forEach((e => e && o.classList.remove(e)))
                                }));
                                n.split(/\s+/).forEach((e => e && o.classList.add(e))), o.style.display = "none";
                                const i = 1 === t.nodeType ? t : t.parentNode;
                                i.appendChild(o);
                                const {
                                    hasTransform: l
                                } = Gi(o);
                                return i.removeChild(o), l
                            }(r[0].el, n.vnode.el, t)) return;
                        r.forEach(kl), r.forEach($l);
                        const o = r.filter(_l);
                        Zi(), o.forEach((e => {
                            const n = e.el,
                                o = n.style;
                            Wi(n, t), o.transform = o.webkitTransform = o.transitionDuration = "";
                            const r = n[xl] = e => {
                                e && e.target !== n || e && !/transform$/.test(e.propertyName) || (n.removeEventListener("transitionend", r), n[xl] = null, Vi(n, t))
                            };
                            n.addEventListener("transitionend", r)
                        }))
                    })), () => {
                        const l = wt(e),
                            a = Ni(l);
                        let s = l.tag || Mr;
                        if (r = [], i)
                            for (let e = 0; e < i.length; e++) {
                                const t = i[e];
                                t.el && t.el instanceof Element && (r.push(t), _n(t, Sn(t, a, o, n)), ml.set(t, t.el.getBoundingClientRect()))
                            }
                        i = t.default ? zn(t.default()) : [];
                        for (let e = 0; e < i.length; e++) {
                            const t = i[e];
                            null != t.key && _n(t, Sn(t, a, o, n))
                        }
                        return Xr(s, null, i)
                    }
                }
            },
            Sl = Cl;

        function kl(e) {
            const t = e.el;
            t[xl] && t[xl](), t[wl] && t[wl]()
        }

        function $l(e) {
            yl.set(e, e.el.getBoundingClientRect())
        }

        function _l(e) {
            const t = ml.get(e),
                n = yl.get(e),
                o = t.left - n.left,
                r = t.top - n.top;
            if (o || r) {
                const t = e.el.style;
                return t.transform = t.webkitTransform = `translate(${o}px,${r}px)`, t.transitionDuration = "0s", e
            }
        }
        Symbol("_assign");
        const zl = ["ctrl", "shift", "alt", "meta"],
            Tl = {
                stop: e => e.stopPropagation(),
                prevent: e => e.preventDefault(),
                self: e => e.target !== e.currentTarget,
                ctrl: e => !e.ctrlKey,
                shift: e => !e.shiftKey,
                alt: e => !e.altKey,
                meta: e => !e.metaKey,
                left: e => "button" in e && 0 !== e.button,
                middle: e => "button" in e && 1 !== e.button,
                right: e => "button" in e && 2 !== e.button,
                exact: (e, t) => zl.some((n => e[`${n}Key`] && !t.includes(n)))
            },
            Pl = (e, t) => {
                const n = e._withMods || (e._withMods = {}),
                    o = t.join(".");
                return n[o] || (n[o] = (n, ...o) => {
                    for (let e = 0; e < t.length; e++) {
                        const o = Tl[t[e]];
                        if (o && o(n, t)) return
                    }
                    return e(n, ...o)
                })
            },
            Fl = {
                esc: "escape",
                space: " ",
                up: "arrow-up",
                left: "arrow-left",
                right: "arrow-right",
                down: "arrow-down",
                delete: "backspace"
            },
            Ml = (e, t) => {
                const n = e._withKeys || (e._withKeys = {}),
                    o = t.join(".");
                return n[o] || (n[o] = n => {
                    if (!("key" in n)) return;
                    const o = D(n.key);
                    return t.some((e => e === o || Fl[e] === o)) ? e(n) : void 0
                })
            },
            Rl = g({
                patchProp: (e, t, n, o, r, i) => {
                    const l = "svg" === r;
                    "class" === t ? function(e, t, n) {
                        const o = e[Bi];
                        o && (t = (t ? [t, ...o] : [...o]).join(" ")), null == t ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
                    }(e, o, l) : "style" === t ? function(e, t, n) {
                        const o = e.style,
                            r = k(n);
                        let i = !1;
                        if (n && !r) {
                            if (t)
                                if (k(t))
                                    for (const e of t.split(";")) {
                                        const t = e.slice(0, e.indexOf(":")).trim();
                                        null == n[t] && il(o, t, "")
                                    } else
                                        for (const e in t) null == n[e] && il(o, e, "");
                            for (const e in n) "display" === e && (i = !0), il(o, e, n[e])
                        } else if (r) {
                            if (t !== n) {
                                const e = o[nl];
                                e && (n += ";" + e), o.cssText = n, i = ol.test(n)
                            }
                        } else t && e.removeAttribute("style");
                        Ji in e && (e[Ji] = i ? o.display : "", e[Qi] && (o.display = "none"))
                    }(e, n, o) : h(t) ? v(t) || fl(e, t, 0, o, i) : ("." === t[0] ? (t = t.slice(1), 1) : "^" === t[0] ? (t = t.slice(1), 0) : function(e, t, n, o) {
                        if (o) return "innerHTML" === t || "textContent" === t || !!(t in e && bl(t) && S(n));
                        if ("spellcheck" === t || "draggable" === t || "translate" === t) return !1;
                        if ("form" === t) return !1;
                        if ("list" === t && "INPUT" === e.tagName) return !1;
                        if ("type" === t && "TEXTAREA" === e.tagName) return !1;
                        if ("width" === t || "height" === t) {
                            const t = e.tagName;
                            if ("IMG" === t || "VIDEO" === t || "CANVAS" === t || "SOURCE" === t) return !1
                        }
                        if (bl(t) && k(n)) return !1;
                        return t in e
                    }(e, t, o, l)) ? (! function(e, t, n) {
                        if ("innerHTML" === t || "textContent" === t) {
                            if (null === n) return;
                            return void(e[t] = n)
                        }
                        const o = e.tagName;
                        if ("value" === t && "PROGRESS" !== o && !o.includes("-")) {
                            const r = "OPTION" === o ? e.getAttribute("value") || "" : e.value,
                                i = null == n ? "" : String(n);
                            return r === i && "_value" in e || (e.value = i), null == n && e.removeAttribute(t), void(e._value = n)
                        }
                        let r = !1;
                        if ("" === n || null == n) {
                            const o = typeof e[t];
                            "boolean" === o ? n = ne(n) : null == n && "string" === o ? (n = "", r = !0) : "number" === o && (n = 0, r = !0)
                        }
                        try {
                            e[t] = n
                        } catch (e) {}
                        r && e.removeAttribute(t)
                    }(e, t, o), e.tagName.includes("-") || "value" !== t && "checked" !== t && "selected" !== t || cl(e, t, o, l, 0, "value" !== t)) : ("true-value" === t ? e._trueValue = o : "false-value" === t && (e._falseValue = o), cl(e, t, o, l))
                }
            }, Ri);
        let El;

        function Ol() {
            return El || (El = rr(Rl))
        }

        function Bl(e) {
            return e instanceof SVGElement ? "svg" : "function" == typeof MathMLElement && e instanceof MathMLElement ? "mathml" : void 0
        }

        function Al(e) {
            if (k(e)) {
                return document.querySelector(e)
            }
            return e
        }
        var Il = function(e) {
            const t = zi(e),
                n = Ft(t.value);
            return vr(t, (e => {
                n.value = e
            })), "function" == typeof e ? n : {
                __v_isRef: !0,
                get value() {
                    return n.value
                },
                set value(t) {
                    e.set(t)
                }
            }
        };
        var Dl = function() {
            this.__data__ = [], this.size = 0
        };
        var Ll = function(e, t) {
            return e === t || e != e && t != t
        };
        var jl = function(e, t) {
                for (var n = e.length; n--;)
                    if (Ll(e[n][0], t)) return n;
                return -1
            },
            Nl = Array.prototype.splice;
        var Hl = function(e) {
            var t = this.__data__,
                n = jl(t, e);
            return !(n < 0) && (n == t.length - 1 ? t.pop() : Nl.call(t, n, 1), --this.size, !0)
        };
        var Wl = function(e) {
            var t = this.__data__,
                n = jl(t, e);
            return n < 0 ? void 0 : t[n][1]
        };
        var Vl = function(e) {
            return jl(this.__data__, e) > -1
        };
        var ql = function(e, t) {
            var n = this.__data__,
                o = jl(n, e);
            return o < 0 ? (++this.size, n.push([e, t])) : n[o][1] = t, this
        };

        function Ul(e) {
            var t = -1,
                n = null == e ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }
        Ul.prototype.clear = Dl, Ul.prototype.delete = Hl, Ul.prototype.get = Wl, Ul.prototype.has = Vl, Ul.prototype.set = ql;
        var Kl = Ul;
        var Gl = function() {
            this.__data__ = new Kl, this.size = 0
        };
        var Xl = function(e) {
            var t = this.__data__,
                n = t.delete(e);
            return this.size = t.size, n
        };
        var Yl = function(e) {
            return this.__data__.get(e)
        };
        var Zl = function(e) {
                return this.__data__.has(e)
            },
            Jl = "object" == typeof global && global && global.Object === Object && global,
            Ql = "object" == typeof self && self && self.Object === Object && self,
            ea = Jl || Ql || Function("return this")(),
            ta = ea.Symbol,
            na = Object.prototype,
            oa = na.hasOwnProperty,
            ra = na.toString,
            ia = ta ? ta.toStringTag : void 0;
        var la = function(e) {
                var t = oa.call(e, ia),
                    n = e[ia];
                try {
                    e[ia] = void 0;
                    var o = !0
                } catch (e) {}
                var r = ra.call(e);
                return o && (t ? e[ia] = n : delete e[ia]), r
            },
            aa = Object.prototype.toString;
        var sa = function(e) {
                return aa.call(e)
            },
            ca = ta ? ta.toStringTag : void 0;
        var ua = function(e) {
            return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : ca && ca in Object(e) ? la(e) : sa(e)
        };
        var da = function(e) {
            var t = typeof e;
            return null != e && ("object" == t || "function" == t)
        };
        var fa = function(e) {
                if (!da(e)) return !1;
                var t = ua(e);
                return "[object Function]" == t || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t
            },
            pa = ea["__core-js_shared__"],
            ha = function() {
                var e = /[^.]+$/.exec(pa && pa.keys && pa.keys.IE_PROTO || "");
                return e ? "Symbol(src)_1." + e : ""
            }();
        var va = function(e) {
                return !!ha && ha in e
            },
            ga = Function.prototype.toString;
        var ba = function(e) {
                if (null != e) {
                    try {
                        return ga.call(e)
                    } catch (e) {}
                    try {
                        return e + ""
                    } catch (e) {}
                }
                return ""
            },
            ma = /^\[object .+?Constructor\]$/,
            ya = Function.prototype,
            xa = Object.prototype,
            wa = ya.toString,
            Ca = xa.hasOwnProperty,
            Sa = RegExp("^" + wa.call(Ca).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
        var ka = function(e) {
            return !(!da(e) || va(e)) && (fa(e) ? Sa : ma).test(ba(e))
        };
        var $a = function(e, t) {
            return null == e ? void 0 : e[t]
        };
        var _a = function(e, t) {
                var n = $a(e, t);
                return ka(n) ? n : void 0
            },
            za = _a(ea, "Map"),
            Ta = _a(Object, "create");
        var Pa = function() {
            this.__data__ = Ta ? Ta(null) : {}, this.size = 0
        };
        var Fa = function(e) {
                var t = this.has(e) && delete this.__data__[e];
                return this.size -= t ? 1 : 0, t
            },
            Ma = Object.prototype.hasOwnProperty;
        var Ra = function(e) {
                var t = this.__data__;
                if (Ta) {
                    var n = t[e];
                    return "__lodash_hash_undefined__" === n ? void 0 : n
                }
                return Ma.call(t, e) ? t[e] : void 0
            },
            Ea = Object.prototype.hasOwnProperty;
        var Oa = function(e) {
            var t = this.__data__;
            return Ta ? void 0 !== t[e] : Ea.call(t, e)
        };
        var Ba = function(e, t) {
            var n = this.__data__;
            return this.size += this.has(e) ? 0 : 1, n[e] = Ta && void 0 === t ? "__lodash_hash_undefined__" : t, this
        };

        function Aa(e) {
            var t = -1,
                n = null == e ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }
        Aa.prototype.clear = Pa, Aa.prototype.delete = Fa, Aa.prototype.get = Ra, Aa.prototype.has = Oa, Aa.prototype.set = Ba;
        var Ia = Aa;
        var Da = function() {
            this.size = 0, this.__data__ = {
                hash: new Ia,
                map: new(za || Kl),
                string: new Ia
            }
        };
        var La = function(e) {
            var t = typeof e;
            return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e
        };
        var ja = function(e, t) {
            var n = e.__data__;
            return La(t) ? n["string" == typeof t ? "string" : "hash"] : n.map
        };
        var Na = function(e) {
            var t = ja(this, e).delete(e);
            return this.size -= t ? 1 : 0, t
        };
        var Ha = function(e) {
            return ja(this, e).get(e)
        };
        var Wa = function(e) {
            return ja(this, e).has(e)
        };
        var Va = function(e, t) {
            var n = ja(this, e),
                o = n.size;
            return n.set(e, t), this.size += n.size == o ? 0 : 1, this
        };

        function qa(e) {
            var t = -1,
                n = null == e ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }
        qa.prototype.clear = Da, qa.prototype.delete = Na, qa.prototype.get = Ha, qa.prototype.has = Wa, qa.prototype.set = Va;
        var Ua = qa;
        var Ka = function(e, t) {
            var n = this.__data__;
            if (n instanceof Kl) {
                var o = n.__data__;
                if (!za || o.length < 199) return o.push([e, t]), this.size = ++n.size, this;
                n = this.__data__ = new Ua(o)
            }
            return n.set(e, t), this.size = n.size, this
        };

        function Ga(e) {
            var t = this.__data__ = new Kl(e);
            this.size = t.size
        }
        Ga.prototype.clear = Gl, Ga.prototype.delete = Xl, Ga.prototype.get = Yl, Ga.prototype.has = Zl, Ga.prototype.set = Ka;
        var Xa = Ga,
            Ya = function() {
                try {
                    var e = _a(Object, "defineProperty");
                    return e({}, "", {}), e
                } catch (e) {}
            }();
        var Za = function(e, t, n) {
            "__proto__" == t && Ya ? Ya(e, t, {
                configurable: !0,
                enumerable: !0,
                value: n,
                writable: !0
            }) : e[t] = n
        };
        var Ja = function(e, t, n) {
            (void 0 !== n && !Ll(e[t], n) || void 0 === n && !(t in e)) && Za(e, t, n)
        };
        var Qa = function(e) {
                return function(t, n, o) {
                    for (var r = -1, i = Object(t), l = o(t), a = l.length; a--;) {
                        var s = l[e ? a : ++r];
                        if (!1 === n(i[s], s, i)) break
                    }
                    return t
                }
            },
            es = Qa(),
            ts = "object" == typeof exports && exports && !exports.nodeType && exports,
            ns = ts && "object" == typeof module && module && !module.nodeType && module,
            os = ns && ns.exports === ts ? ea.Buffer : void 0,
            rs = os ? os.allocUnsafe : void 0;
        var is = function(e, t) {
                if (t) return e.slice();
                var n = e.length,
                    o = rs ? rs(n) : new e.constructor(n);
                return e.copy(o), o
            },
            ls = ea.Uint8Array;
        var as = function(e) {
            var t = new e.constructor(e.byteLength);
            return new ls(t).set(new ls(e)), t
        };
        var ss = function(e, t) {
            var n = t ? as(e.buffer) : e.buffer;
            return new e.constructor(n, e.byteOffset, e.length)
        };
        var cs = function(e, t) {
                var n = -1,
                    o = e.length;
                for (t || (t = Array(o)); ++n < o;) t[n] = e[n];
                return t
            },
            us = Object.create,
            ds = function() {
                function e() {}
                return function(t) {
                    if (!da(t)) return {};
                    if (us) return us(t);
                    e.prototype = t;
                    var n = new e;
                    return e.prototype = void 0, n
                }
            }();
        var fs = function(e, t) {
                return function(n) {
                    return e(t(n))
                }
            },
            ps = fs(Object.getPrototypeOf, Object),
            hs = Object.prototype;
        var vs = function(e) {
            var t = e && e.constructor;
            return e === ("function" == typeof t && t.prototype || hs)
        };
        var gs = function(e) {
            return "function" != typeof e.constructor || vs(e) ? {} : ds(ps(e))
        };
        var bs = function(e) {
            return null != e && "object" == typeof e
        };
        var ms = function(e) {
                return bs(e) && "[object Arguments]" == ua(e)
            },
            ys = Object.prototype,
            xs = ys.hasOwnProperty,
            ws = ys.propertyIsEnumerable,
            Cs = ms(function() {
                return arguments
            }()) ? ms : function(e) {
                return bs(e) && xs.call(e, "callee") && !ws.call(e, "callee")
            },
            Ss = Cs,
            ks = Array.isArray;
        var $s = function(e) {
            return "number" == typeof e && e > -1 && e % 1 == 0 && e <= 9007199254740991
        };
        var _s = function(e) {
            return null != e && $s(e.length) && !fa(e)
        };
        var zs = function(e) {
            return bs(e) && _s(e)
        };
        var Ts = function() {
                return !1
            },
            Ps = "object" == typeof exports && exports && !exports.nodeType && exports,
            Fs = Ps && "object" == typeof module && module && !module.nodeType && module,
            Ms = Fs && Fs.exports === Ps ? ea.Buffer : void 0,
            Rs = (Ms ? Ms.isBuffer : void 0) || Ts,
            Es = Function.prototype,
            Os = Object.prototype,
            Bs = Es.toString,
            As = Os.hasOwnProperty,
            Is = Bs.call(Object);
        var Ds = function(e) {
                if (!bs(e) || "[object Object]" != ua(e)) return !1;
                var t = ps(e);
                if (null === t) return !0;
                var n = As.call(t, "constructor") && t.constructor;
                return "function" == typeof n && n instanceof n && Bs.call(n) == Is
            },
            Ls = {};
        Ls["[object Float32Array]"] = Ls["[object Float64Array]"] = Ls["[object Int8Array]"] = Ls["[object Int16Array]"] = Ls["[object Int32Array]"] = Ls["[object Uint8Array]"] = Ls["[object Uint8ClampedArray]"] = Ls["[object Uint16Array]"] = Ls["[object Uint32Array]"] = !0, Ls["[object Arguments]"] = Ls["[object Array]"] = Ls["[object ArrayBuffer]"] = Ls["[object Boolean]"] = Ls["[object DataView]"] = Ls["[object Date]"] = Ls["[object Error]"] = Ls["[object Function]"] = Ls["[object Map]"] = Ls["[object Number]"] = Ls["[object Object]"] = Ls["[object RegExp]"] = Ls["[object Set]"] = Ls["[object String]"] = Ls["[object WeakMap]"] = !1;
        var js = function(e) {
            return bs(e) && $s(e.length) && !!Ls[ua(e)]
        };
        var Ns = function(e) {
                return function(t) {
                    return e(t)
                }
            },
            Hs = "object" == typeof exports && exports && !exports.nodeType && exports,
            Ws = Hs && "object" == typeof module && module && !module.nodeType && module,
            Vs = Ws && Ws.exports === Hs && Jl.process,
            qs = function() {
                try {
                    var e = Ws && Ws.require && Ws.require("util").types;
                    return e || Vs && Vs.binding && Vs.binding("util")
                } catch (e) {}
            }(),
            Us = qs && qs.isTypedArray,
            Ks = Us ? Ns(Us) : js;
        var Gs = function(e, t) {
                if (("constructor" !== t || "function" != typeof e[t]) && "__proto__" != t) return e[t]
            },
            Xs = Object.prototype.hasOwnProperty;
        var Ys = function(e, t, n) {
            var o = e[t];
            Xs.call(e, t) && Ll(o, n) && (void 0 !== n || t in e) || Za(e, t, n)
        };
        var Zs = function(e, t, n, o) {
            var r = !n;
            n || (n = {});
            for (var i = -1, l = t.length; ++i < l;) {
                var a = t[i],
                    s = o ? o(n[a], e[a], a, n, e) : void 0;
                void 0 === s && (s = e[a]), r ? Za(n, a, s) : Ys(n, a, s)
            }
            return n
        };
        var Js = function(e, t) {
                for (var n = -1, o = Array(e); ++n < e;) o[n] = t(n);
                return o
            },
            Qs = /^(?:0|[1-9]\d*)$/;
        var ec = function(e, t) {
                var n = typeof e;
                return !!(t = null == t ? 9007199254740991 : t) && ("number" == n || "symbol" != n && Qs.test(e)) && e > -1 && e % 1 == 0 && e < t
            },
            tc = Object.prototype.hasOwnProperty;
        var nc = function(e, t) {
            var n = ks(e),
                o = !n && Ss(e),
                r = !n && !o && Rs(e),
                i = !n && !o && !r && Ks(e),
                l = n || o || r || i,
                a = l ? Js(e.length, String) : [],
                s = a.length;
            for (var c in e) !t && !tc.call(e, c) || l && ("length" == c || r && ("offset" == c || "parent" == c) || i && ("buffer" == c || "byteLength" == c || "byteOffset" == c) || ec(c, s)) || a.push(c);
            return a
        };
        var oc = function(e) {
                var t = [];
                if (null != e)
                    for (var n in Object(e)) t.push(n);
                return t
            },
            rc = Object.prototype.hasOwnProperty;
        var ic = function(e) {
            if (!da(e)) return oc(e);
            var t = vs(e),
                n = [];
            for (var o in e)("constructor" != o || !t && rc.call(e, o)) && n.push(o);
            return n
        };
        var lc = function(e) {
            return _s(e) ? nc(e, !0) : ic(e)
        };
        var ac = function(e) {
            return Zs(e, lc(e))
        };
        var sc = function(e, t, n, o, r, i, l) {
            var a = Gs(e, n),
                s = Gs(t, n),
                c = l.get(s);
            if (c) Ja(e, n, c);
            else {
                var u = i ? i(a, s, n + "", e, t, l) : void 0,
                    d = void 0 === u;
                if (d) {
                    var f = ks(s),
                        p = !f && Rs(s),
                        h = !f && !p && Ks(s);
                    u = s, f || p || h ? ks(a) ? u = a : zs(a) ? u = cs(a) : p ? (d = !1, u = is(s, !0)) : h ? (d = !1, u = ss(s, !0)) : u = [] : Ds(s) || Ss(s) ? (u = a, Ss(a) ? u = ac(a) : da(a) && !fa(a) || (u = gs(s))) : d = !1
                }
                d && (l.set(s, u), r(u, s, o, i, l), l.delete(s)), Ja(e, n, u)
            }
        };
        var cc = function e(t, n, o, r, i) {
            t !== n && es(n, (function(l, a) {
                if (i || (i = new Xa), da(l)) sc(t, n, a, o, e, r, i);
                else {
                    var s = r ? r(Gs(t, a), l, a + "", t, n, i) : void 0;
                    void 0 === s && (s = l), Ja(t, a, s)
                }
            }), lc)
        };
        var uc = function(e) {
            return e
        };
        var dc = function(e, t, n) {
                switch (n.length) {
                    case 0:
                        return e.call(t);
                    case 1:
                        return e.call(t, n[0]);
                    case 2:
                        return e.call(t, n[0], n[1]);
                    case 3:
                        return e.call(t, n[0], n[1], n[2])
                }
                return e.apply(t, n)
            },
            fc = Math.max;
        var pc = function(e, t, n) {
            return t = fc(void 0 === t ? e.length - 1 : t, 0),
                function() {
                    for (var o = arguments, r = -1, i = fc(o.length - t, 0), l = Array(i); ++r < i;) l[r] = o[t + r];
                    r = -1;
                    for (var a = Array(t + 1); ++r < t;) a[r] = o[r];
                    return a[t] = n(l), dc(e, this, a)
                }
        };
        var hc = function(e) {
                return function() {
                    return e
                }
            },
            vc = Ya ? function(e, t) {
                return Ya(e, "toString", {
                    configurable: !0,
                    enumerable: !1,
                    value: hc(t),
                    writable: !0
                })
            } : uc,
            gc = Date.now;
        var bc = function(e) {
                var t = 0,
                    n = 0;
                return function() {
                    var o = gc(),
                        r = 16 - (o - n);
                    if (n = o, r > 0) {
                        if (++t >= 800) return arguments[0]
                    } else t = 0;
                    return e.apply(void 0, arguments)
                }
            },
            mc = bc(vc);
        var yc = function(e, t) {
            return mc(pc(e, t, uc), e + "")
        };
        var xc = function(e, t, n) {
            if (!da(n)) return !1;
            var o = typeof t;
            return !!("number" == o ? _s(n) && ec(t, n.length) : "string" == o && t in n) && Ll(n[t], e)
        };
        var wc = function(e) {
                return yc((function(t, n) {
                    var o = -1,
                        r = n.length,
                        i = r > 1 ? n[r - 1] : void 0,
                        l = r > 2 ? n[2] : void 0;
                    for (i = e.length > 3 && "function" == typeof i ? (r--, i) : void 0, l && xc(n[0], n[1], l) && (i = r < 3 ? void 0 : i, r = 1), t = Object(t); ++o < r;) {
                        var a = n[o];
                        a && e(t, a, o, i)
                    }
                    return t
                }))
            },
            Cc = wc((function(e, t, n) {
                cc(e, t, n)
            }));
        var Sc = function(e) {
            for (var t, n = 0, o = 0, r = e.length; r >= 4; ++o, r -= 4) t = 1540483477 * (65535 & (t = 255 & e.charCodeAt(o) | (255 & e.charCodeAt(++o)) << 8 | (255 & e.charCodeAt(++o)) << 16 | (255 & e.charCodeAt(++o)) << 24)) + (59797 * (t >>> 16) << 16), n = 1540483477 * (65535 & (t ^= t >>> 24)) + (59797 * (t >>> 16) << 16) ^ 1540483477 * (65535 & n) + (59797 * (n >>> 16) << 16);
            switch (r) {
                case 3:
                    n ^= (255 & e.charCodeAt(o + 2)) << 16;
                case 2:
                    n ^= (255 & e.charCodeAt(o + 1)) << 8;
                case 1:
                    n = 1540483477 * (65535 & (n ^= 255 & e.charCodeAt(o))) + (59797 * (n >>> 16) << 16)
            }
            return (((n = 1540483477 * (65535 & (n ^= n >>> 13)) + (59797 * (n >>> 16) << 16)) ^ n >>> 15) >>> 0).toString(36)
        };
        new Set;

        function kc(e, t) {
            throw new Error(`[naive/${e}]: ${t}`)
        }
        const $c = "n-config-provider",
            _c = "n";

        function zc(e = {}, t = {
            defaultBordered: !0
        }) {
            const n = _o($c, null);
            return {
                inlineThemeDisabled: null == n ? void 0 : n.inlineThemeDisabled,
                mergedRtlRef: null == n ? void 0 : n.mergedRtlRef,
                mergedComponentPropsRef: null == n ? void 0 : n.mergedComponentPropsRef,
                mergedBreakpointsRef: null == n ? void 0 : n.mergedBreakpointsRef,
                mergedBorderedRef: zi((() => {
                    var o, r;
                    const {
                        bordered: i
                    } = e;
                    return void 0 !== i ? i : null === (r = null !== (o = null == n ? void 0 : n.mergedBorderedRef.value) && void 0 !== o ? o : t.defaultBordered) || void 0 === r || r
                })),
                mergedClsPrefixRef: n ? n.mergedClsPrefixRef : (o = _c, Mt(o, !0)),
                namespaceRef: zi((() => null == n ? void 0 : n.mergedNamespaceRef.value))
            };
            var o
        }
        var Tc = Tn({
                name: "ConfigProvider",
                alias: ["App"],
                props: {
                    abstract: Boolean,
                    bordered: {
                        type: Boolean,
                        default: void 0
                    },
                    clsPrefix: {
                        type: String,
                        default: _c
                    },
                    locale: Object,
                    dateLocale: Object,
                    namespace: String,
                    rtl: Array,
                    tag: {
                        type: String,
                        default: "div"
                    },
                    hljs: Object,
                    katex: Object,
                    theme: Object,
                    themeOverrides: Object,
                    componentOptions: Object,
                    icons: Object,
                    breakpoints: Object,
                    preflightStyleDisabled: Boolean,
                    inlineThemeDisabled: {
                        type: Boolean,
                        default: void 0
                    },
                    as: {
                        type: String,
                        validator: () => !0,
                        default: void 0
                    }
                },
                setup(e) {
                    const t = _o($c, null),
                        n = zi((() => {
                            const {
                                theme: n
                            } = e;
                            if (null === n) return;
                            const o = null == t ? void 0 : t.mergedThemeRef.value;
                            return void 0 === n ? o : void 0 === o ? n : Object.assign({}, o, n)
                        })),
                        o = zi((() => {
                            const {
                                themeOverrides: n
                            } = e;
                            if (null !== n) {
                                if (void 0 === n) return null == t ? void 0 : t.mergedThemeOverridesRef.value;
                                {
                                    const e = null == t ? void 0 : t.mergedThemeOverridesRef.value;
                                    return void 0 === e ? n : Cc({}, e, n)
                                }
                            }
                        })),
                        r = Il((() => {
                            const {
                                namespace: n
                            } = e;
                            return void 0 === n ? null == t ? void 0 : t.mergedNamespaceRef.value : n
                        })),
                        i = Il((() => {
                            const {
                                bordered: n
                            } = e;
                            return void 0 === n ? null == t ? void 0 : t.mergedBorderedRef.value : n
                        })),
                        l = zi((() => {
                            const {
                                icons: n
                            } = e;
                            return void 0 === n ? null == t ? void 0 : t.mergedIconsRef.value : n
                        })),
                        a = zi((() => {
                            const {
                                componentOptions: n
                            } = e;
                            return void 0 !== n ? n : null == t ? void 0 : t.mergedComponentPropsRef.value
                        })),
                        s = zi((() => {
                            const {
                                clsPrefix: n
                            } = e;
                            return void 0 !== n ? n : t ? t.mergedClsPrefixRef.value : _c
                        })),
                        c = zi((() => {
                            var n;
                            const {
                                rtl: o
                            } = e;
                            if (void 0 === o) return null == t ? void 0 : t.mergedRtlRef.value;
                            const r = {};
                            for (const e of o) r[e.name] = Ct(e), null === (n = e.peers) || void 0 === n || n.forEach((e => {
                                e.name in r || (r[e.name] = Ct(e))
                            }));
                            return r
                        })),
                        u = zi((() => e.breakpoints || (null == t ? void 0 : t.mergedBreakpointsRef.value))),
                        d = e.inlineThemeDisabled || (null == t ? void 0 : t.inlineThemeDisabled),
                        f = e.preflightStyleDisabled || (null == t ? void 0 : t.preflightStyleDisabled),
                        p = zi((() => {
                            const {
                                value: e
                            } = n, {
                                value: t
                            } = o, r = t && 0 !== Object.keys(t).length, i = null == e ? void 0 : e.name;
                            return i ? r ? `${i}-${Sc(JSON.stringify(o.value))}` : i : r ? Sc(JSON.stringify(o.value)) : ""
                        }));
                    return $o($c, {
                        mergedThemeHashRef: p,
                        mergedBreakpointsRef: u,
                        mergedRtlRef: c,
                        mergedIconsRef: l,
                        mergedComponentPropsRef: a,
                        mergedBorderedRef: i,
                        mergedNamespaceRef: r,
                        mergedClsPrefixRef: s,
                        mergedLocaleRef: zi((() => {
                            const {
                                locale: n
                            } = e;
                            if (null !== n) return void 0 === n ? null == t ? void 0 : t.mergedLocaleRef.value : n
                        })),
                        mergedDateLocaleRef: zi((() => {
                            const {
                                dateLocale: n
                            } = e;
                            if (null !== n) return void 0 === n ? null == t ? void 0 : t.mergedDateLocaleRef.value : n
                        })),
                        mergedHljsRef: zi((() => {
                            const {
                                hljs: n
                            } = e;
                            return void 0 === n ? null == t ? void 0 : t.mergedHljsRef.value : n
                        })),
                        mergedKatexRef: zi((() => {
                            const {
                                katex: n
                            } = e;
                            return void 0 === n ? null == t ? void 0 : t.mergedKatexRef.value : n
                        })),
                        mergedThemeRef: n,
                        mergedThemeOverridesRef: o,
                        inlineThemeDisabled: d || !1,
                        preflightStyleDisabled: f || !1
                    }), {
                        mergedClsPrefix: s,
                        mergedBordered: i,
                        mergedNamespace: r,
                        mergedTheme: n,
                        mergedThemeOverrides: o
                    }
                },
                render() {
                    var e, t, n, o;
                    return this.abstract ? null === (o = (n = this.$slots).default) || void 0 === o ? void 0 : o.call(n) : Ti(this.as || this.tag, {
                        class: `${this.mergedClsPrefix||_c}-config-provider`
                    }, null === (t = (e = this.$slots).default) || void 0 === t ? void 0 : t.call(e))
                }
            }),
            Pc = {
                black: "#000",
                silver: "#C0C0C0",
                gray: "#808080",
                white: "#FFF",
                maroon: "#800000",
                red: "#F00",
                purple: "#800080",
                fuchsia: "#F0F",
                green: "#008000",
                lime: "#0F0",
                olive: "#808000",
                yellow: "#FF0",
                navy: "#000080",
                blue: "#00F",
                teal: "#008080",
                aqua: "#0FF",
                transparent: "#0000"
            };
        const Fc = "^\\s*",
            Mc = "\\s*$",
            Rc = "\\s*((\\.\\d+)|(\\d+(\\.\\d*)?))%\\s*",
            Ec = "\\s*((\\.\\d+)|(\\d+(\\.\\d*)?))\\s*",
            Oc = "([0-9A-Fa-f])",
            Bc = "([0-9A-Fa-f]{2})",
            Ac = (new RegExp(`${Fc}hsl\\s*\\(${Ec},${Rc},${Rc}\\)${Mc}`), new RegExp(`${Fc}hsv\\s*\\(${Ec},${Rc},${Rc}\\)${Mc}`), new RegExp(`${Fc}hsla\\s*\\(${Ec},${Rc},${Rc},${Ec}\\)${Mc}`), new RegExp(`${Fc}hsva\\s*\\(${Ec},${Rc},${Rc},${Ec}\\)${Mc}`), new RegExp(`${Fc}rgb\\s*\\(${Ec},${Ec},${Ec}\\)${Mc}`)),
            Ic = new RegExp(`${Fc}rgba\\s*\\(${Ec},${Ec},${Ec},${Ec}\\)${Mc}`),
            Dc = new RegExp(`${Fc}#${Oc}${Oc}${Oc}${Mc}`),
            Lc = new RegExp(`${Fc}#${Bc}${Bc}${Bc}${Mc}`),
            jc = new RegExp(`${Fc}#${Oc}${Oc}${Oc}${Oc}${Mc}`),
            Nc = new RegExp(`${Fc}#${Bc}${Bc}${Bc}${Bc}${Mc}`);

        function Hc(e) {
            return parseInt(e, 16)
        }

        function Wc(e) {
            try {
                let t;
                if (t = Lc.exec(e)) return [Hc(t[1]), Hc(t[2]), Hc(t[3]), 1];
                if (t = Ac.exec(e)) return [Yc(t[1]), Yc(t[5]), Yc(t[9]), 1];
                if (t = Ic.exec(e)) return [Yc(t[1]), Yc(t[5]), Yc(t[9]), Xc(t[13])];
                if (t = Dc.exec(e)) return [Hc(t[1] + t[1]), Hc(t[2] + t[2]), Hc(t[3] + t[3]), 1];
                if (t = Nc.exec(e)) return [Hc(t[1]), Hc(t[2]), Hc(t[3]), Xc(Hc(t[4]) / 255)];
                if (t = jc.exec(e)) return [Hc(t[1] + t[1]), Hc(t[2] + t[2]), Hc(t[3] + t[3]), Xc(Hc(t[4] + t[4]) / 255)];
                if (e in Pc) return Wc(Pc[e]);
                throw new Error(`[seemly/rgba]: Invalid color value ${e}.`)
            } catch (e) {
                throw e
            }
        }

        function Vc(e, t, n, o) {
            return `rgba(${Yc(e)}, ${Yc(t)}, ${Yc(n)}, ${r=o,r>1?1:r<0?0:r})`;
            var r
        }

        function qc(e, t, n, o, r) {
            return Yc((e * t * (1 - o) + n * o) / r)
        }

        function Uc(e, t) {
            Array.isArray(e) || (e = Wc(e)), Array.isArray(t) || (t = Wc(t));
            const n = e[3],
                o = t[3],
                r = Xc(n + o - n * o);
            return Vc(qc(e[0], n, t[0], o, r), qc(e[1], n, t[1], o, r), qc(e[2], n, t[2], o, r), r)
        }

        function Kc(e, t) {
            const [n, o, r, i = 1] = Array.isArray(e) ? e : Wc(e);
            return t.alpha ? Vc(n, o, r, t.alpha) : Vc(n, o, r, i)
        }

        function Gc(e, t) {
            const [n, o, r, i = 1] = Array.isArray(e) ? e : Wc(e), {
                lightness: l = 1,
                alpha: a = 1
            } = t;
            return function(e) {
                const [t, n, o] = e;
                if (3 in e) return `rgba(${Yc(t)}, ${Yc(n)}, ${Yc(o)}, ${Xc(e[3])})`;
                return `rgba(${Yc(t)}, ${Yc(n)}, ${Yc(o)}, 1)`
            }([n * l, o * l, r * l, i * a])
        }

        function Xc(e) {
            const t = Math.round(100 * Number(e)) / 100;
            return t > 1 ? 1 : t < 0 ? 0 : t
        }

        function Yc(e) {
            const t = Math.round(Number(e));
            return t > 255 ? 255 : t < 0 ? 0 : t
        }

        function Zc(e) {
            return Uc(e, [255, 255, 255, .16])
        }

        function Jc(e) {
            return Uc(e, [0, 0, 0, .12])
        }

        function Qc(e) {
            if (!e) return;
            const t = e.parentElement;
            t && t.removeChild(e)
        }

        function eu(e) {
            return document.querySelector(`style[cssr-id="${e}"]`)
        }

        function tu(e) {
            return !!e && /^\s*@(s|m)/.test(e)
        }
        const nu = "@css-render/vue3-ssr";
        const ou = "undefined" != typeof document;

        function ru() {
            if (ou) return;
            const e = _o(nu, null);
            return null !== e ? {
                adapter: (t, n) => function(e, t, n) {
                    const {
                        styles: o,
                        ids: r
                    } = n;
                    r.has(e) || null !== o && (r.add(e), o.push(function(e, t) {
                        return `<style cssr-id="${e}">\n${t}\n</style>`
                    }(e, t)))
                }(t, n, e),
                context: e
            } : void 0
        }
        const iu = "naive-ui-style";

        function lu(e, t, n) {
            if (!t) return;
            const o = ru(),
                r = zi((() => {
                    const {
                        value: n
                    } = t;
                    if (!n) return;
                    const o = n[e];
                    return o || void 0
                })),
                i = () => {
                    pr((() => {
                        const {
                            value: t
                        } = n, i = `${t}${e}Rtl`;
                        if (function(e, t) {
                                if (void 0 === e) return !1;
                                if (t) {
                                    const {
                                        context: {
                                            ids: n
                                        }
                                    } = t;
                                    return n.has(e)
                                }
                                return null !== eu(e)
                            }(i, o)) return;
                        const {
                            value: l
                        } = r;
                        l && l.style.mount({
                            id: i,
                            head: !0,
                            anchorMetaName: iu,
                            props: {
                                bPrefix: t ? `.${t}-` : void 0
                            },
                            ssr: o
                        })
                    }))
                };
            return o ? i() : jn(i), r
        }
        const au = "undefined" != typeof document && "undefined" != typeof window,
            su = au && "chrome" in window,
            cu = (au && navigator.userAgent.includes("Firefox"), au && navigator.userAgent.includes("Safari") && !su);
        const uu = /\s*,(?![^(]*\))\s*/g,
            du = /\s+/g;

        function fu(e) {
            let t = [""];
            return e.forEach((e => {
                (e = e && e.trim()) && (t = e.includes("&") ? function(e, t) {
                    const n = [];
                    return t.split(uu).forEach((t => {
                        let o = function(e) {
                            let t = 0;
                            for (let n = 0; n < e.length; ++n) "&" === e[n] && ++t;
                            return t
                        }(t);
                        if (!o) return void e.forEach((e => {
                            n.push((e && e + " ") + t)
                        }));
                        if (1 === o) return void e.forEach((e => {
                            n.push(t.replace("&", e))
                        }));
                        let r = [t];
                        for (; o--;) {
                            const t = [];
                            r.forEach((n => {
                                e.forEach((e => {
                                    t.push(n.replace("&", e))
                                }))
                            })), r = t
                        }
                        r.forEach((e => n.push(e)))
                    })), n
                }(t, e) : function(e, t) {
                    const n = [];
                    return t.split(uu).forEach((t => {
                        e.forEach((e => {
                            n.push((e && e + " ") + t)
                        }))
                    })), n
                }(t, e))
            })), t.join(", ").replace(du, " ")
        }
        const pu = /[A-Z]/g;

        function hu(e) {
            return e.replace(pu, (e => "-" + e.toLowerCase()))
        }

        function vu(e, t, n, o) {
            if (!t) return "";
            const r = function(e, t, n) {
                return "function" == typeof e ? e({
                    context: t.context,
                    props: n
                }) : e
            }(t, n, o);
            if (!r) return "";
            if ("string" == typeof r) return `${e} {\n${r}\n}`;
            const i = Object.keys(r);
            if (0 === i.length) return n.config.keepEmptyBlock ? e + " {\n}" : "";
            const l = e ? [e + " {"] : [];
            return i.forEach((e => {
                const t = r[e];
                "raw" !== e ? (e = hu(e), null != t && l.push(`  ${e}${function(e,t="  "){return"object"==typeof e&&null!==e?" {\n"+Object.entries(e).map((e=>t+`  ${hu(e[0])}: ${e[1]};`)).join("\n")+"\n"+t+"}":`: $ {
                        e
                    };
                    `}(t)}`)) : l.push("\n" + t + "\n")
            })), e && l.push("}"), l.join("\n")
        }

        function gu(e, t, n) {
            e && e.forEach((e => {
                if (Array.isArray(e)) gu(e, t, n);
                else if ("function" == typeof e) {
                    const o = e(t);
                    Array.isArray(o) ? gu(o, t, n) : o && n(o)
                } else e && n(e)
            }))
        }

        function bu(e, t, n, o, r, i) {
            const l = e.$;
            let a = "";
            if (l && "string" != typeof l)
                if ("function" == typeof l) {
                    const e = l({
                        context: o.context,
                        props: r
                    });
                    tu(e) ? a = e : t.push(e)
                } else if (l.before && l.before(o.context), l.$ && "string" != typeof l.$) {
                if (l.$) {
                    const e = l.$({
                        context: o.context,
                        props: r
                    });
                    tu(e) ? a = e : t.push(e)
                }
            } else tu(l.$) ? a = l.$ : t.push(l.$);
            else tu(l) ? a = l : t.push(l);
            const s = fu(t),
                c = vu(s, e.props, o, r);
            a ? (n.push(`${a} {`), i && c && i.insertRule(`${a} {\n${c}\n}\n`)) : (i && c && i.insertRule(c), !i && c.length && n.push(c)), e.children && gu(e.children, {
                context: o.context,
                props: r
            }, (e => {
                if ("string" == typeof e) {
                    const t = vu(s, {
                        raw: e
                    }, o, r);
                    i ? i.insertRule(t) : n.push(t)
                } else bu(e, t, n, o, r, i)
            })), t.pop(), a && n.push("}"), l && l.after && l.after(o.context)
        }

        function mu(e, t, n, o = !1) {
            const r = [];
            return bu(e, [], r, t, n, o ? e.instance.__styleSheet : void 0), o ? "" : r.join("\n\n")
        }

        function yu(e, t) {
            e.push(t)
        }

        function xu(e, t, n, o, r, i, l, a, s) {
            if (i && !s) {
                if (void 0 === n) return;
                const r = window.__cssrContext;
                return void(r[n] || (r[n] = !0, mu(t, e, o, i)))
            }
            let c;
            if (void 0 === n && (c = t.render(o), n = Sc(c)), s) return void s.adapter(n, null != c ? c : t.render(o));
            const u = eu(n);
            if (null !== u && !l) return u;
            const d = null != u ? u : function(e) {
                const t = document.createElement("style");
                return t.setAttribute("cssr-id", e), t
            }(n);
            if (void 0 === c && (c = t.render(o)), d.textContent = c, null !== u) return u;
            if (a) {
                const e = document.head.querySelector(`meta[name="${a}"]`);
                if (e) return document.head.insertBefore(d, e), yu(t.els, d), d
            }
            return r ? document.head.insertBefore(d, document.head.querySelector("style, link")) : document.head.appendChild(d), yu(t.els, d), d
        }

        function wu(e) {
            return mu(this, this.instance, e)
        }

        function Cu(e = {}) {
            const {
                id: t,
                ssr: n,
                props: o,
                head: r = !1,
                silent: i = !1,
                force: l = !1,
                anchorMetaName: a
            } = e;
            return xu(this.instance, this, t, o, r, i, l, a, n)
        }

        function Su(e = {}) {
            const {
                id: t
            } = e;
            ! function(e, t, n) {
                const {
                    els: o
                } = t;
                if (void 0 === n) o.forEach(Qc), t.els = [];
                else {
                    const e = eu(n);
                    e && o.includes(e) && (Qc(e), t.els = o.filter((t => t !== e)))
                }
            }(this.instance, this, t)
        }
        "undefined" != typeof window && (window.__cssrContext = {});
        const ku = function(e, t, n, o) {
            return {
                instance: e,
                $: t,
                props: n,
                children: o,
                els: [],
                render: wu,
                mount: Cu,
                unmount: Su
            }
        };

        function $u(e = {}) {
            let t = null;
            const n = {
                c: (...e) => function(e, t, n, o) {
                    return Array.isArray(t) ? ku(e, {
                        $: null
                    }, null, t) : Array.isArray(n) ? ku(e, t, null, n) : Array.isArray(o) ? ku(e, t, n, o) : ku(e, t, n, null)
                }(n, ...e),
                use: (e, ...t) => e.install(n, ...t),
                find: eu,
                context: {},
                config: e,
                get __styleSheet() {
                    if (!t) {
                        const e = document.createElement("style");
                        return document.head.appendChild(e), t = document.styleSheets[document.styleSheets.length - 1], t
                    }
                    return t
                }
            };
            return n
        }

        function _u(e) {
            let t, n = ".",
                o = "__",
                r = "--";
            if (e) {
                let t = e.blockPrefix;
                t && (n = t), t = e.elementPrefix, t && (o = t), t = e.modifierPrefix, t && (r = t)
            }
            const i = {
                install(e) {
                    t = e.c;
                    const n = e.context;
                    n.bem = {}, n.bem.b = null, n.bem.els = null
                }
            };
            return Object.assign(i, {
                cB: (...e) => t(function(e) {
                    let t, o;
                    return {
                        before(e) {
                            t = e.bem.b, o = e.bem.els, e.bem.els = null
                        },
                        after(e) {
                            e.bem.b = t, e.bem.els = o
                        },
                        $({
                            context: t,
                            props: o
                        }) {
                            return e = "string" == typeof e ? e : e({
                                context: t,
                                props: o
                            }), t.bem.b = e, `${(null==o?void 0:o.bPrefix)||n}${t.bem.b}`
                        }
                    }
                }(e[0]), e[1], e[2]),
                cE: (...e) => t(function(e) {
                    let t;
                    return {
                        before(e) {
                            t = e.bem.els
                        },
                        after(e) {
                            e.bem.els = t
                        },
                        $({
                            context: t,
                            props: r
                        }) {
                            return e = "string" == typeof e ? e : e({
                                context: t,
                                props: r
                            }), t.bem.els = e.split(",").map((e => e.trim())), t.bem.els.map((e => `${(null==r?void 0:r.bPrefix)||n}${t.bem.b}${o}${e}`)).join(", ")
                        }
                    }
                }(e[0]), e[1], e[2]),
                cM: (...e) => {
                    return t((i = e[0], {
                        $({
                            context: e,
                            props: t
                        }) {
                            const l = (i = "string" == typeof i ? i : i({
                                context: e,
                                props: t
                            })).split(",").map((e => e.trim()));

                            function a(i) {
                                return l.map((l => `&${(null==t?void 0:t.bPrefix)||n}${e.bem.b}${void 0!==i?`${o}${i}`:""}${r}${l}`)).join(", ")
                            }
                            const s = e.bem.els;
                            return null !== s ? a(s[0]) : a()
                        }
                    }), e[1], e[2]);
                    var i
                },
                cNotM: (...e) => {
                    return t((i = e[0], {
                        $({
                            context: e,
                            props: t
                        }) {
                            i = "string" == typeof i ? i : i({
                                context: e,
                                props: t
                            });
                            const l = e.bem.els;
                            return `&:not(${(null==t?void 0:t.bPrefix)||n}${e.bem.b}${null!==l&&l.length>0?`${o}${l[0]}`:""}${r}${i})`
                        }
                    }), e[1], e[2]);
                    var i
                }
            }), i
        }
        const zu = ".n-",
            Tu = $u(),
            Pu = _u({
                blockPrefix: zu,
                elementPrefix: "__",
                modifierPrefix: "--"
            });
        Tu.use(Pu);
        const {
            c: Fu,
            find: Mu
        } = Tu, {
            cB: Ru,
            cE: Eu,
            cM: Ou,
            cNotM: Bu
        } = Pu;
        const Au = (...e) => Fu(">", [Ru(...e)]);

        function Iu(e, t) {
            return e + ("default" === t ? "" : t.replace(/^[a-z]/, (e => e.toUpperCase())))
        }
        var Du = {
            fontFamily: 'v-sans, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"',
            fontFamilyMono: "v-mono, SFMono-Regular, Menlo, Consolas, Courier, monospace",
            fontWeight: "400",
            fontWeightStrong: "500",
            cubicBezierEaseInOut: "cubic-bezier(.4, 0, .2, 1)",
            cubicBezierEaseOut: "cubic-bezier(0, 0, .2, 1)",
            cubicBezierEaseIn: "cubic-bezier(.4, 0, 1, 1)",
            borderRadius: "3px",
            borderRadiusSmall: "2px",
            fontSize: "14px",
            fontSizeMini: "12px",
            fontSizeTiny: "12px",
            fontSizeSmall: "14px",
            fontSizeMedium: "14px",
            fontSizeLarge: "15px",
            fontSizeHuge: "16px",
            lineHeight: "1.6",
            heightMini: "16px",
            heightTiny: "22px",
            heightSmall: "28px",
            heightMedium: "34px",
            heightLarge: "40px",
            heightHuge: "46px"
        };
        const {
            fontSize: Lu,
            fontFamily: ju,
            lineHeight: Nu
        } = Du;
        var Hu = Fu("body", `\n margin: 0;\n font-size: ${Lu};\n font-family: ${ju};\n line-height: ${Nu};\n -webkit-text-size-adjust: 100%;\n -webkit-tap-highlight-color: transparent;\n`, [Fu("input", "\n font-family: inherit;\n font-size: inherit;\n ")]);

        function Wu(e, t, n, o, r, i) {
            const l = ru(),
                a = _o($c, null);
            if (n) {
                const e = () => {
                    const e = null == i ? void 0 : i.value;
                    n.mount({
                        id: void 0 === e ? t : e + t,
                        head: !0,
                        props: {
                            bPrefix: e ? `.${e}-` : void 0
                        },
                        anchorMetaName: iu,
                        ssr: l
                    }), (null == a ? void 0 : a.preflightStyleDisabled) || Hu.mount({
                        id: "n-global",
                        head: !0,
                        anchorMetaName: iu,
                        ssr: l
                    })
                };
                l ? e() : jn(e)
            }
            return zi((() => {
                var t;
                const {
                    theme: {
                        common: n,
                        self: i,
                        peers: l = {}
                    } = {},
                    themeOverrides: s = {},
                    builtinThemeOverrides: c = {}
                } = r, {
                    common: u,
                    peers: d
                } = s, {
                    common: f,
                    [e]: {
                        common: p,
                        self: h,
                        peers: v = {}
                    } = {}
                } = (null == a ? void 0 : a.mergedThemeRef.value) || {}, {
                    common: g,
                    [e]: b = {}
                } = (null == a ? void 0 : a.mergedThemeOverridesRef.value) || {}, {
                    common: m,
                    peers: y = {}
                } = b, x = Cc({}, n || p || f || o.common, g, m, u);
                return {
                    common: x,
                    self: Cc(null === (t = i || h || o.self) || void 0 === t ? void 0 : t(x), c, b, s),
                    peers: Cc({}, o.peers, v, l),
                    peerOverrides: Cc({}, c.peers, y, d)
                }
            }))
        }
        Wu.props = {
            theme: Object,
            themeOverrides: Object,
            builtinThemeOverrides: Object
        };
        var Vu = Wu;
        const qu = "n-form-item";

        function Uu(e, {
            defaultSize: t = "medium",
            mergedSize: n,
            mergedDisabled: o
        } = {}) {
            const r = _o(qu, null);
            $o(qu, null);
            const i = zi(n ? () => n(r) : () => {
                    const {
                        size: n
                    } = e;
                    if (n) return n;
                    if (r) {
                        const {
                            mergedSize: e
                        } = r;
                        if (void 0 !== e.value) return e.value
                    }
                    return t
                }),
                l = zi(o ? () => o(r) : () => {
                    const {
                        disabled: t
                    } = e;
                    return void 0 !== t ? t : !!r && r.disabled.value
                }),
                a = zi((() => {
                    const {
                        status: t
                    } = e;
                    return t || (null == r ? void 0 : r.mergedValidationStatus.value)
                }));
            return Vn((() => {
                r && r.restoreValidation()
            })), {
                mergedSizeRef: i,
                mergedDisabledRef: l,
                mergedStatusRef: a,
                nTriggerFormBlur() {
                    r && r.handleContentBlur()
                },
                nTriggerFormChange() {
                    r && r.handleContentChange()
                },
                nTriggerFormFocus() {
                    r && r.handleContentFocus()
                },
                nTriggerFormInput() {
                    r && r.handleContentInput()
                }
            }
        }

        function Ku(e, t, n, o) {
            var r;
            n || kc("useThemeClass", "cssVarsRef is not passed");
            const i = null === (r = _o($c, null)) || void 0 === r ? void 0 : r.mergedThemeHashRef,
                l = Ft(""),
                a = ru();
            let s;
            const c = `__${e}`;
            return pr((() => {
                (() => {
                    let e = c;
                    const r = t ? t.value : void 0,
                        u = null == i ? void 0 : i.value;
                    u && (e += `-${u}`), r && (e += `-${r}`);
                    const {
                        themeOverrides: d,
                        builtinThemeOverrides: f
                    } = o;
                    d && (e += `-${Sc(JSON.stringify(d))}`), f && (e += `-${Sc(JSON.stringify(f))}`), l.value = e, s = () => {
                        const t = n.value;
                        let o = "";
                        for (const e in t) o += `${e}: ${t[e]};`;
                        Fu(`.${e}`, o).mount({
                            id: e,
                            ssr: a
                        }), s = void 0
                    }
                })()
            })), {
                themeClass: l,
                onRender: () => {
                    null == s || s()
                }
            }
        }
        var Gu = Tn({
            name: "FadeInExpandTransition",
            props: {
                appear: Boolean,
                group: Boolean,
                mode: String,
                onLeave: Function,
                onAfterLeave: Function,
                onAfterEnter: Function,
                width: Boolean,
                reverse: Boolean
            },
            setup(e, {
                slots: t
            }) {
                function n(t) {
                    e.width ? t.style.maxWidth = `${t.offsetWidth}px` : t.style.maxHeight = `${t.offsetHeight}px`, t.offsetWidth
                }

                function o(t) {
                    e.width ? t.style.maxWidth = "0" : t.style.maxHeight = "0", t.offsetWidth;
                    const {
                        onLeave: n
                    } = e;
                    n && n()
                }

                function r(t) {
                    e.width ? t.style.maxWidth = "" : t.style.maxHeight = "";
                    const {
                        onAfterLeave: n
                    } = e;
                    n && n()
                }

                function i(t) {
                    if (t.style.transition = "none", e.width) {
                        const e = t.offsetWidth;
                        t.style.maxWidth = "0", t.offsetWidth, t.style.transition = "", t.style.maxWidth = `${e}px`
                    } else if (e.reverse) t.style.maxHeight = `${t.offsetHeight}px`, t.offsetHeight, t.style.transition = "", t.style.maxHeight = "0";
                    else {
                        const e = t.offsetHeight;
                        t.style.maxHeight = "0", t.offsetWidth, t.style.transition = "", t.style.maxHeight = `${e}px`
                    }
                    t.offsetWidth
                }

                function l(t) {
                    var n;
                    e.width ? t.style.maxWidth = "" : e.reverse || (t.style.maxHeight = ""), null === (n = e.onAfterEnter) || void 0 === n || n.call(e)
                }
                return () => {
                    const {
                        group: a,
                        width: s,
                        appear: c,
                        mode: u
                    } = e, d = a ? Sl : Ai, f = {
                        name: s ? "fade-in-width-expand-transition" : "fade-in-height-expand-transition",
                        appear: c,
                        onEnter: i,
                        onAfterEnter: l,
                        onBeforeLeave: n,
                        onLeave: o,
                        onAfterLeave: r
                    };
                    return a || (f.mode = u), Ti(d, f, t)
                }
            }
        });

        function Xu() {
            const e = Ft(!1);
            return Nn((() => {
                e.value = !0
            })), vt(e)
        }
        var Yu = Tn({
            name: "BaseIconSwitchTransition",
            setup(e, {
                slots: t
            }) {
                const n = Xu();
                return () => Ti(Ai, {
                    name: "icon-switch-transition",
                    appear: n.value
                }, t)
            }
        });

        function Zu(e, t, n) {
            if (!t) return void 0;
            const o = ru(),
                r = _o($c, null),
                i = () => {
                    const i = n.value;
                    t.mount({
                        id: void 0 === i ? e : i + e,
                        head: !0,
                        anchorMetaName: iu,
                        props: {
                            bPrefix: i ? `.${i}-` : void 0
                        },
                        ssr: o
                    }), (null == r ? void 0 : r.preflightStyleDisabled) || Hu.mount({
                        id: "n-global",
                        head: !0,
                        anchorMetaName: iu,
                        ssr: o
                    })
                };
            o ? i() : jn(i)
        }
        const {
            cubicBezierEaseInOut: Ju
        } = Du;

        function Qu({
            originalTransform: e = "",
            left: t = 0,
            top: n = 0,
            transition: o = `all .3s ${Ju} !important`
        } = {}) {
            return [Fu("&.icon-switch-transition-enter-from, &.icon-switch-transition-leave-to", {
                transform: `${e} scale(0.75)`,
                left: t,
                top: n,
                opacity: 0
            }), Fu("&.icon-switch-transition-enter-to, &.icon-switch-transition-leave-from", {
                transform: `scale(1) ${e}`,
                left: t,
                top: n,
                opacity: 1
            }), Fu("&.icon-switch-transition-enter-active, &.icon-switch-transition-leave-active", {
                transformOrigin: "center",
                position: "absolute",
                left: t,
                top: n,
                transition: o
            })]
        }
        var ed = Fu([Fu("@keyframes rotator", "\n 0% {\n -webkit-transform: rotate(0deg);\n transform: rotate(0deg);\n }\n 100% {\n -webkit-transform: rotate(360deg);\n transform: rotate(360deg);\n }"), Ru("base-loading", "\n position: relative;\n line-height: 0;\n width: 1em;\n height: 1em;\n ", [Eu("transition-wrapper", "\n position: absolute;\n width: 100%;\n height: 100%;\n ", [Qu()]), Eu("placeholder", "\n position: absolute;\n left: 50%;\n top: 50%;\n transform: translateX(-50%) translateY(-50%);\n ", [Qu({
            left: "50%",
            top: "50%",
            originalTransform: "translateX(-50%) translateY(-50%)"
        })]), Eu("container", "\n animation: rotator 3s linear infinite both;\n ", [Eu("icon", "\n height: 1em;\n width: 1em;\n ")])])]);
        const td = "1.6s",
            nd = {
                strokeWidth: {
                    type: Number,
                    default: 28
                },
                stroke: {
                    type: String,
                    default: void 0
                }
            };
        var od = Tn({
                name: "BaseLoading",
                props: Object.assign({
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    show: {
                        type: Boolean,
                        default: !0
                    },
                    scale: {
                        type: Number,
                        default: 1
                    },
                    radius: {
                        type: Number,
                        default: 100
                    }
                }, nd),
                setup(e) {
                    Zu("-base-loading", ed, Dt(e, "clsPrefix"))
                },
                render() {
                    const {
                        clsPrefix: e,
                        radius: t,
                        strokeWidth: n,
                        stroke: o,
                        scale: r
                    } = this, i = t / r;
                    return Ti("div", {
                        class: `${e}-base-loading`,
                        role: "img",
                        "aria-label": "loading"
                    }, Ti(Yu, null, {
                        default: () => this.show ? Ti("div", {
                            key: "icon",
                            class: `${e}-base-loading__transition-wrapper`
                        }, Ti("div", {
                            class: `${e}-base-loading__container`
                        }, Ti("svg", {
                            class: `${e}-base-loading__icon`,
                            viewBox: `0 0 ${2*i} ${2*i}`,
                            xmlns: "http://www.w3.org/2000/svg",
                            style: {
                                color: o
                            }
                        }, Ti("g", null, Ti("animateTransform", {
                            attributeName: "transform",
                            type: "rotate",
                            values: `0 ${i} ${i};270 ${i} ${i}`,
                            begin: "0s",
                            dur: td,
                            fill: "freeze",
                            repeatCount: "indefinite"
                        }), Ti("circle", {
                            class: `${e}-base-loading__icon`,
                            fill: "none",
                            stroke: "currentColor",
                            "stroke-width": n,
                            "stroke-linecap": "round",
                            cx: i,
                            cy: i,
                            r: t - n / 2,
                            "stroke-dasharray": 5.67 * t,
                            "stroke-dashoffset": 18.48 * t
                        }, Ti("animateTransform", {
                            attributeName: "transform",
                            type: "rotate",
                            values: `0 ${i} ${i};135 ${i} ${i};450 ${i} ${i}`,
                            begin: "0s",
                            dur: td,
                            fill: "freeze",
                            repeatCount: "indefinite"
                        }), Ti("animate", {
                            attributeName: "stroke-dashoffset",
                            values: `${5.67*t};${1.42*t};${5.67*t}`,
                            begin: "0s",
                            dur: td,
                            fill: "freeze",
                            repeatCount: "indefinite"
                        })))))) : Ti("div", {
                            key: "placeholder",
                            class: `${e}-base-loading__placeholder`
                        }, this.$slots)
                    }))
                }
            }),
            rd = Ru("base-wave", "\n position: absolute;\n left: 0;\n right: 0;\n top: 0;\n bottom: 0;\n border-radius: inherit;\n"),
            id = Tn({
                name: "BaseWave",
                props: {
                    clsPrefix: {
                        type: String,
                        required: !0
                    }
                },
                setup(e) {
                    Zu("-base-wave", rd, Dt(e, "clsPrefix"));
                    const t = Ft(null),
                        n = Ft(!1);
                    let o = null;
                    return Vn((() => {
                        null !== o && window.clearTimeout(o)
                    })), {
                        active: n,
                        selfRef: t,
                        play() {
                            null !== o && (window.clearTimeout(o), n.value = !1, o = null), Jt((() => {
                                var e;
                                null === (e = t.value) || void 0 === e || e.offsetHeight, n.value = !0, o = window.setTimeout((() => {
                                    n.value = !1, o = null
                                }), 1e3)
                            }))
                        }
                    }
                },
                render() {
                    const {
                        clsPrefix: e
                    } = this;
                    return Ti("div", {
                        ref: "selfRef",
                        "aria-hidden": !0,
                        class: [`${e}-base-wave`, this.active && `${e}-base-wave--active`]
                    })
                }
            });

        function ld(e, ...t) {
            if (!Array.isArray(e)) return e(...t);
            e.forEach((e => ld(e, ...t)))
        }

        function ad(e) {
            return e.replace(/#|\(|\)|,|\s|\./g, "_")
        }

        function sd(e) {
            return e.some((e => !Vr(e) || e.type !== Er && !(e.type === Mr && !sd(e.children)))) ? e : null
        }

        function cd(e, t) {
            return e && sd(e()) || t()
        }

        function ud(e, t, n) {
            return e && sd(e(t)) || n(t)
        }

        function dd(e, t) {
            return t(e && sd(e()) || null)
        }

        function fd(e) {
            return !(e && sd(e()))
        }
        const pd = "#FFF",
            hd = "#000",
            vd = "#000",
            gd = "#fff",
            bd = "#fff",
            md = "#fff",
            yd = "#fff",
            xd = "0.82",
            wd = "0.72",
            Cd = "0.38",
            Sd = "0.24",
            kd = "0.18",
            $d = "0.6",
            _d = "0.5",
            zd = "0.2",
            Td = ".08",
            Pd = "0",
            Fd = "0.25",
            Md = "0.4",
            Rd = "#36ad6a",
            Ed = "#18a058",
            Od = "#0c7a43",
            Bd = "#36ad6a",
            Ad = "#4098fc",
            Id = "#2080f0",
            Dd = "#1060c9",
            Ld = "#4098fc",
            jd = "#de576d",
            Nd = "#d03050",
            Hd = "#ab1f3f",
            Wd = "#de576d",
            Vd = "#fcb040",
            qd = "#f0a020",
            Ud = "#c97c10",
            Kd = "#fcb040",
            Gd = "#36ad6a",
            Xd = "#18a058",
            Yd = "#0c7a43",
            Zd = "#36ad6a",
            Jd = Wc(pd),
            Qd = Wc(hd),
            ef = `rgba(${Qd.slice(0,3).join(", ")}, `;

        function tf(e) {
            return `${ef+String(e)})`
        }

        function nf(e) {
            const t = Array.from(Qd);
            return t[3] = Number(e), Uc(Jd, t)
        }
        var of = Object.assign(Object.assign({
            name: "common"
        }, Du), {
            baseColor: pd,
            primaryColor: Ed,
            primaryColorHover: Rd,
            primaryColorPressed: Od,
            primaryColorSuppl: Bd,
            infoColor: Id,
            infoColorHover: Ad,
            infoColorPressed: Dd,
            infoColorSuppl: Ld,
            successColor: Xd,
            successColorHover: Gd,
            successColorPressed: Yd,
            successColorSuppl: Zd,
            warningColor: qd,
            warningColorHover: Vd,
            warningColorPressed: Ud,
            warningColorSuppl: Kd,
            errorColor: Nd,
            errorColorHover: jd,
            errorColorPressed: Hd,
            errorColorSuppl: Wd,
            textColorBase: vd,
            textColor1: "rgb(31, 34, 37)",
            textColor2: "rgb(51, 54, 57)",
            textColor3: "rgb(118, 124, 130)",
            textColorDisabled: nf(Sd),
            placeholderColor: nf(Sd),
            placeholderColorDisabled: nf(kd),
            iconColor: nf(Sd),
            iconColorHover: Gc(nf(Sd), {
                lightness: .75
            }),
            iconColorPressed: Gc(nf(Sd), {
                lightness: .9
            }),
            iconColorDisabled: nf(kd),
            opacity1: xd,
            opacity2: wd,
            opacity3: Cd,
            opacity4: Sd,
            opacity5: kd,
            dividerColor: "rgb(239, 239, 245)",
            borderColor: "rgb(224, 224, 230)",
            closeIconColor: nf(Number($d)),
            closeIconColorHover: nf(Number($d)),
            closeIconColorPressed: nf(Number($d)),
            closeColorHover: "rgba(0, 0, 0, .09)",
            closeColorPressed: "rgba(0, 0, 0, .13)",
            clearColor: nf(Sd),
            clearColorHover: Gc(nf(Sd), {
                lightness: .75
            }),
            clearColorPressed: Gc(nf(Sd), {
                lightness: .9
            }),
            scrollbarColor: tf(Fd),
            scrollbarColorHover: tf(Md),
            scrollbarWidth: "5px",
            scrollbarHeight: "5px",
            scrollbarBorderRadius: "5px",
            progressRailColor: nf(Td),
            railColor: "rgb(219, 219, 223)",
            popoverColor: gd,
            tableColor: bd,
            cardColor: bd,
            modalColor: md,
            bodyColor: yd,
            tagColor: "#eee",
            avatarColor: nf(zd),
            invertedColor: "rgb(0, 20, 40)",
            inputColor: nf(Pd),
            codeColor: "rgb(244, 244, 248)",
            tabColor: "rgb(247, 247, 250)",
            actionColor: "rgb(250, 250, 252)",
            tableHeaderColor: "rgb(250, 250, 252)",
            hoverColor: "rgb(243, 243, 245)",
            tableColorHover: "rgba(0, 0, 100, 0.03)",
            tableColorStriped: "rgba(0, 0, 100, 0.02)",
            pressedColor: "rgb(237, 237, 239)",
            opacityDisabled: _d,
            inputColorDisabled: "rgb(250, 250, 252)",
            buttonColor2: "rgba(46, 51, 56, .05)",
            buttonColor2Hover: "rgba(46, 51, 56, .09)",
            buttonColor2Pressed: "rgba(46, 51, 56, .13)",
            boxShadow1: "0 1px 2px -2px rgba(0, 0, 0, .08), 0 3px 6px 0 rgba(0, 0, 0, .06), 0 5px 12px 4px rgba(0, 0, 0, .04)",
            boxShadow2: "0 3px 6px -4px rgba(0, 0, 0, .12), 0 6px 16px 0 rgba(0, 0, 0, .08), 0 9px 28px 8px rgba(0, 0, 0, .05)",
            boxShadow3: "0 6px 16px -9px rgba(0, 0, 0, .08), 0 9px 28px 0 rgba(0, 0, 0, .05), 0 12px 48px 16px rgba(0, 0, 0, .03)"
        }), rf = {
            paddingTiny: "0 6px",
            paddingSmall: "0 10px",
            paddingMedium: "0 14px",
            paddingLarge: "0 18px",
            paddingRoundTiny: "0 10px",
            paddingRoundSmall: "0 14px",
            paddingRoundMedium: "0 18px",
            paddingRoundLarge: "0 22px",
            iconMarginTiny: "6px",
            iconMarginSmall: "6px",
            iconMarginMedium: "6px",
            iconMarginLarge: "6px",
            iconSizeTiny: "14px",
            iconSizeSmall: "18px",
            iconSizeMedium: "18px",
            iconSizeLarge: "20px",
            rippleDuration: ".6s"
        };
        var lf = {
            name: "Button",
            common: of,
            self: function(e) {
                const {
                    heightTiny: t,
                    heightSmall: n,
                    heightMedium: o,
                    heightLarge: r,
                    borderRadius: i,
                    fontSizeTiny: l,
                    fontSizeSmall: a,
                    fontSizeMedium: s,
                    fontSizeLarge: c,
                    opacityDisabled: u,
                    textColor2: d,
                    textColor3: f,
                    primaryColorHover: p,
                    primaryColorPressed: h,
                    borderColor: v,
                    primaryColor: g,
                    baseColor: b,
                    infoColor: m,
                    infoColorHover: y,
                    infoColorPressed: x,
                    successColor: w,
                    successColorHover: C,
                    successColorPressed: S,
                    warningColor: k,
                    warningColorHover: $,
                    warningColorPressed: _,
                    errorColor: z,
                    errorColorHover: T,
                    errorColorPressed: P,
                    fontWeight: F,
                    buttonColor2: M,
                    buttonColor2Hover: R,
                    buttonColor2Pressed: E,
                    fontWeightStrong: O
                } = e;
                return Object.assign(Object.assign({}, rf), {
                    heightTiny: t,
                    heightSmall: n,
                    heightMedium: o,
                    heightLarge: r,
                    borderRadiusTiny: i,
                    borderRadiusSmall: i,
                    borderRadiusMedium: i,
                    borderRadiusLarge: i,
                    fontSizeTiny: l,
                    fontSizeSmall: a,
                    fontSizeMedium: s,
                    fontSizeLarge: c,
                    opacityDisabled: u,
                    colorOpacitySecondary: "0.16",
                    colorOpacitySecondaryHover: "0.22",
                    colorOpacitySecondaryPressed: "0.28",
                    colorSecondary: M,
                    colorSecondaryHover: R,
                    colorSecondaryPressed: E,
                    colorTertiary: M,
                    colorTertiaryHover: R,
                    colorTertiaryPressed: E,
                    colorQuaternary: "#0000",
                    colorQuaternaryHover: R,
                    colorQuaternaryPressed: E,
                    color: "#0000",
                    colorHover: "#0000",
                    colorPressed: "#0000",
                    colorFocus: "#0000",
                    colorDisabled: "#0000",
                    textColor: d,
                    textColorTertiary: f,
                    textColorHover: p,
                    textColorPressed: h,
                    textColorFocus: p,
                    textColorDisabled: d,
                    textColorText: d,
                    textColorTextHover: p,
                    textColorTextPressed: h,
                    textColorTextFocus: p,
                    textColorTextDisabled: d,
                    textColorGhost: d,
                    textColorGhostHover: p,
                    textColorGhostPressed: h,
                    textColorGhostFocus: p,
                    textColorGhostDisabled: d,
                    border: `1px solid ${v}`,
                    borderHover: `1px solid ${p}`,
                    borderPressed: `1px solid ${h}`,
                    borderFocus: `1px solid ${p}`,
                    borderDisabled: `1px solid ${v}`,
                    rippleColor: g,
                    colorPrimary: g,
                    colorHoverPrimary: p,
                    colorPressedPrimary: h,
                    colorFocusPrimary: p,
                    colorDisabledPrimary: g,
                    textColorPrimary: b,
                    textColorHoverPrimary: b,
                    textColorPressedPrimary: b,
                    textColorFocusPrimary: b,
                    textColorDisabledPrimary: b,
                    textColorTextPrimary: g,
                    textColorTextHoverPrimary: p,
                    textColorTextPressedPrimary: h,
                    textColorTextFocusPrimary: p,
                    textColorTextDisabledPrimary: d,
                    textColorGhostPrimary: g,
                    textColorGhostHoverPrimary: p,
                    textColorGhostPressedPrimary: h,
                    textColorGhostFocusPrimary: p,
                    textColorGhostDisabledPrimary: g,
                    borderPrimary: `1px solid ${g}`,
                    borderHoverPrimary: `1px solid ${p}`,
                    borderPressedPrimary: `1px solid ${h}`,
                    borderFocusPrimary: `1px solid ${p}`,
                    borderDisabledPrimary: `1px solid ${g}`,
                    rippleColorPrimary: g,
                    colorInfo: m,
                    colorHoverInfo: y,
                    colorPressedInfo: x,
                    colorFocusInfo: y,
                    colorDisabledInfo: m,
                    textColorInfo: b,
                    textColorHoverInfo: b,
                    textColorPressedInfo: b,
                    textColorFocusInfo: b,
                    textColorDisabledInfo: b,
                    textColorTextInfo: m,
                    textColorTextHoverInfo: y,
                    textColorTextPressedInfo: x,
                    textColorTextFocusInfo: y,
                    textColorTextDisabledInfo: d,
                    textColorGhostInfo: m,
                    textColorGhostHoverInfo: y,
                    textColorGhostPressedInfo: x,
                    textColorGhostFocusInfo: y,
                    textColorGhostDisabledInfo: m,
                    borderInfo: `1px solid ${m}`,
                    borderHoverInfo: `1px solid ${y}`,
                    borderPressedInfo: `1px solid ${x}`,
                    borderFocusInfo: `1px solid ${y}`,
                    borderDisabledInfo: `1px solid ${m}`,
                    rippleColorInfo: m,
                    colorSuccess: w,
                    colorHoverSuccess: C,
                    colorPressedSuccess: S,
                    colorFocusSuccess: C,
                    colorDisabledSuccess: w,
                    textColorSuccess: b,
                    textColorHoverSuccess: b,
                    textColorPressedSuccess: b,
                    textColorFocusSuccess: b,
                    textColorDisabledSuccess: b,
                    textColorTextSuccess: w,
                    textColorTextHoverSuccess: C,
                    textColorTextPressedSuccess: S,
                    textColorTextFocusSuccess: C,
                    textColorTextDisabledSuccess: d,
                    textColorGhostSuccess: w,
                    textColorGhostHoverSuccess: C,
                    textColorGhostPressedSuccess: S,
                    textColorGhostFocusSuccess: C,
                    textColorGhostDisabledSuccess: w,
                    borderSuccess: `1px solid ${w}`,
                    borderHoverSuccess: `1px solid ${C}`,
                    borderPressedSuccess: `1px solid ${S}`,
                    borderFocusSuccess: `1px solid ${C}`,
                    borderDisabledSuccess: `1px solid ${w}`,
                    rippleColorSuccess: w,
                    colorWarning: k,
                    colorHoverWarning: $,
                    colorPressedWarning: _,
                    colorFocusWarning: $,
                    colorDisabledWarning: k,
                    textColorWarning: b,
                    textColorHoverWarning: b,
                    textColorPressedWarning: b,
                    textColorFocusWarning: b,
                    textColorDisabledWarning: b,
                    textColorTextWarning: k,
                    textColorTextHoverWarning: $,
                    textColorTextPressedWarning: _,
                    textColorTextFocusWarning: $,
                    textColorTextDisabledWarning: d,
                    textColorGhostWarning: k,
                    textColorGhostHoverWarning: $,
                    textColorGhostPressedWarning: _,
                    textColorGhostFocusWarning: $,
                    textColorGhostDisabledWarning: k,
                    borderWarning: `1px solid ${k}`,
                    borderHoverWarning: `1px solid ${$}`,
                    borderPressedWarning: `1px solid ${_}`,
                    borderFocusWarning: `1px solid ${$}`,
                    borderDisabledWarning: `1px solid ${k}`,
                    rippleColorWarning: k,
                    colorError: z,
                    colorHoverError: T,
                    colorPressedError: P,
                    colorFocusError: T,
                    colorDisabledError: z,
                    textColorError: b,
                    textColorHoverError: b,
                    textColorPressedError: b,
                    textColorFocusError: b,
                    textColorDisabledError: b,
                    textColorTextError: z,
                    textColorTextHoverError: T,
                    textColorTextPressedError: P,
                    textColorTextFocusError: T,
                    textColorTextDisabledError: d,
                    textColorGhostError: z,
                    textColorGhostHoverError: T,
                    textColorGhostPressedError: P,
                    textColorGhostFocusError: T,
                    textColorGhostDisabledError: z,
                    borderError: `1px solid ${z}`,
                    borderHoverError: `1px solid ${T}`,
                    borderPressedError: `1px solid ${P}`,
                    borderFocusError: `1px solid ${T}`,
                    borderDisabledError: `1px solid ${z}`,
                    rippleColorError: z,
                    waveOpacity: "0.6",
                    fontWeight: F,
                    fontWeightStrong: O
                })
            }
        };
        const {
            cubicBezierEaseInOut: af
        } = Du;
        var sf = Fu([Ru("button", "\n margin: 0;\n font-weight: var(--n-font-weight);\n line-height: 1;\n font-family: inherit;\n padding: var(--n-padding);\n height: var(--n-height);\n font-size: var(--n-font-size);\n border-radius: var(--n-border-radius);\n color: var(--n-text-color);\n background-color: var(--n-color);\n width: var(--n-width);\n white-space: nowrap;\n outline: none;\n position: relative;\n z-index: auto;\n border: none;\n display: inline-flex;\n flex-wrap: nowrap;\n flex-shrink: 0;\n align-items: center;\n justify-content: center;\n user-select: none;\n -webkit-user-select: none;\n text-align: center;\n cursor: pointer;\n text-decoration: none;\n transition:\n color .3s var(--n-bezier),\n background-color .3s var(--n-bezier),\n opacity .3s var(--n-bezier),\n border-color .3s var(--n-bezier);\n ", [Ou("color", [Eu("border", {
            borderColor: "var(--n-border-color)"
        }), Ou("disabled", [Eu("border", {
            borderColor: "var(--n-border-color-disabled)"
        })]), Bu("disabled", [Fu("&:focus", [Eu("state-border", {
            borderColor: "var(--n-border-color-focus)"
        })]), Fu("&:hover", [Eu("state-border", {
            borderColor: "var(--n-border-color-hover)"
        })]), Fu("&:active", [Eu("state-border", {
            borderColor: "var(--n-border-color-pressed)"
        })]), Ou("pressed", [Eu("state-border", {
            borderColor: "var(--n-border-color-pressed)"
        })])])]), Ou("disabled", {
            backgroundColor: "var(--n-color-disabled)",
            color: "var(--n-text-color-disabled)"
        }, [Eu("border", {
            border: "var(--n-border-disabled)"
        })]), Bu("disabled", [Fu("&:focus", {
            backgroundColor: "var(--n-color-focus)",
            color: "var(--n-text-color-focus)"
        }, [Eu("state-border", {
            border: "var(--n-border-focus)"
        })]), Fu("&:hover", {
            backgroundColor: "var(--n-color-hover)",
            color: "var(--n-text-color-hover)"
        }, [Eu("state-border", {
            border: "var(--n-border-hover)"
        })]), Fu("&:active", {
            backgroundColor: "var(--n-color-pressed)",
            color: "var(--n-text-color-pressed)"
        }, [Eu("state-border", {
            border: "var(--n-border-pressed)"
        })]), Ou("pressed", {
            backgroundColor: "var(--n-color-pressed)",
            color: "var(--n-text-color-pressed)"
        }, [Eu("state-border", {
            border: "var(--n-border-pressed)"
        })])]), Ou("loading", "cursor: wait;"), Ru("base-wave", "\n pointer-events: none;\n top: 0;\n right: 0;\n bottom: 0;\n left: 0;\n animation-iteration-count: 1;\n animation-duration: var(--n-ripple-duration);\n animation-timing-function: var(--n-bezier-ease-out), var(--n-bezier-ease-out);\n ", [Ou("active", {
            zIndex: 1,
            animationName: "button-wave-spread, button-wave-opacity"
        })]), au && "MozBoxSizing" in document.createElement("div").style ? Fu("&::moz-focus-inner", {
            border: 0
        }) : null, Eu("border, state-border", "\n position: absolute;\n left: 0;\n top: 0;\n right: 0;\n bottom: 0;\n border-radius: inherit;\n transition: border-color .3s var(--n-bezier);\n pointer-events: none;\n "), Eu("border", {
            border: "var(--n-border)"
        }), Eu("state-border", {
            border: "var(--n-border)",
            borderColor: "#0000",
            zIndex: 1
        }), Eu("icon", "\n margin: var(--n-icon-margin);\n margin-left: 0;\n height: var(--n-icon-size);\n width: var(--n-icon-size);\n max-width: var(--n-icon-size);\n font-size: var(--n-icon-size);\n position: relative;\n flex-shrink: 0;\n ", [Ru("icon-slot", "\n height: var(--n-icon-size);\n width: var(--n-icon-size);\n position: absolute;\n left: 0;\n top: 50%;\n transform: translateY(-50%);\n display: flex;\n align-items: center;\n justify-content: center;\n ", [Qu({
            top: "50%",
            originalTransform: "translateY(-50%)"
        })]), function({
            duration: e = ".2s",
            delay: t = ".1s"
        } = {}) {
            return [Fu("&.fade-in-width-expand-transition-leave-from, &.fade-in-width-expand-transition-enter-to", {
                opacity: 1
            }), Fu("&.fade-in-width-expand-transition-leave-to, &.fade-in-width-expand-transition-enter-from", "\n opacity: 0!important;\n margin-left: 0!important;\n margin-right: 0!important;\n "), Fu("&.fade-in-width-expand-transition-leave-active", `\n overflow: hidden;\n transition:\n opacity ${e} ${af},\n max-width ${e} ${af} ${t},\n margin-left ${e} ${af} ${t},\n margin-right ${e} ${af} ${t};\n `), Fu("&.fade-in-width-expand-transition-enter-active", `\n overflow: hidden;\n transition:\n opacity ${e} ${af} ${t},\n max-width ${e} ${af},\n margin-left ${e} ${af},\n margin-right ${e} ${af};\n `)]
        }()]), Eu("content", "\n display: flex;\n align-items: center;\n flex-wrap: nowrap;\n min-width: 0;\n ", [Fu("~", [Eu("icon", {
            margin: "var(--n-icon-margin)",
            marginRight: 0
        })])]), Ou("block", "\n display: flex;\n width: 100%;\n "), Ou("dashed", [Eu("border, state-border", {
            borderStyle: "dashed !important"
        })]), Ou("disabled", {
            cursor: "not-allowed",
            opacity: "var(--n-opacity-disabled)"
        })]), Fu("@keyframes button-wave-spread", {
            from: {
                boxShadow: "0 0 0.5px 0 var(--n-ripple-color)"
            },
            to: {
                boxShadow: "0 0 0.5px 4.5px var(--n-ripple-color)"
            }
        }), Fu("@keyframes button-wave-opacity", {
            from: {
                opacity: "var(--n-wave-opacity)"
            },
            to: {
                opacity: 0
            }
        })]);
        const cf = Tn({
            name: "Button",
            props: Object.assign(Object.assign({}, Vu.props), {
                color: String,
                textColor: String,
                text: Boolean,
                block: Boolean,
                loading: Boolean,
                disabled: Boolean,
                circle: Boolean,
                size: String,
                ghost: Boolean,
                round: Boolean,
                secondary: Boolean,
                tertiary: Boolean,
                quaternary: Boolean,
                strong: Boolean,
                focusable: {
                    type: Boolean,
                    default: !0
                },
                keyboard: {
                    type: Boolean,
                    default: !0
                },
                tag: {
                    type: String,
                    default: "button"
                },
                type: {
                    type: String,
                    default: "default"
                },
                dashed: Boolean,
                renderIcon: Function,
                iconPlacement: {
                    type: String,
                    default: "left"
                },
                attrType: {
                    type: String,
                    default: "button"
                },
                bordered: {
                    type: Boolean,
                    default: !0
                },
                onClick: [Function, Array],
                nativeFocusBehavior: {
                    type: Boolean,
                    default: !cu
                }
            }),
            setup(e) {
                const t = Ft(null),
                    n = Ft(null),
                    o = Ft(!1),
                    r = Il((() => !e.quaternary && !e.tertiary && !e.secondary && !e.text && (!e.color || e.ghost || e.dashed) && e.bordered)),
                    i = _o("n-button-group", {}),
                    {
                        mergedSizeRef: l
                    } = Uu({}, {
                        defaultSize: "medium",
                        mergedSize: t => {
                            const {
                                size: n
                            } = e;
                            if (n) return n;
                            const {
                                size: o
                            } = i;
                            if (o) return o;
                            const {
                                mergedSize: r
                            } = t || {};
                            return r ? r.value : "medium"
                        }
                    }),
                    a = zi((() => e.focusable && !e.disabled)),
                    {
                        inlineThemeDisabled: s,
                        mergedClsPrefixRef: c,
                        mergedRtlRef: u
                    } = zc(e),
                    d = Vu("Button", "-button", sf, lf, e, c),
                    f = lu("Button", u, c),
                    p = zi((() => {
                        const t = d.value,
                            {
                                common: {
                                    cubicBezierEaseInOut: n,
                                    cubicBezierEaseOut: o
                                },
                                self: r
                            } = t,
                            {
                                rippleDuration: i,
                                opacityDisabled: a,
                                fontWeight: s,
                                fontWeightStrong: c
                            } = r,
                            u = l.value,
                            {
                                dashed: f,
                                type: p,
                                ghost: h,
                                text: v,
                                color: g,
                                round: b,
                                circle: m,
                                textColor: y,
                                secondary: x,
                                tertiary: w,
                                quaternary: C,
                                strong: S
                            } = e,
                            k = {
                                "font-weight": S ? c : s
                            };
                        let $ = {
                            "--n-color": "initial",
                            "--n-color-hover": "initial",
                            "--n-color-pressed": "initial",
                            "--n-color-focus": "initial",
                            "--n-color-disabled": "initial",
                            "--n-ripple-color": "initial",
                            "--n-text-color": "initial",
                            "--n-text-color-hover": "initial",
                            "--n-text-color-pressed": "initial",
                            "--n-text-color-focus": "initial",
                            "--n-text-color-disabled": "initial"
                        };
                        const _ = "tertiary" === p,
                            z = "default" === p,
                            T = _ ? "default" : p;
                        if (v) {
                            const e = y || g;
                            $ = {
                                "--n-color": "#0000",
                                "--n-color-hover": "#0000",
                                "--n-color-pressed": "#0000",
                                "--n-color-focus": "#0000",
                                "--n-color-disabled": "#0000",
                                "--n-ripple-color": "#0000",
                                "--n-text-color": e || r[Iu("textColorText", T)],
                                "--n-text-color-hover": e ? Zc(e) : r[Iu("textColorTextHover", T)],
                                "--n-text-color-pressed": e ? Jc(e) : r[Iu("textColorTextPressed", T)],
                                "--n-text-color-focus": e ? Zc(e) : r[Iu("textColorTextHover", T)],
                                "--n-text-color-disabled": e || r[Iu("textColorTextDisabled", T)]
                            }
                        } else if (h || f) {
                            const e = y || g;
                            $ = {
                                "--n-color": "#0000",
                                "--n-color-hover": "#0000",
                                "--n-color-pressed": "#0000",
                                "--n-color-focus": "#0000",
                                "--n-color-disabled": "#0000",
                                "--n-ripple-color": g || r[Iu("rippleColor", T)],
                                "--n-text-color": e || r[Iu("textColorGhost", T)],
                                "--n-text-color-hover": e ? Zc(e) : r[Iu("textColorGhostHover", T)],
                                "--n-text-color-pressed": e ? Jc(e) : r[Iu("textColorGhostPressed", T)],
                                "--n-text-color-focus": e ? Zc(e) : r[Iu("textColorGhostHover", T)],
                                "--n-text-color-disabled": e || r[Iu("textColorGhostDisabled", T)]
                            }
                        } else if (x) {
                            const e = z ? r.textColor : _ ? r.textColorTertiary : r[Iu("color", T)],
                                t = g || e,
                                n = "default" !== p && "tertiary" !== p;
                            $ = {
                                "--n-color": n ? Kc(t, {
                                    alpha: Number(r.colorOpacitySecondary)
                                }) : r.colorSecondary,
                                "--n-color-hover": n ? Kc(t, {
                                    alpha: Number(r.colorOpacitySecondaryHover)
                                }) : r.colorSecondaryHover,
                                "--n-color-pressed": n ? Kc(t, {
                                    alpha: Number(r.colorOpacitySecondaryPressed)
                                }) : r.colorSecondaryPressed,
                                "--n-color-focus": n ? Kc(t, {
                                    alpha: Number(r.colorOpacitySecondaryHover)
                                }) : r.colorSecondaryHover,
                                "--n-color-disabled": r.colorSecondary,
                                "--n-ripple-color": "#0000",
                                "--n-text-color": t,
                                "--n-text-color-hover": t,
                                "--n-text-color-pressed": t,
                                "--n-text-color-focus": t,
                                "--n-text-color-disabled": t
                            }
                        } else if (w || C) {
                            const e = z ? r.textColor : _ ? r.textColorTertiary : r[Iu("color", T)],
                                t = g || e;
                            w ? ($["--n-color"] = r.colorTertiary, $["--n-color-hover"] = r.colorTertiaryHover, $["--n-color-pressed"] = r.colorTertiaryPressed, $["--n-color-focus"] = r.colorSecondaryHover, $["--n-color-disabled"] = r.colorTertiary) : ($["--n-color"] = r.colorQuaternary, $["--n-color-hover"] = r.colorQuaternaryHover, $["--n-color-pressed"] = r.colorQuaternaryPressed, $["--n-color-focus"] = r.colorQuaternaryHover, $["--n-color-disabled"] = r.colorQuaternary), $["--n-ripple-color"] = "#0000", $["--n-text-color"] = t, $["--n-text-color-hover"] = t, $["--n-text-color-pressed"] = t, $["--n-text-color-focus"] = t, $["--n-text-color-disabled"] = t
                        } else $ = {
                            "--n-color": g || r[Iu("color", T)],
                            "--n-color-hover": g ? Zc(g) : r[Iu("colorHover", T)],
                            "--n-color-pressed": g ? Jc(g) : r[Iu("colorPressed", T)],
                            "--n-color-focus": g ? Zc(g) : r[Iu("colorFocus", T)],
                            "--n-color-disabled": g || r[Iu("colorDisabled", T)],
                            "--n-ripple-color": g || r[Iu("rippleColor", T)],
                            "--n-text-color": y || (g ? r.textColorPrimary : _ ? r.textColorTertiary : r[Iu("textColor", T)]),
                            "--n-text-color-hover": y || (g ? r.textColorHoverPrimary : r[Iu("textColorHover", T)]),
                            "--n-text-color-pressed": y || (g ? r.textColorPressedPrimary : r[Iu("textColorPressed", T)]),
                            "--n-text-color-focus": y || (g ? r.textColorFocusPrimary : r[Iu("textColorFocus", T)]),
                            "--n-text-color-disabled": y || (g ? r.textColorDisabledPrimary : r[Iu("textColorDisabled", T)])
                        };
                        let P = {
                            "--n-border": "initial",
                            "--n-border-hover": "initial",
                            "--n-border-pressed": "initial",
                            "--n-border-focus": "initial",
                            "--n-border-disabled": "initial"
                        };
                        P = v ? {
                            "--n-border": "none",
                            "--n-border-hover": "none",
                            "--n-border-pressed": "none",
                            "--n-border-focus": "none",
                            "--n-border-disabled": "none"
                        } : {
                            "--n-border": r[Iu("border", T)],
                            "--n-border-hover": r[Iu("borderHover", T)],
                            "--n-border-pressed": r[Iu("borderPressed", T)],
                            "--n-border-focus": r[Iu("borderFocus", T)],
                            "--n-border-disabled": r[Iu("borderDisabled", T)]
                        };
                        const {
                            [Iu("height", u)]: F, [Iu("fontSize", u)]: M, [Iu("padding", u)]: R, [Iu("paddingRound", u)]: E, [Iu("iconSize", u)]: O, [Iu("borderRadius", u)]: B, [Iu("iconMargin", u)]: A, waveOpacity: I
                        } = r, D = {
                            "--n-width": m && !v ? F : "initial",
                            "--n-height": v ? "initial" : F,
                            "--n-font-size": M,
                            "--n-padding": m || v ? "initial" : b ? E : R,
                            "--n-icon-size": O,
                            "--n-icon-margin": A,
                            "--n-border-radius": v ? "initial" : m || b ? F : B
                        };
                        return Object.assign(Object.assign(Object.assign(Object.assign({
                            "--n-bezier": n,
                            "--n-bezier-ease-out": o,
                            "--n-ripple-duration": i,
                            "--n-opacity-disabled": a,
                            "--n-wave-opacity": I
                        }, k), $), P), D)
                    })),
                    h = s ? Ku("button", zi((() => {
                        let t = "";
                        const {
                            dashed: n,
                            type: o,
                            ghost: r,
                            text: i,
                            color: a,
                            round: s,
                            circle: c,
                            textColor: u,
                            secondary: d,
                            tertiary: f,
                            quaternary: p,
                            strong: h
                        } = e;
                        n && (t += "a"), r && (t += "b"), i && (t += "c"), s && (t += "d"), c && (t += "e"), d && (t += "f"), f && (t += "g"), p && (t += "h"), h && (t += "i"), a && (t += `j${ad(a)}`), u && (t += `k${ad(u)}`);
                        const {
                            value: v
                        } = l;
                        return t += `l${v[0]}`, t += `m${o[0]}`, t
                    })), p, e) : void 0;
                return {
                    selfElRef: t,
                    waveElRef: n,
                    mergedClsPrefix: c,
                    mergedFocusable: a,
                    mergedSize: l,
                    showBorder: r,
                    enterPressed: o,
                    rtlEnabled: f,
                    handleMousedown: n => {
                        var o;
                        a.value || n.preventDefault(), e.nativeFocusBehavior || (n.preventDefault(), e.disabled || a.value && (null === (o = t.value) || void 0 === o || o.focus({
                            preventScroll: !0
                        })))
                    },
                    handleKeydown: t => {
                        if ("Enter" === t.key) {
                            if (!e.keyboard || e.loading) return void t.preventDefault();
                            o.value = !0
                        }
                    },
                    handleBlur: () => {
                        o.value = !1
                    },
                    handleKeyup: t => {
                        if ("Enter" === t.key) {
                            if (!e.keyboard) return;
                            o.value = !1
                        }
                    },
                    handleClick: t => {
                        var o;
                        if (!e.disabled && !e.loading) {
                            const {
                                onClick: r
                            } = e;
                            r && ld(r, t), e.text || null === (o = n.value) || void 0 === o || o.play()
                        }
                    },
                    customColorCssVars: zi((() => {
                        const {
                            color: t
                        } = e;
                        if (!t) return null;
                        const n = Zc(t);
                        return {
                            "--n-border-color": t,
                            "--n-border-color-hover": n,
                            "--n-border-color-pressed": Jc(t),
                            "--n-border-color-focus": n,
                            "--n-border-color-disabled": t
                        }
                    })),
                    cssVars: s ? void 0 : p,
                    themeClass: null == h ? void 0 : h.themeClass,
                    onRender: null == h ? void 0 : h.onRender
                }
            },
            render() {
                const {
                    mergedClsPrefix: e,
                    tag: t,
                    onRender: n
                } = this;
                null == n || n();
                const o = dd(this.$slots.default, (t => t && Ti("span", {
                    class: `${e}-button__content`
                }, t)));
                return Ti(t, {
                    ref: "selfElRef",
                    class: [this.themeClass, `${e}-button`, `${e}-button--${this.type}-type`, `${e}-button--${this.mergedSize}-type`, this.rtlEnabled && `${e}-button--rtl`, this.disabled && `${e}-button--disabled`, this.block && `${e}-button--block`, this.enterPressed && `${e}-button--pressed`, !this.text && this.dashed && `${e}-button--dashed`, this.color && `${e}-button--color`, this.secondary && `${e}-button--secondary`, this.loading && `${e}-button--loading`, this.ghost && `${e}-button--ghost`],
                    tabindex: this.mergedFocusable ? 0 : -1,
                    type: this.attrType,
                    style: this.cssVars,
                    disabled: this.disabled,
                    onClick: this.handleClick,
                    onBlur: this.handleBlur,
                    onMousedown: this.handleMousedown,
                    onKeyup: this.handleKeyup,
                    onKeydown: this.handleKeydown
                }, "right" === this.iconPlacement && o, Ti(Gu, {
                    width: !0
                }, {
                    default: () => dd(this.$slots.icon, (t => (this.loading || this.renderIcon || t) && Ti("span", {
                        class: `${e}-button__icon`,
                        style: {
                            margin: fd(this.$slots.default) ? "0" : ""
                        }
                    }, Ti(Yu, null, {
                        default: () => this.loading ? Ti(od, {
                            clsPrefix: e,
                            key: "loading",
                            class: `${e}-icon-slot`,
                            strokeWidth: 20
                        }) : Ti("div", {
                            key: "icon",
                            class: `${e}-icon-slot`,
                            role: "none"
                        }, this.renderIcon ? this.renderIcon() : t)
                    }))))
                }), "left" === this.iconPlacement && o, this.text ? null : Ti(id, {
                    ref: "waveElRef",
                    clsPrefix: e
                }), this.showBorder ? Ti("div", {
                    "aria-hidden": !0,
                    class: `${e}-button__border`,
                    style: this.customColorCssVars
                }) : null, this.showBorder ? Ti("div", {
                    "aria-hidden": !0,
                    class: `${e}-button__state-border`,
                    style: this.customColorCssVars
                }) : null)
            }
        });
        var uf = cf;

        function df(e, t) {
            return vr(e, (e => {
                void 0 !== e && (t.value = e)
            })), zi((() => void 0 === e.value ? t.value : e.value))
        }

        function ff(e) {
            return "string" == typeof e ? e.endsWith("px") ? Number(e.slice(0, e.length - 2)) : Number(e) : e
        }

        function pf(e) {
            if (null != e) return "number" == typeof e ? `${e}px` : e.endsWith("px") ? e : `${e}px`
        }

        function hf(e, t) {
            const n = e.trim().split(/\s+/g),
                o = {
                    top: n[0]
                };
            switch (n.length) {
                case 1:
                    o.right = n[0], o.bottom = n[0], o.left = n[0];
                    break;
                case 2:
                    o.right = n[1], o.left = n[1], o.bottom = n[0];
                    break;
                case 3:
                    o.right = n[1], o.bottom = n[2], o.left = n[1];
                    break;
                case 4:
                    o.right = n[1], o.bottom = n[2], o.left = n[3];
                    break;
                default:
                    throw new Error("[seemly/getMargin]:" + e + " is not a valid value.")
            }
            return void 0 === t ? o : o[t]
        }
        var vf, gf = [],
            bf = "ResizeObserver loop completed with undelivered notifications.";
        ! function(e) {
            e.BORDER_BOX = "border-box", e.CONTENT_BOX = "content-box", e.DEVICE_PIXEL_CONTENT_BOX = "device-pixel-content-box"
        }(vf || (vf = {}));
        var mf, yf = function(e) {
                return Object.freeze(e)
            },
            xf = function(e, t) {
                this.inlineSize = e, this.blockSize = t, yf(this)
            },
            wf = function() {
                function e(e, t, n, o) {
                    return this.x = e, this.y = t, this.width = n, this.height = o, this.top = this.y, this.left = this.x, this.bottom = this.top + this.height, this.right = this.left + this.width, yf(this)
                }
                return e.prototype.toJSON = function() {
                    var e = this;
                    return {
                        x: e.x,
                        y: e.y,
                        top: e.top,
                        right: e.right,
                        bottom: e.bottom,
                        left: e.left,
                        width: e.width,
                        height: e.height
                    }
                }, e.fromRect = function(t) {
                    return new e(t.x, t.y, t.width, t.height)
                }, e
            }(),
            Cf = function(e) {
                return e instanceof SVGElement && "getBBox" in e
            },
            Sf = function(e) {
                if (Cf(e)) {
                    var t = e.getBBox(),
                        n = t.width,
                        o = t.height;
                    return !n && !o
                }
                var r = e,
                    i = r.offsetWidth,
                    l = r.offsetHeight;
                return !(i || l || e.getClientRects().length)
            },
            kf = function(e) {
                var t;
                if (e instanceof Element) return !0;
                var n = null === (t = null == e ? void 0 : e.ownerDocument) || void 0 === t ? void 0 : t.defaultView;
                return !!(n && e instanceof n.Element)
            },
            $f = "undefined" != typeof window ? window : {},
            _f = new WeakMap,
            zf = /auto|scroll/,
            Tf = /^tb|vertical/,
            Pf = /msie|trident/i.test($f.navigator && $f.navigator.userAgent),
            Ff = function(e) {
                return parseFloat(e || "0")
            },
            Mf = function(e, t, n) {
                return void 0 === e && (e = 0), void 0 === t && (t = 0), void 0 === n && (n = !1), new xf((n ? t : e) || 0, (n ? e : t) || 0)
            },
            Rf = yf({
                devicePixelContentBoxSize: Mf(),
                borderBoxSize: Mf(),
                contentBoxSize: Mf(),
                contentRect: new wf(0, 0, 0, 0)
            }),
            Ef = function(e, t) {
                if (void 0 === t && (t = !1), _f.has(e) && !t) return _f.get(e);
                if (Sf(e)) return _f.set(e, Rf), Rf;
                var n = getComputedStyle(e),
                    o = Cf(e) && e.ownerSVGElement && e.getBBox(),
                    r = !Pf && "border-box" === n.boxSizing,
                    i = Tf.test(n.writingMode || ""),
                    l = !o && zf.test(n.overflowY || ""),
                    a = !o && zf.test(n.overflowX || ""),
                    s = o ? 0 : Ff(n.paddingTop),
                    c = o ? 0 : Ff(n.paddingRight),
                    u = o ? 0 : Ff(n.paddingBottom),
                    d = o ? 0 : Ff(n.paddingLeft),
                    f = o ? 0 : Ff(n.borderTopWidth),
                    p = o ? 0 : Ff(n.borderRightWidth),
                    h = o ? 0 : Ff(n.borderBottomWidth),
                    v = d + c,
                    g = s + u,
                    b = (o ? 0 : Ff(n.borderLeftWidth)) + p,
                    m = f + h,
                    y = a ? e.offsetHeight - m - e.clientHeight : 0,
                    x = l ? e.offsetWidth - b - e.clientWidth : 0,
                    w = r ? v + b : 0,
                    C = r ? g + m : 0,
                    S = o ? o.width : Ff(n.width) - w - x,
                    k = o ? o.height : Ff(n.height) - C - y,
                    $ = S + v + x + b,
                    _ = k + g + y + m,
                    z = yf({
                        devicePixelContentBoxSize: Mf(Math.round(S * devicePixelRatio), Math.round(k * devicePixelRatio), i),
                        borderBoxSize: Mf($, _, i),
                        contentBoxSize: Mf(S, k, i),
                        contentRect: new wf(d, s, S, k)
                    });
                return _f.set(e, z), z
            },
            Of = function(e, t, n) {
                var o = Ef(e, n),
                    r = o.borderBoxSize,
                    i = o.contentBoxSize,
                    l = o.devicePixelContentBoxSize;
                switch (t) {
                    case vf.DEVICE_PIXEL_CONTENT_BOX:
                        return l;
                    case vf.BORDER_BOX:
                        return r;
                    default:
                        return i
                }
            },
            Bf = function(e) {
                var t = Ef(e);
                this.target = e, this.contentRect = t.contentRect, this.borderBoxSize = yf([t.borderBoxSize]), this.contentBoxSize = yf([t.contentBoxSize]), this.devicePixelContentBoxSize = yf([t.devicePixelContentBoxSize])
            },
            Af = function(e) {
                if (Sf(e)) return 1 / 0;
                for (var t = 0, n = e.parentNode; n;) t += 1, n = n.parentNode;
                return t
            },
            If = function() {
                var e = 1 / 0,
                    t = [];
                gf.forEach((function(n) {
                    if (0 !== n.activeTargets.length) {
                        var o = [];
                        n.activeTargets.forEach((function(t) {
                            var n = new Bf(t.target),
                                r = Af(t.target);
                            o.push(n), t.lastReportedSize = Of(t.target, t.observedBox), r < e && (e = r)
                        })), t.push((function() {
                            n.callback.call(n.observer, o, n.observer)
                        })), n.activeTargets.splice(0, n.activeTargets.length)
                    }
                }));
                for (var n = 0, o = t; n < o.length; n++) {
                    (0, o[n])()
                }
                return e
            },
            Df = function(e) {
                gf.forEach((function(t) {
                    t.activeTargets.splice(0, t.activeTargets.length), t.skippedTargets.splice(0, t.skippedTargets.length), t.observationTargets.forEach((function(n) {
                        n.isActive() && (Af(n.target) > e ? t.activeTargets.push(n) : t.skippedTargets.push(n))
                    }))
                }))
            },
            Lf = function() {
                var e, t = 0;
                for (Df(t); gf.some((function(e) {
                        return e.activeTargets.length > 0
                    }));) t = If(), Df(t);
                return gf.some((function(e) {
                    return e.skippedTargets.length > 0
                })) && ("function" == typeof ErrorEvent ? e = new ErrorEvent("error", {
                    message: bf
                }) : ((e = document.createEvent("Event")).initEvent("error", !1, !1), e.message = bf), window.dispatchEvent(e)), t > 0
            },
            jf = [],
            Nf = function(e) {
                if (!mf) {
                    var t = 0,
                        n = document.createTextNode("");
                    new MutationObserver((function() {
                        return jf.splice(0).forEach((function(e) {
                            return e()
                        }))
                    })).observe(n, {
                        characterData: !0
                    }), mf = function() {
                        n.textContent = "".concat(t ? t-- : t++)
                    }
                }
                jf.push(e), mf()
            },
            Hf = 0,
            Wf = {
                attributes: !0,
                characterData: !0,
                childList: !0,
                subtree: !0
            },
            Vf = ["resize", "load", "transitionend", "animationend", "animationstart", "animationiteration", "keyup", "keydown", "mouseup", "mousedown", "mouseover", "mouseout", "blur", "focus"],
            qf = function(e) {
                return void 0 === e && (e = 0), Date.now() + e
            },
            Uf = !1,
            Kf = new(function() {
                function e() {
                    var e = this;
                    this.stopped = !0, this.listener = function() {
                        return e.schedule()
                    }
                }
                return e.prototype.run = function(e) {
                    var t = this;
                    if (void 0 === e && (e = 250), !Uf) {
                        Uf = !0;
                        var n, o = qf(e);
                        n = function() {
                            var n = !1;
                            try {
                                n = Lf()
                            } finally {
                                if (Uf = !1, e = o - qf(), !Hf) return;
                                n ? t.run(1e3) : e > 0 ? t.run(e) : t.start()
                            }
                        }, Nf((function() {
                            requestAnimationFrame(n)
                        }))
                    }
                }, e.prototype.schedule = function() {
                    this.stop(), this.run()
                }, e.prototype.observe = function() {
                    var e = this,
                        t = function() {
                            return e.observer && e.observer.observe(document.body, Wf)
                        };
                    document.body ? t() : $f.addEventListener("DOMContentLoaded", t)
                }, e.prototype.start = function() {
                    var e = this;
                    this.stopped && (this.stopped = !1, this.observer = new MutationObserver(this.listener), this.observe(), Vf.forEach((function(t) {
                        return $f.addEventListener(t, e.listener, !0)
                    })))
                }, e.prototype.stop = function() {
                    var e = this;
                    this.stopped || (this.observer && this.observer.disconnect(), Vf.forEach((function(t) {
                        return $f.removeEventListener(t, e.listener, !0)
                    })), this.stopped = !0)
                }, e
            }()),
            Gf = function(e) {
                !Hf && e > 0 && Kf.start(), !(Hf += e) && Kf.stop()
            },
            Xf = function() {
                function e(e, t) {
                    this.target = e, this.observedBox = t || vf.CONTENT_BOX, this.lastReportedSize = {
                        inlineSize: 0,
                        blockSize: 0
                    }
                }
                return e.prototype.isActive = function() {
                    var e, t = Of(this.target, this.observedBox, !0);
                    return e = this.target, Cf(e) || function(e) {
                        switch (e.tagName) {
                            case "INPUT":
                                if ("image" !== e.type) break;
                            case "VIDEO":
                            case "AUDIO":
                            case "EMBED":
                            case "OBJECT":
                            case "CANVAS":
                            case "IFRAME":
                            case "IMG":
                                return !0
                        }
                        return !1
                    }(e) || "inline" !== getComputedStyle(e).display || (this.lastReportedSize = t), this.lastReportedSize.inlineSize !== t.inlineSize || this.lastReportedSize.blockSize !== t.blockSize
                }, e
            }(),
            Yf = function(e, t) {
                this.activeTargets = [], this.skippedTargets = [], this.observationTargets = [], this.observer = e, this.callback = t
            },
            Zf = new WeakMap,
            Jf = function(e, t) {
                for (var n = 0; n < e.length; n += 1)
                    if (e[n].target === t) return n;
                return -1
            },
            Qf = function() {
                function e() {}
                return e.connect = function(e, t) {
                    var n = new Yf(e, t);
                    Zf.set(e, n)
                }, e.observe = function(e, t, n) {
                    var o = Zf.get(e),
                        r = 0 === o.observationTargets.length;
                    Jf(o.observationTargets, t) < 0 && (r && gf.push(o), o.observationTargets.push(new Xf(t, n && n.box)), Gf(1), Kf.schedule())
                }, e.unobserve = function(e, t) {
                    var n = Zf.get(e),
                        o = Jf(n.observationTargets, t),
                        r = 1 === n.observationTargets.length;
                    o >= 0 && (r && gf.splice(gf.indexOf(n), 1), n.observationTargets.splice(o, 1), Gf(-1))
                }, e.disconnect = function(e) {
                    var t = this,
                        n = Zf.get(e);
                    n.observationTargets.slice().forEach((function(n) {
                        return t.unobserve(e, n.target)
                    })), n.activeTargets.splice(0, n.activeTargets.length)
                }, e
            }(),
            ep = function() {
                function e(e) {
                    if (0 === arguments.length) throw new TypeError("Failed to construct 'ResizeObserver': 1 argument required, but only 0 present.");
                    if ("function" != typeof e) throw new TypeError("Failed to construct 'ResizeObserver': The callback provided as parameter 1 is not a function.");
                    Qf.connect(this, e)
                }
                return e.prototype.observe = function(e, t) {
                    if (0 === arguments.length) throw new TypeError("Failed to execute 'observe' on 'ResizeObserver': 1 argument required, but only 0 present.");
                    if (!kf(e)) throw new TypeError("Failed to execute 'observe' on 'ResizeObserver': parameter 1 is not of type 'Element");
                    Qf.observe(this, e, t)
                }, e.prototype.unobserve = function(e) {
                    if (0 === arguments.length) throw new TypeError("Failed to execute 'unobserve' on 'ResizeObserver': 1 argument required, but only 0 present.");
                    if (!kf(e)) throw new TypeError("Failed to execute 'unobserve' on 'ResizeObserver': parameter 1 is not of type 'Element");
                    Qf.unobserve(this, e)
                }, e.prototype.disconnect = function() {
                    Qf.disconnect(this)
                }, e.toString = function() {
                    return "function ResizeObserver () { [polyfill code] }"
                }, e
            }();
        var tp = new class {
            constructor() {
                this.handleResize = this.handleResize.bind(this), this.observer = new("undefined" != typeof window && window.ResizeObserver || ep)(this.handleResize), this.elHandlersMap = new Map
            }
            handleResize(e) {
                for (const t of e) {
                    const e = this.elHandlersMap.get(t.target);
                    void 0 !== e && e(t)
                }
            }
            registerHandler(e, t) {
                this.elHandlersMap.set(e, t), this.observer.observe(e)
            }
            unregisterHandler(e) {
                this.elHandlersMap.has(e) && (this.elHandlersMap.delete(e), this.observer.unobserve(e))
            }
        };
        var np = Tn({
            name: "ResizeObserver",
            props: {
                onResize: Function
            },
            setup(e) {
                let t = !1;
                const n = ui().proxy;

                function o(t) {
                    const {
                        onResize: n
                    } = e;
                    void 0 !== n && n(t)
                }
                Nn((() => {
                    const e = n.$el;
                    void 0 !== e && (e.nextElementSibling !== e.nextSibling && 3 === e.nodeType && "" !== e.nodeValue || null !== e.nextElementSibling && (tp.registerHandler(e.nextElementSibling, o), t = !0))
                })), Vn((() => {
                    t && tp.unregisterHandler(n.$el.nextElementSibling)
                }))
            },
            render() {
                return to(this.$slots, "default")
            }
        });

        function op(e) {
            return e.composedPath()[0]
        }
        const rp = {
            mousemoveoutside: new WeakMap,
            clickoutside: new WeakMap
        };

        function ip(e, t, n) {
            const o = rp[e];
            let r = o.get(t);
            void 0 === r && o.set(t, r = new WeakMap);
            let i = r.get(n);
            return void 0 === i && r.set(n, i = function(e, t, n) {
                if ("mousemoveoutside" === e) {
                    const e = e => {
                        t.contains(op(e)) || n(e)
                    };
                    return {
                        mousemove: e,
                        touchstart: e
                    }
                }
                if ("clickoutside" === e) {
                    let e = !1;
                    const o = n => {
                            e = !t.contains(op(n))
                        },
                        r = o => {
                            e && (t.contains(op(o)) || n(o))
                        };
                    return {
                        mousedown: o,
                        mouseup: r,
                        touchstart: o,
                        touchend: r
                    }
                }
                return {}
            }(e, t, n)), i
        }

        function lp(e, t, n, o) {
            if ("mousemoveoutside" === e || "clickoutside" === e) {
                const r = ip(e, t, n);
                return Object.keys(r).forEach((e => {
                    sp(e, document, r[e], o)
                })), !0
            }
            return !1
        }

        function ap(e, t, n, o) {
            if ("mousemoveoutside" === e || "clickoutside" === e) {
                const r = ip(e, t, n);
                return Object.keys(r).forEach((e => {
                    cp(e, document, r[e], o)
                })), !0
            }
            return !1
        }
        const {
            on: sp,
            off: cp
        } = function() {
            if ("undefined" == typeof window) return {
                on: () => {},
                off: () => {}
            };
            const e = new WeakMap,
                t = new WeakMap;

            function n() {
                e.set(this, !0)
            }

            function o() {
                e.set(this, !0), t.set(this, !0)
            }

            function r(e, t, n) {
                const o = e[t];
                return e[t] = function() {
                    return n.apply(e, arguments), o.apply(e, arguments)
                }, e
            }

            function i(e, t) {
                e[t] = Event.prototype[t]
            }
            const l = new WeakMap,
                a = Object.getOwnPropertyDescriptor(Event.prototype, "currentTarget");

            function s() {
                var e;
                return null !== (e = l.get(this)) && void 0 !== e ? e : null
            }

            function c(e, t) {
                void 0 !== a && Object.defineProperty(e, "currentTarget", {
                    configurable: !0,
                    enumerable: !0,
                    get: null != t ? t : a.get
                })
            }
            const u = {
                    bubble: {},
                    capture: {}
                },
                d = {},
                f = function() {
                    const a = function(a) {
                        const {
                            type: d,
                            eventPhase: f,
                            bubbles: p
                        } = a, h = op(a);
                        if (2 === f) return;
                        const v = 1 === f ? "capture" : "bubble";
                        let g = h;
                        const b = [];
                        for (; null === g && (g = window), b.push(g), g !== window;) g = g.parentNode || null;
                        const m = u.capture[d],
                            y = u.bubble[d];
                        if (r(a, "stopPropagation", n), r(a, "stopImmediatePropagation", o), c(a, s), "capture" === v) {
                            if (void 0 === m) return;
                            for (let n = b.length - 1; n >= 0 && !e.has(a); --n) {
                                const e = b[n],
                                    o = m.get(e);
                                if (void 0 !== o) {
                                    l.set(a, e);
                                    for (const e of o) {
                                        if (t.has(a)) break;
                                        e(a)
                                    }
                                }
                                if (0 === n && !p && void 0 !== y) {
                                    const n = y.get(e);
                                    if (void 0 !== n)
                                        for (const e of n) {
                                            if (t.has(a)) break;
                                            e(a)
                                        }
                                }
                            }
                        } else if ("bubble" === v) {
                            if (void 0 === y) return;
                            for (let n = 0; n < b.length && !e.has(a); ++n) {
                                const e = b[n],
                                    o = y.get(e);
                                if (void 0 !== o) {
                                    l.set(a, e);
                                    for (const e of o) {
                                        if (t.has(a)) break;
                                        e(a)
                                    }
                                }
                            }
                        }
                        i(a, "stopPropagation"), i(a, "stopImmediatePropagation"), c(a)
                    };
                    return a.displayName = "evtdUnifiedHandler", a
                }(),
                p = function() {
                    const e = function(e) {
                        const {
                            type: t,
                            eventPhase: n
                        } = e;
                        if (2 !== n) return;
                        const o = d[t];
                        void 0 !== o && o.forEach((t => t(e)))
                    };
                    return e.displayName = "evtdUnifiedWindowEventHandler", e
                }();

            function h(e, t) {
                const n = u[e];
                return void 0 === n[t] && (n[t] = new Map, window.addEventListener(t, f, "capture" === e)), n[t]
            }

            function v(e, t) {
                let n = e.get(t);
                return void 0 === n && e.set(t, n = new Set), n
            }

            function g(e, t, n, o) {
                if (ap(e, t, n, o)) return;
                const r = !0 === o || "object" == typeof o && !0 === o.capture,
                    i = r ? "capture" : "bubble",
                    l = h(i, e),
                    a = v(l, t);
                if (t === window) {
                    if (! function(e, t, n, o) {
                            const r = u[t][n];
                            if (void 0 !== r) {
                                const t = r.get(e);
                                if (void 0 !== t && t.has(o)) return !0
                            }
                            return !1
                        }(t, r ? "bubble" : "capture", e, n) && function(e, t) {
                            const n = d[e];
                            return !(void 0 === n || !n.has(t))
                        }(e, n)) {
                        const t = d[e];
                        t.delete(n), 0 === t.size && (window.removeEventListener(e, p), d[e] = void 0)
                    }
                }
                a.has(n) && a.delete(n), 0 === a.size && l.delete(t), 0 === l.size && (window.removeEventListener(e, f, "capture" === i), u[i][e] = void 0)
            }
            return {
                on: function(e, t, n, o) {
                    let r;
                    if (r = "object" == typeof o && !0 === o.once ? i => {
                            g(e, t, r, o), n(i)
                        } : n, lp(e, t, r, o)) return;
                    const i = v(h(!0 === o || "object" == typeof o && !0 === o.capture ? "capture" : "bubble", e), t);
                    if (i.has(r) || i.add(r), t === window) {
                        const t = function(e) {
                            return void 0 === d[e] && (d[e] = new Set, window.addEventListener(e, p)), d[e]
                        }(e);
                        t.has(r) || t.add(r)
                    }
                },
                off: g
            }
        }();
        var up = Tn({
                name: "Eye",
                render() {
                    return Ti("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 512 512"
                    }, Ti("path", {
                        d: "M255.66 112c-77.94 0-157.89 45.11-220.83 135.33a16 16 0 0 0-.27 17.77C82.92 340.8 161.8 400 255.66 400c92.84 0 173.34-59.38 221.79-135.25a16.14 16.14 0 0 0 0-17.47C428.89 172.28 347.8 112 255.66 112z",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round",
                        "stroke-width": "32"
                    }), Ti("circle", {
                        cx: "256",
                        cy: "256",
                        r: "80",
                        fill: "none",
                        stroke: "currentColor",
                        "stroke-miterlimit": "10",
                        "stroke-width": "32"
                    }))
                }
            }),
            dp = Tn({
                name: "EyeOff",
                render() {
                    return Ti("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 512 512"
                    }, Ti("path", {
                        d: "M432 448a15.92 15.92 0 0 1-11.31-4.69l-352-352a16 16 0 0 1 22.62-22.62l352 352A16 16 0 0 1 432 448z",
                        fill: "currentColor"
                    }), Ti("path", {
                        d: "M255.66 384c-41.49 0-81.5-12.28-118.92-36.5c-34.07-22-64.74-53.51-88.7-91v-.08c19.94-28.57 41.78-52.73 65.24-72.21a2 2 0 0 0 .14-2.94L93.5 161.38a2 2 0 0 0-2.71-.12c-24.92 21-48.05 46.76-69.08 76.92a31.92 31.92 0 0 0-.64 35.54c26.41 41.33 60.4 76.14 98.28 100.65C162 402 207.9 416 255.66 416a239.13 239.13 0 0 0 75.8-12.58a2 2 0 0 0 .77-3.31l-21.58-21.58a4 4 0 0 0-3.83-1a204.8 204.8 0 0 1-51.16 6.47z",
                        fill: "currentColor"
                    }), Ti("path", {
                        d: "M490.84 238.6c-26.46-40.92-60.79-75.68-99.27-100.53C349 110.55 302 96 255.66 96a227.34 227.34 0 0 0-74.89 12.83a2 2 0 0 0-.75 3.31l21.55 21.55a4 4 0 0 0 3.88 1a192.82 192.82 0 0 1 50.21-6.69c40.69 0 80.58 12.43 118.55 37c34.71 22.4 65.74 53.88 89.76 91a.13.13 0 0 1 0 .16a310.72 310.72 0 0 1-64.12 72.73a2 2 0 0 0-.15 2.95l19.9 19.89a2 2 0 0 0 2.7.13a343.49 343.49 0 0 0 68.64-78.48a32.2 32.2 0 0 0-.1-34.78z",
                        fill: "currentColor"
                    }), Ti("path", {
                        d: "M256 160a95.88 95.88 0 0 0-21.37 2.4a2 2 0 0 0-1 3.38l112.59 112.56a2 2 0 0 0 3.38-1A96 96 0 0 0 256 160z",
                        fill: "currentColor"
                    }), Ti("path", {
                        d: "M165.78 233.66a2 2 0 0 0-3.38 1a96 96 0 0 0 115 115a2 2 0 0 0 1-3.38z",
                        fill: "currentColor"
                    }))
                }
            });
        const fp = "undefined" != typeof window && (/iPad|iPhone|iPod/.test(navigator.platform) || "MacIntel" === navigator.platform && navigator.maxTouchPoints > 1) && !window.MSStream;

        function pp() {
            return fp
        }

        function hp(e) {
            return e.composedPath()[0] || null
        }

        function vp(e) {
            const {
                left: t,
                right: n,
                top: o,
                bottom: r
            } = hf(e);
            return `${o} ${n} ${r} ${t}`
        }
        const gp = Tn({
                render() {
                    var e, t;
                    return null === (t = (e = this.$slots).default) || void 0 === t ? void 0 : t.call(e)
                }
            }),
            bp = {
                railInsetHorizontal: "auto 2px 4px 2px",
                railInsetVertical: "2px 4px 2px auto",
                railColor: "transparent"
            };
        var mp = {
            name: "Scrollbar",
            common: of,
            self: function(e) {
                const {
                    scrollbarColor: t,
                    scrollbarColorHover: n,
                    scrollbarHeight: o,
                    scrollbarWidth: r,
                    scrollbarBorderRadius: i
                } = e;
                return Object.assign(Object.assign({}, bp), {
                    height: o,
                    width: r,
                    borderRadius: i,
                    color: t,
                    colorHover: n
                })
            }
        };
        const {
            cubicBezierEaseInOut: yp
        } = Du;
        var xp = Ru("scrollbar", "\n overflow: hidden;\n position: relative;\n z-index: auto;\n height: 100%;\n width: 100%;\n", [Fu(">", [Ru("scrollbar-container", "\n width: 100%;\n overflow: scroll;\n height: 100%;\n min-height: inherit;\n max-height: inherit;\n scrollbar-width: none;\n ", [Fu("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb", "\n width: 0;\n height: 0;\n display: none;\n "), Fu(">", [Ru("scrollbar-content", "\n box-sizing: border-box;\n min-width: 100%;\n ")])])]), Fu(">, +", [Ru("scrollbar-rail", "\n position: absolute;\n pointer-events: none;\n user-select: none;\n background: var(--n-scrollbar-rail-color);\n -webkit-user-select: none;\n ", [Ou("horizontal", "\n inset: var(--n-scrollbar-rail-inset-horizontal);\n height: var(--n-scrollbar-height);\n ", [Fu(">", [Eu("scrollbar", "\n height: var(--n-scrollbar-height);\n border-radius: var(--n-scrollbar-border-radius);\n right: 0;\n ")])]), Ou("vertical", "\n inset: var(--n-scrollbar-rail-inset-vertical);\n width: var(--n-scrollbar-width);\n ", [Fu(">", [Eu("scrollbar", "\n width: var(--n-scrollbar-width);\n border-radius: var(--n-scrollbar-border-radius);\n bottom: 0;\n ")])]), Ou("disabled", [Fu(">", [Eu("scrollbar", "pointer-events: none;")])]), Fu(">", [Eu("scrollbar", "\n z-index: 1;\n position: absolute;\n cursor: pointer;\n pointer-events: all;\n background-color: var(--n-scrollbar-color);\n transition: background-color .2s var(--n-scrollbar-bezier);\n ", [function({
            name: e = "fade-in",
            enterDuration: t = "0.2s",
            leaveDuration: n = "0.2s",
            enterCubicBezier: o = yp,
            leaveCubicBezier: r = yp
        } = {}) {
            return [Fu(`&.${e}-transition-enter-active`, {
                transition: `all ${t} ${o}!important`
            }), Fu(`&.${e}-transition-leave-active`, {
                transition: `all ${n} ${r}!important`
            }), Fu(`&.${e}-transition-enter-from, &.${e}-transition-leave-to`, {
                opacity: 0
            }), Fu(`&.${e}-transition-leave-from, &.${e}-transition-enter-to`, {
                opacity: 1
            })]
        }(), Fu("&:hover", "background-color: var(--n-scrollbar-color-hover);")])])])])]);
        const wp = Tn({
            name: "Scrollbar",
            props: Object.assign(Object.assign({}, Vu.props), {
                duration: {
                    type: Number,
                    default: 0
                },
                scrollable: {
                    type: Boolean,
                    default: !0
                },
                xScrollable: Boolean,
                trigger: {
                    type: String,
                    default: "hover"
                },
                useUnifiedContainer: Boolean,
                triggerDisplayManually: Boolean,
                container: Function,
                content: Function,
                containerClass: String,
                containerStyle: [String, Object],
                contentClass: [String, Array],
                contentStyle: [String, Object],
                horizontalRailStyle: [String, Object],
                verticalRailStyle: [String, Object],
                onScroll: Function,
                onWheel: Function,
                onResize: Function,
                internalOnUpdateScrollLeft: Function,
                internalHoistYRail: Boolean
            }),
            inheritAttrs: !1,
            setup(e) {
                const {
                    mergedClsPrefixRef: t,
                    inlineThemeDisabled: n,
                    mergedRtlRef: o
                } = zc(e), r = lu("Scrollbar", o, t), i = Ft(null), l = Ft(null), a = Ft(null), s = Ft(null), c = Ft(null), u = Ft(null), d = Ft(null), f = Ft(null), p = Ft(null), h = Ft(null), v = Ft(null), g = Ft(0), b = Ft(0), m = Ft(!1), y = Ft(!1);
                let x, w, C = !1,
                    S = !1,
                    k = 0,
                    $ = 0,
                    _ = 0,
                    z = 0;
                const T = pp(),
                    P = Vu("Scrollbar", "-scrollbar", xp, mp, e, t),
                    F = zi((() => {
                        const {
                            value: e
                        } = f, {
                            value: t
                        } = u, {
                            value: n
                        } = h;
                        return null === e || null === t || null === n ? 0 : Math.min(e, n * e / t + 1.5 * ff(P.value.self.width))
                    })),
                    M = zi((() => `${F.value}px`)),
                    R = zi((() => {
                        const {
                            value: e
                        } = p, {
                            value: t
                        } = d, {
                            value: n
                        } = v;
                        return null === e || null === t || null === n ? 0 : n * e / t + 1.5 * ff(P.value.self.height)
                    })),
                    E = zi((() => `${R.value}px`)),
                    O = zi((() => {
                        const {
                            value: e
                        } = f, {
                            value: t
                        } = g, {
                            value: n
                        } = u, {
                            value: o
                        } = h;
                        if (null === e || null === n || null === o) return 0;
                        {
                            const r = n - e;
                            return r ? t / r * (o - F.value) : 0
                        }
                    })),
                    B = zi((() => `${O.value}px`)),
                    A = zi((() => {
                        const {
                            value: e
                        } = p, {
                            value: t
                        } = b, {
                            value: n
                        } = d, {
                            value: o
                        } = v;
                        if (null === e || null === n || null === o) return 0;
                        {
                            const r = n - e;
                            return r ? t / r * (o - R.value) : 0
                        }
                    })),
                    I = zi((() => `${A.value}px`)),
                    D = zi((() => {
                        const {
                            value: e
                        } = f, {
                            value: t
                        } = u;
                        return null !== e && null !== t && t > e
                    })),
                    L = zi((() => {
                        const {
                            value: e
                        } = p, {
                            value: t
                        } = d;
                        return null !== e && null !== t && t > e
                    })),
                    j = zi((() => {
                        const {
                            trigger: t
                        } = e;
                        return "none" === t || m.value
                    })),
                    N = zi((() => {
                        const {
                            trigger: t
                        } = e;
                        return "none" === t || y.value
                    })),
                    H = zi((() => {
                        const {
                            container: t
                        } = e;
                        return t ? t() : l.value
                    })),
                    W = zi((() => {
                        const {
                            content: t
                        } = e;
                        return t ? t() : a.value
                    })),
                    V = (t, n) => {
                        if (!e.scrollable) return;
                        if ("number" == typeof t) return void U(t, null != n ? n : 0, 0, !1, "auto");
                        const {
                            left: o,
                            top: r,
                            index: i,
                            elSize: l,
                            position: a,
                            behavior: s,
                            el: c,
                            debounce: u = !0
                        } = t;
                        void 0 === o && void 0 === r || U(null != o ? o : 0, null != r ? r : 0, 0, !1, s), void 0 !== c ? U(0, c.offsetTop, c.offsetHeight, u, s) : void 0 !== i && void 0 !== l ? U(0, i * l, l, u, s) : "bottom" === a ? U(0, Number.MAX_SAFE_INTEGER, 0, !1, s) : "top" === a && U(0, 0, 0, !1, s)
                    },
                    q = function(e) {
                        const t = {
                            isDeactivated: !1
                        };
                        let n = !1;
                        return Rn((() => {
                            t.isDeactivated = !1, n ? e() : n = !0
                        })), En((() => {
                            t.isDeactivated = !0, n || (n = !0)
                        })), t
                    }((() => {
                        e.container || V({
                            top: g.value,
                            left: b.value
                        })
                    }));

                function U(e, t, n, o, r) {
                    const {
                        value: i
                    } = H;
                    if (i) {
                        if (o) {
                            const {
                                scrollTop: o,
                                offsetHeight: l
                            } = i;
                            if (t > o) return void(t + n <= o + l || i.scrollTo({
                                left: e,
                                top: t + n - l,
                                behavior: r
                            }))
                        }
                        i.scrollTo({
                            left: e,
                            top: t,
                            behavior: r
                        })
                    }
                }

                function K() {
                    ! function() {
                        void 0 !== w && window.clearTimeout(w);
                        w = window.setTimeout((() => {
                            y.value = !1
                        }), e.duration)
                    }(),
                    function() {
                        void 0 !== x && window.clearTimeout(x);
                        x = window.setTimeout((() => {
                            m.value = !1
                        }), e.duration)
                    }()
                }

                function G() {
                    const {
                        value: e
                    } = H;
                    e && (g.value = e.scrollTop, b.value = e.scrollLeft * ((null == r ? void 0 : r.value) ? -1 : 1))
                }

                function X() {
                    const {
                        value: e
                    } = H;
                    e && (g.value = e.scrollTop, b.value = e.scrollLeft * ((null == r ? void 0 : r.value) ? -1 : 1), f.value = e.offsetHeight, p.value = e.offsetWidth, u.value = e.scrollHeight, d.value = e.scrollWidth);
                    const {
                        value: t
                    } = c, {
                        value: n
                    } = s;
                    t && (v.value = t.offsetWidth), n && (h.value = n.offsetHeight)
                }

                function Y() {
                    e.scrollable && (e.useUnifiedContainer ? X() : (! function() {
                        const {
                            value: e
                        } = W;
                        e && (u.value = e.offsetHeight, d.value = e.offsetWidth);
                        const {
                            value: t
                        } = H;
                        t && (f.value = t.offsetHeight, p.value = t.offsetWidth);
                        const {
                            value: n
                        } = c, {
                            value: o
                        } = s;
                        n && (v.value = n.offsetWidth), o && (h.value = o.offsetHeight)
                    }(), G()))
                }

                function Z(e) {
                    var t;
                    return !(null === (t = i.value) || void 0 === t ? void 0 : t.contains(hp(e)))
                }

                function J(t) {
                    if (!S) return;
                    void 0 !== x && window.clearTimeout(x), void 0 !== w && window.clearTimeout(w);
                    const {
                        value: n
                    } = p, {
                        value: o
                    } = d, {
                        value: i
                    } = R;
                    if (null === n || null === o) return;
                    const l = (null == r ? void 0 : r.value) ? window.innerWidth - t.clientX - _ : t.clientX - _,
                        a = o - n;
                    let s = $ + l * (o - n) / (n - i);
                    s = Math.min(a, s), s = Math.max(s, 0);
                    const {
                        value: c
                    } = H;
                    if (c) {
                        c.scrollLeft = s * ((null == r ? void 0 : r.value) ? -1 : 1);
                        const {
                            internalOnUpdateScrollLeft: t
                        } = e;
                        t && t(s)
                    }
                }

                function Q(e) {
                    e.preventDefault(), e.stopPropagation(), cp("mousemove", window, J, !0), cp("mouseup", window, Q, !0), S = !1, Y(), Z(e) && K()
                }

                function ee(e) {
                    if (!C) return;
                    void 0 !== x && window.clearTimeout(x), void 0 !== w && window.clearTimeout(w);
                    const {
                        value: t
                    } = f, {
                        value: n
                    } = u, {
                        value: o
                    } = F;
                    if (null === t || null === n) return;
                    const r = e.clientY - z,
                        i = n - t;
                    let l = k + r * (n - t) / (t - o);
                    l = Math.min(i, l), l = Math.max(l, 0);
                    const {
                        value: a
                    } = H;
                    a && (a.scrollTop = l)
                }

                function te(e) {
                    e.preventDefault(), e.stopPropagation(), cp("mousemove", window, ee, !0), cp("mouseup", window, te, !0), C = !1, Y(), Z(e) && K()
                }
                pr((() => {
                    const {
                        value: e
                    } = L, {
                        value: n
                    } = D, {
                        value: o
                    } = t, {
                        value: r
                    } = c, {
                        value: i
                    } = s;
                    r && (e ? r.classList.remove(`${o}-scrollbar-rail--disabled`) : r.classList.add(`${o}-scrollbar-rail--disabled`)), i && (n ? i.classList.remove(`${o}-scrollbar-rail--disabled`) : i.classList.add(`${o}-scrollbar-rail--disabled`))
                })), Nn((() => {
                    e.container || Y()
                })), Vn((() => {
                    void 0 !== x && window.clearTimeout(x), void 0 !== w && window.clearTimeout(w), cp("mousemove", window, ee, !0), cp("mouseup", window, te, !0)
                }));
                const ne = zi((() => {
                        const {
                            common: {
                                cubicBezierEaseInOut: e
                            },
                            self: {
                                color: t,
                                colorHover: n,
                                height: o,
                                width: i,
                                borderRadius: l,
                                railInsetHorizontal: a,
                                railInsetVertical: s,
                                railColor: c
                            }
                        } = P.value;
                        return {
                            "--n-scrollbar-bezier": e,
                            "--n-scrollbar-color": t,
                            "--n-scrollbar-color-hover": n,
                            "--n-scrollbar-border-radius": l,
                            "--n-scrollbar-width": i,
                            "--n-scrollbar-height": o,
                            "--n-scrollbar-rail-inset-horizontal": a,
                            "--n-scrollbar-rail-inset-vertical": (null == r ? void 0 : r.value) ? vp(s) : s,
                            "--n-scrollbar-rail-color": c
                        }
                    })),
                    oe = n ? Ku("scrollbar", void 0, ne, e) : void 0,
                    re = {
                        scrollTo: V,
                        scrollBy: (t, n) => {
                            if (!e.scrollable) return;
                            const {
                                value: o
                            } = H;
                            o && ("object" == typeof t ? o.scrollBy(t) : o.scrollBy(t, n || 0))
                        },
                        sync: Y,
                        syncUnifiedContainer: X,
                        handleMouseEnterWrapper: function() {
                            ! function() {
                                void 0 !== x && window.clearTimeout(x);
                                m.value = !0
                            }(),
                            function() {
                                void 0 !== w && window.clearTimeout(w);
                                y.value = !0
                            }(), Y()
                        },
                        handleMouseLeaveWrapper: function() {
                            K()
                        }
                    };
                return Object.assign(Object.assign({}, re), {
                    mergedClsPrefix: t,
                    rtlEnabled: r,
                    containerScrollTop: g,
                    wrapperRef: i,
                    containerRef: l,
                    contentRef: a,
                    yRailRef: s,
                    xRailRef: c,
                    needYBar: D,
                    needXBar: L,
                    yBarSizePx: M,
                    xBarSizePx: E,
                    yBarTopPx: B,
                    xBarLeftPx: I,
                    isShowXBar: j,
                    isShowYBar: N,
                    isIos: T,
                    handleScroll: function(t) {
                        const {
                            onScroll: n
                        } = e;
                        n && n(t), G()
                    },
                    handleContentResize: () => {
                        q.isDeactivated || Y()
                    },
                    handleContainerResize: t => {
                        if (q.isDeactivated) return;
                        const {
                            onResize: n
                        } = e;
                        n && n(t), Y()
                    },
                    handleYScrollMouseDown: function(e) {
                        e.preventDefault(), e.stopPropagation(), C = !0, sp("mousemove", window, ee, !0), sp("mouseup", window, te, !0), k = g.value, z = e.clientY
                    },
                    handleXScrollMouseDown: function(e) {
                        e.preventDefault(), e.stopPropagation(), S = !0, sp("mousemove", window, J, !0), sp("mouseup", window, Q, !0), $ = b.value, _ = (null == r ? void 0 : r.value) ? window.innerWidth - e.clientX : e.clientX
                    },
                    cssVars: n ? void 0 : ne,
                    themeClass: null == oe ? void 0 : oe.themeClass,
                    onRender: null == oe ? void 0 : oe.onRender
                })
            },
            render() {
                var e;
                const {
                    $slots: t,
                    mergedClsPrefix: n,
                    triggerDisplayManually: o,
                    rtlEnabled: r,
                    internalHoistYRail: i
                } = this;
                if (!this.scrollable) return null === (e = t.default) || void 0 === e ? void 0 : e.call(t);
                const l = "none" === this.trigger,
                    a = (e, t) => Ti("div", {
                        ref: "yRailRef",
                        class: [`${n}-scrollbar-rail`, `${n}-scrollbar-rail--vertical`, e],
                        "data-scrollbar-rail": !0,
                        style: [t || "", this.verticalRailStyle],
                        "aria-hidden": !0
                    }, Ti(l ? gp : Ai, l ? null : {
                        name: "fade-in-transition"
                    }, {
                        default: () => this.needYBar && this.isShowYBar && !this.isIos ? Ti("div", {
                            class: `${n}-scrollbar-rail__scrollbar`,
                            style: {
                                height: this.yBarSizePx,
                                top: this.yBarTopPx
                            },
                            onMousedown: this.handleYScrollMouseDown
                        }) : null
                    })),
                    s = () => {
                        var e, s;
                        return null === (e = this.onRender) || void 0 === e || e.call(this), Ti("div", ri(this.$attrs, {
                            role: "none",
                            ref: "wrapperRef",
                            class: [`${n}-scrollbar`, this.themeClass, r && `${n}-scrollbar--rtl`],
                            style: this.cssVars,
                            onMouseenter: o ? void 0 : this.handleMouseEnterWrapper,
                            onMouseleave: o ? void 0 : this.handleMouseLeaveWrapper
                        }), [this.container ? null === (s = t.default) || void 0 === s ? void 0 : s.call(t) : Ti("div", {
                            role: "none",
                            ref: "containerRef",
                            class: [`${n}-scrollbar-container`, this.containerClass],
                            style: this.containerStyle,
                            onScroll: this.handleScroll,
                            onWheel: this.onWheel
                        }, Ti(np, {
                            onResize: this.handleContentResize
                        }, {
                            default: () => Ti("div", {
                                ref: "contentRef",
                                role: "none",
                                style: [{
                                    width: this.xScrollable ? "fit-content" : null
                                }, this.contentStyle],
                                class: [`${n}-scrollbar-content`, this.contentClass]
                            }, t)
                        })), i ? null : a(void 0, void 0), this.xScrollable && Ti("div", {
                            ref: "xRailRef",
                            class: [`${n}-scrollbar-rail`, `${n}-scrollbar-rail--horizontal`],
                            style: this.horizontalRailStyle,
                            "data-scrollbar-rail": !0,
                            "aria-hidden": !0
                        }, Ti(l ? gp : Ai, l ? null : {
                            name: "fade-in-transition"
                        }, {
                            default: () => this.needXBar && this.isShowXBar && !this.isIos ? Ti("div", {
                                class: `${n}-scrollbar-rail__scrollbar`,
                                style: {
                                    width: this.xBarSizePx,
                                    right: r ? this.xBarLeftPx : void 0,
                                    left: r ? void 0 : this.xBarLeftPx
                                },
                                onMousedown: this.handleXScrollMouseDown
                            }) : null
                        }))])
                    },
                    c = this.container ? s() : Ti(np, {
                        onResize: this.handleContainerResize
                    }, {
                        default: s
                    });
                return i ? Ti(Mr, null, c, a(this.themeClass, this.cssVars)) : c
            }
        });
        var Cp = wp;
        const Sp = wp;
        var kp = function(e, t, n) {
            var o = -1,
                r = e.length;
            t < 0 && (t = -t > r ? 0 : r + t), (n = n > r ? r : n) < 0 && (n += r), r = t > n ? 0 : n - t >>> 0, t >>>= 0;
            for (var i = Array(r); ++o < r;) i[o] = e[o + t];
            return i
        };
        var $p = function(e, t, n) {
                var o = e.length;
                return n = void 0 === n ? o : n, !t && n >= o ? e : kp(e, t, n)
            },
            _p = RegExp("[\\u200d\\ud800-\\udfff\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff\\ufe0e\\ufe0f]");
        var zp = function(e) {
            return _p.test(e)
        };
        var Tp = function(e) {
                return e.split("")
            },
            Pp = "\\ud800-\\udfff",
            Fp = "[" + Pp + "]",
            Mp = "[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]",
            Rp = "\\ud83c[\\udffb-\\udfff]",
            Ep = "[^" + Pp + "]",
            Op = "(?:\\ud83c[\\udde6-\\uddff]){2}",
            Bp = "[\\ud800-\\udbff][\\udc00-\\udfff]",
            Ap = "(?:" + Mp + "|" + Rp + ")" + "?",
            Ip = "[\\ufe0e\\ufe0f]?",
            Dp = Ip + Ap + ("(?:\\u200d(?:" + [Ep, Op, Bp].join("|") + ")" + Ip + Ap + ")*"),
            Lp = "(?:" + [Ep + Mp + "?", Mp, Op, Bp, Fp].join("|") + ")",
            jp = RegExp(Rp + "(?=" + Rp + ")|" + Lp + Dp, "g");
        var Np = function(e) {
            return e.match(jp) || []
        };
        var Hp = function(e) {
            return zp(e) ? Np(e) : Tp(e)
        };
        var Wp = function(e, t) {
            for (var n = -1, o = null == e ? 0 : e.length, r = Array(o); ++n < o;) r[n] = t(e[n], n, e);
            return r
        };
        var Vp = function(e) {
                return "symbol" == typeof e || bs(e) && "[object Symbol]" == ua(e)
            },
            qp = ta ? ta.prototype : void 0,
            Up = qp ? qp.toString : void 0;
        var Kp = function e(t) {
            if ("string" == typeof t) return t;
            if (ks(t)) return Wp(t, e) + "";
            if (Vp(t)) return Up ? Up.call(t) : "";
            var n = t + "";
            return "0" == n && 1 / t == -1 / 0 ? "-0" : n
        };
        var Gp = function(e) {
            return null == e ? "" : Kp(e)
        };
        var Xp = function(e) {
            return function(t) {
                t = Gp(t);
                var n = zp(t) ? Hp(t) : void 0,
                    o = n ? n[0] : t.charAt(0),
                    r = n ? $p(n, 1).join("") : t.slice(1);
                return o[e]() + r
            }
        }("toUpperCase");

        function Yp(e, t) {
            return Tn({
                name: Xp(e),
                setup() {
                    var n;
                    const o = null === (n = _o($c, null)) || void 0 === n ? void 0 : n.mergedIconsRef;
                    return () => {
                        var n;
                        const r = null === (n = null == o ? void 0 : o.value) || void 0 === n ? void 0 : n[e];
                        return r ? r() : t
                    }
                }
            })
        }
        var Zp = Yp("clear", Ti("svg", {
                viewBox: "0 0 16 16",
                version: "1.1",
                xmlns: "http://www.w3.org/2000/svg"
            }, Ti("g", {
                stroke: "none",
                "stroke-width": "1",
                fill: "none",
                "fill-rule": "evenodd"
            }, Ti("g", {
                fill: "currentColor",
                "fill-rule": "nonzero"
            }, Ti("path", {
                d: "M8,2 C11.3137085,2 14,4.6862915 14,8 C14,11.3137085 11.3137085,14 8,14 C4.6862915,14 2,11.3137085 2,8 C2,4.6862915 4.6862915,2 8,2 Z M6.5343055,5.83859116 C6.33943736,5.70359511 6.07001296,5.72288026 5.89644661,5.89644661 L5.89644661,5.89644661 L5.83859116,5.9656945 C5.70359511,6.16056264 5.72288026,6.42998704 5.89644661,6.60355339 L5.89644661,6.60355339 L7.293,8 L5.89644661,9.39644661 L5.83859116,9.4656945 C5.70359511,9.66056264 5.72288026,9.92998704 5.89644661,10.1035534 L5.89644661,10.1035534 L5.9656945,10.1614088 C6.16056264,10.2964049 6.42998704,10.2771197 6.60355339,10.1035534 L6.60355339,10.1035534 L8,8.707 L9.39644661,10.1035534 L9.4656945,10.1614088 C9.66056264,10.2964049 9.92998704,10.2771197 10.1035534,10.1035534 L10.1035534,10.1035534 L10.1614088,10.0343055 C10.2964049,9.83943736 10.2771197,9.57001296 10.1035534,9.39644661 L10.1035534,9.39644661 L8.707,8 L10.1035534,6.60355339 L10.1614088,6.5343055 C10.2964049,6.33943736 10.2771197,6.07001296 10.1035534,5.89644661 L10.1035534,5.89644661 L10.0343055,5.83859116 C9.83943736,5.70359511 9.57001296,5.72288026 9.39644661,5.89644661 L9.39644661,5.89644661 L8,7.293 L6.60355339,5.89644661 Z"
            }))))),
            Jp = Ru("base-icon", "\n height: 1em;\n width: 1em;\n line-height: 1em;\n text-align: center;\n display: inline-block;\n position: relative;\n fill: currentColor;\n transform: translateZ(0);\n", [Fu("svg", "\n height: 1em;\n width: 1em;\n ")]),
            Qp = Tn({
                name: "BaseIcon",
                props: {
                    role: String,
                    ariaLabel: String,
                    ariaDisabled: {
                        type: Boolean,
                        default: void 0
                    },
                    ariaHidden: {
                        type: Boolean,
                        default: void 0
                    },
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    onClick: Function,
                    onMousedown: Function,
                    onMouseup: Function
                },
                setup(e) {
                    Zu("-base-icon", Jp, Dt(e, "clsPrefix"))
                },
                render() {
                    return Ti("i", {
                        class: `${this.clsPrefix}-base-icon`,
                        onClick: this.onClick,
                        onMousedown: this.onMousedown,
                        onMouseup: this.onMouseup,
                        role: this.role,
                        "aria-label": this.ariaLabel,
                        "aria-hidden": this.ariaHidden,
                        "aria-disabled": this.ariaDisabled
                    }, this.$slots)
                }
            }),
            eh = Ru("base-clear", "\n flex-shrink: 0;\n height: 1em;\n width: 1em;\n position: relative;\n", [Fu(">", [Eu("clear", "\n font-size: var(--n-clear-size);\n height: 1em;\n width: 1em;\n cursor: pointer;\n color: var(--n-clear-color);\n transition: color .3s var(--n-bezier);\n display: flex;\n ", [Fu("&:hover", "\n color: var(--n-clear-color-hover)!important;\n "), Fu("&:active", "\n color: var(--n-clear-color-pressed)!important;\n ")]), Eu("placeholder", "\n display: flex;\n "), Eu("clear, placeholder", "\n position: absolute;\n left: 50%;\n top: 50%;\n transform: translateX(-50%) translateY(-50%);\n ", [Qu({
                originalTransform: "translateX(-50%) translateY(-50%)",
                left: "50%",
                top: "50%"
            })])])]),
            th = Tn({
                name: "BaseClear",
                props: {
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    show: Boolean,
                    onClear: Function
                },
                setup(e) {
                    return Zu("-base-clear", eh, Dt(e, "clsPrefix")), {
                        handleMouseDown(e) {
                            e.preventDefault()
                        }
                    }
                },
                render() {
                    const {
                        clsPrefix: e
                    } = this;
                    return Ti("div", {
                        class: `${e}-base-clear`
                    }, Ti(Yu, null, {
                        default: () => {
                            var t, n;
                            return this.show ? Ti("div", {
                                key: "dismiss",
                                class: `${e}-base-clear__clear`,
                                onClick: this.onClear,
                                onMousedown: this.handleMouseDown,
                                "data-clear": !0
                            }, cd(this.$slots.icon, (() => [Ti(Qp, {
                                clsPrefix: e
                            }, {
                                default: () => Ti(Zp, null)
                            })]))) : Ti("div", {
                                key: "icon",
                                class: `${e}-base-clear__placeholder`
                            }, null === (n = (t = this.$slots).placeholder) || void 0 === n ? void 0 : n.call(t))
                        }
                    }))
                }
            }),
            nh = Tn({
                name: "ChevronDown",
                render() {
                    return Ti("svg", {
                        viewBox: "0 0 16 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, Ti("path", {
                        d: "M3.14645 5.64645C3.34171 5.45118 3.65829 5.45118 3.85355 5.64645L8 9.79289L12.1464 5.64645C12.3417 5.45118 12.6583 5.45118 12.8536 5.64645C13.0488 5.84171 13.0488 6.15829 12.8536 6.35355L8.35355 10.8536C8.15829 11.0488 7.84171 11.0488 7.64645 10.8536L3.14645 6.35355C2.95118 6.15829 2.95118 5.84171 3.14645 5.64645Z",
                        fill: "currentColor"
                    }))
                }
            }),
            oh = Tn({
                name: "InternalSelectionSuffix",
                props: {
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    showArrow: {
                        type: Boolean,
                        default: void 0
                    },
                    showClear: {
                        type: Boolean,
                        default: void 0
                    },
                    loading: {
                        type: Boolean,
                        default: !1
                    },
                    onClear: Function
                },
                setup(e, {
                    slots: t
                }) {
                    return () => {
                        const {
                            clsPrefix: n
                        } = e;
                        return Ti(od, {
                            clsPrefix: n,
                            class: `${n}-base-suffix`,
                            strokeWidth: 24,
                            scale: .85,
                            show: e.loading
                        }, {
                            default: () => e.showArrow ? Ti(th, {
                                clsPrefix: n,
                                show: e.showClear,
                                onClear: e.onClear
                            }, {
                                placeholder: () => Ti(Qp, {
                                    clsPrefix: n,
                                    class: `${n}-base-suffix__arrow`
                                }, {
                                    default: () => cd(t.default, (() => [Ti(nh, null)]))
                                })
                            }) : null
                        })
                    }
                }
            });
        var rh = {
                name: "en-US",
                global: {
                    undo: "Undo",
                    redo: "Redo",
                    confirm: "Confirm",
                    clear: "Clear"
                },
                Popconfirm: {
                    positiveText: "Confirm",
                    negativeText: "Cancel"
                },
                Cascader: {
                    placeholder: "Please Select",
                    loading: "Loading",
                    loadingRequiredMessage: e => `Please load all ${e}'s descendants before checking it.`
                },
                Time: {
                    dateFormat: "yyyy-MM-dd",
                    dateTimeFormat: "yyyy-MM-dd HH:mm:ss"
                },
                DatePicker: {
                    yearFormat: "yyyy",
                    monthFormat: "MMM",
                    dayFormat: "eeeeee",
                    yearTypeFormat: "yyyy",
                    monthTypeFormat: "yyyy-MM",
                    dateFormat: "yyyy-MM-dd",
                    dateTimeFormat: "yyyy-MM-dd HH:mm:ss",
                    quarterFormat: "yyyy-qqq",
                    weekFormat: "RRRR-w",
                    clear: "Clear",
                    now: "Now",
                    confirm: "Confirm",
                    selectTime: "Select Time",
                    selectDate: "Select Date",
                    datePlaceholder: "Select Date",
                    datetimePlaceholder: "Select Date and Time",
                    monthPlaceholder: "Select Month",
                    yearPlaceholder: "Select Year",
                    quarterPlaceholder: "Select Quarter",
                    weekPlaceholder: "Select Week",
                    startDatePlaceholder: "Start Date",
                    endDatePlaceholder: "End Date",
                    startDatetimePlaceholder: "Start Date and Time",
                    endDatetimePlaceholder: "End Date and Time",
                    startMonthPlaceholder: "Start Month",
                    endMonthPlaceholder: "End Month",
                    monthBeforeYear: !0,
                    firstDayOfWeek: 6,
                    today: "Today"
                },
                DataTable: {
                    checkTableAll: "Select all in the table",
                    uncheckTableAll: "Unselect all in the table",
                    confirm: "Confirm",
                    clear: "Clear"
                },
                LegacyTransfer: {
                    sourceTitle: "Source",
                    targetTitle: "Target"
                },
                Transfer: {
                    selectAll: "Select all",
                    unselectAll: "Unselect all",
                    clearAll: "Clear",
                    total: e => `Total ${e} items`,
                    selected: e => `${e} items selected`
                },
                Empty: {
                    description: "No Data"
                },
                Select: {
                    placeholder: "Please Select"
                },
                TimePicker: {
                    placeholder: "Select Time",
                    positiveText: "OK",
                    negativeText: "Cancel",
                    now: "Now",
                    clear: "Clear"
                },
                Pagination: {
                    goto: "Goto",
                    selectionSuffix: "page"
                },
                DynamicTags: {
                    add: "Add"
                },
                Log: {
                    loading: "Loading"
                },
                Input: {
                    placeholder: "Please Input"
                },
                InputNumber: {
                    placeholder: "Please Input"
                },
                DynamicInput: {
                    create: "Create"
                },
                ThemeEditor: {
                    title: "Theme Editor",
                    clearAllVars: "Clear All Variables",
                    clearSearch: "Clear Search",
                    filterCompName: "Filter Component Name",
                    filterVarName: "Filter Variable Name",
                    import: "Import",
                    export: "Export",
                    restore: "Reset to Default"
                },
                Image: {
                    tipPrevious: "Previous picture (←)",
                    tipNext: "Next picture (→)",
                    tipCounterclockwise: "Counterclockwise",
                    tipClockwise: "Clockwise",
                    tipZoomOut: "Zoom out",
                    tipZoomIn: "Zoom in",
                    tipDownload: "Download",
                    tipClose: "Close (Esc)",
                    tipOriginalSize: "Zoom to original size"
                }
            },
            ih = {
                lessThanXSeconds: {
                    one: "less than a second",
                    other: "less than {{count}} seconds"
                },
                xSeconds: {
                    one: "1 second",
                    other: "{{count}} seconds"
                },
                halfAMinute: "half a minute",
                lessThanXMinutes: {
                    one: "less than a minute",
                    other: "less than {{count}} minutes"
                },
                xMinutes: {
                    one: "1 minute",
                    other: "{{count}} minutes"
                },
                aboutXHours: {
                    one: "about 1 hour",
                    other: "about {{count}} hours"
                },
                xHours: {
                    one: "1 hour",
                    other: "{{count}} hours"
                },
                xDays: {
                    one: "1 day",
                    other: "{{count}} days"
                },
                aboutXWeeks: {
                    one: "about 1 week",
                    other: "about {{count}} weeks"
                },
                xWeeks: {
                    one: "1 week",
                    other: "{{count}} weeks"
                },
                aboutXMonths: {
                    one: "about 1 month",
                    other: "about {{count}} months"
                },
                xMonths: {
                    one: "1 month",
                    other: "{{count}} months"
                },
                aboutXYears: {
                    one: "about 1 year",
                    other: "about {{count}} years"
                },
                xYears: {
                    one: "1 year",
                    other: "{{count}} years"
                },
                overXYears: {
                    one: "over 1 year",
                    other: "over {{count}} years"
                },
                almostXYears: {
                    one: "almost 1 year",
                    other: "almost {{count}} years"
                }
            },
            lh = function(e, t, n) {
                var o, r = ih[e];
                return o = "string" == typeof r ? r : 1 === t ? r.one : r.other.replace("{{count}}", t.toString()), null != n && n.addSuffix ? n.comparison && n.comparison > 0 ? "in " + o : o + " ago" : o
            };

        function ah(e) {
            return function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    n = t.width ? String(t.width) : e.defaultWidth;
                return e.formats[n] || e.formats[e.defaultWidth]
            }
        }
        var sh = {
                date: ah({
                    formats: {
                        full: "EEEE, MMMM do, y",
                        long: "MMMM do, y",
                        medium: "MMM d, y",
                        short: "MM/dd/yyyy"
                    },
                    defaultWidth: "full"
                }),
                time: ah({
                    formats: {
                        full: "h:mm:ss a zzzz",
                        long: "h:mm:ss a z",
                        medium: "h:mm:ss a",
                        short: "h:mm a"
                    },
                    defaultWidth: "full"
                }),
                dateTime: ah({
                    formats: {
                        full: "{{date}} 'at' {{time}}",
                        long: "{{date}} 'at' {{time}}",
                        medium: "{{date}}, {{time}}",
                        short: "{{date}}, {{time}}"
                    },
                    defaultWidth: "full"
                })
            },
            ch = {
                lastWeek: "'last' eeee 'at' p",
                yesterday: "'yesterday at' p",
                today: "'today at' p",
                tomorrow: "'tomorrow at' p",
                nextWeek: "eeee 'at' p",
                other: "P"
            },
            uh = function(e, t, n, o) {
                return ch[e]
            };

        function dh(e) {
            return function(t, n) {
                var o;
                if ("formatting" === (null != n && n.context ? String(n.context) : "standalone") && e.formattingValues) {
                    var r = e.defaultFormattingWidth || e.defaultWidth,
                        i = null != n && n.width ? String(n.width) : r;
                    o = e.formattingValues[i] || e.formattingValues[r]
                } else {
                    var l = e.defaultWidth,
                        a = null != n && n.width ? String(n.width) : e.defaultWidth;
                    o = e.values[a] || e.values[l]
                }
                return o[e.argumentCallback ? e.argumentCallback(t) : t]
            }
        }
        var fh = {
            ordinalNumber: function(e, t) {
                var n = Number(e),
                    o = n % 100;
                if (o > 20 || o < 10) switch (o % 10) {
                    case 1:
                        return n + "st";
                    case 2:
                        return n + "nd";
                    case 3:
                        return n + "rd"
                }
                return n + "th"
            },
            era: dh({
                values: {
                    narrow: ["B", "A"],
                    abbreviated: ["BC", "AD"],
                    wide: ["Before Christ", "Anno Domini"]
                },
                defaultWidth: "wide"
            }),
            quarter: dh({
                values: {
                    narrow: ["1", "2", "3", "4"],
                    abbreviated: ["Q1", "Q2", "Q3", "Q4"],
                    wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
                },
                defaultWidth: "wide",
                argumentCallback: function(e) {
                    return e - 1
                }
            }),
            month: dh({
                values: {
                    narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
                    abbreviated: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                    wide: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                },
                defaultWidth: "wide"
            }),
            day: dh({
                values: {
                    narrow: ["S", "M", "T", "W", "T", "F", "S"],
                    short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                    abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                    wide: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
                },
                defaultWidth: "wide"
            }),
            dayPeriod: dh({
                values: {
                    narrow: {
                        am: "a",
                        pm: "p",
                        midnight: "mi",
                        noon: "n",
                        morning: "morning",
                        afternoon: "afternoon",
                        evening: "evening",
                        night: "night"
                    },
                    abbreviated: {
                        am: "AM",
                        pm: "PM",
                        midnight: "midnight",
                        noon: "noon",
                        morning: "morning",
                        afternoon: "afternoon",
                        evening: "evening",
                        night: "night"
                    },
                    wide: {
                        am: "a.m.",
                        pm: "p.m.",
                        midnight: "midnight",
                        noon: "noon",
                        morning: "morning",
                        afternoon: "afternoon",
                        evening: "evening",
                        night: "night"
                    }
                },
                defaultWidth: "wide",
                formattingValues: {
                    narrow: {
                        am: "a",
                        pm: "p",
                        midnight: "mi",
                        noon: "n",
                        morning: "in the morning",
                        afternoon: "in the afternoon",
                        evening: "in the evening",
                        night: "at night"
                    },
                    abbreviated: {
                        am: "AM",
                        pm: "PM",
                        midnight: "midnight",
                        noon: "noon",
                        morning: "in the morning",
                        afternoon: "in the afternoon",
                        evening: "in the evening",
                        night: "at night"
                    },
                    wide: {
                        am: "a.m.",
                        pm: "p.m.",
                        midnight: "midnight",
                        noon: "noon",
                        morning: "in the morning",
                        afternoon: "in the afternoon",
                        evening: "in the evening",
                        night: "at night"
                    }
                },
                defaultFormattingWidth: "wide"
            })
        };

        function ph(e) {
            return function(t) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    o = n.width,
                    r = o && e.matchPatterns[o] || e.matchPatterns[e.defaultMatchWidth],
                    i = t.match(r);
                if (!i) return null;
                var l, a = i[0],
                    s = o && e.parsePatterns[o] || e.parsePatterns[e.defaultParseWidth],
                    c = Array.isArray(s) ? function(e, t) {
                        for (var n = 0; n < e.length; n++)
                            if (t(e[n])) return n;
                        return
                    }(s, (function(e) {
                        return e.test(a)
                    })) : function(e, t) {
                        for (var n in e)
                            if (e.hasOwnProperty(n) && t(e[n])) return n;
                        return
                    }(s, (function(e) {
                        return e.test(a)
                    }));
                return l = e.valueCallback ? e.valueCallback(c) : c, {
                    value: l = n.valueCallback ? n.valueCallback(l) : l,
                    rest: t.slice(a.length)
                }
            }
        }
        var hh, vh = {
            ordinalNumber: (hh = {
                matchPattern: /^(\d+)(th|st|nd|rd)?/i,
                parsePattern: /\d+/i,
                valueCallback: function(e) {
                    return parseInt(e, 10)
                }
            }, function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    n = e.match(hh.matchPattern);
                if (!n) return null;
                var o = n[0],
                    r = e.match(hh.parsePattern);
                if (!r) return null;
                var i = hh.valueCallback ? hh.valueCallback(r[0]) : r[0];
                return {
                    value: i = t.valueCallback ? t.valueCallback(i) : i,
                    rest: e.slice(o.length)
                }
            }),
            era: ph({
                matchPatterns: {
                    narrow: /^(b|a)/i,
                    abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
                    wide: /^(before christ|before common era|anno domini|common era)/i
                },
                defaultMatchWidth: "wide",
                parsePatterns: {
                    any: [/^b/i, /^(a|c)/i]
                },
                defaultParseWidth: "any"
            }),
            quarter: ph({
                matchPatterns: {
                    narrow: /^[1234]/i,
                    abbreviated: /^q[1234]/i,
                    wide: /^[1234](th|st|nd|rd)? quarter/i
                },
                defaultMatchWidth: "wide",
                parsePatterns: {
                    any: [/1/i, /2/i, /3/i, /4/i]
                },
                defaultParseWidth: "any",
                valueCallback: function(e) {
                    return e + 1
                }
            }),
            month: ph({
                matchPatterns: {
                    narrow: /^[jfmasond]/i,
                    abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
                    wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
                },
                defaultMatchWidth: "wide",
                parsePatterns: {
                    narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
                    any: [/^ja/i, /^f/i, /^mar/i, /^ap/i, /^may/i, /^jun/i, /^jul/i, /^au/i, /^s/i, /^o/i, /^n/i, /^d/i]
                },
                defaultParseWidth: "any"
            }),
            day: ph({
                matchPatterns: {
                    narrow: /^[smtwf]/i,
                    short: /^(su|mo|tu|we|th|fr|sa)/i,
                    abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
                    wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
                },
                defaultMatchWidth: "wide",
                parsePatterns: {
                    narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
                    any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
                },
                defaultParseWidth: "any"
            }),
            dayPeriod: ph({
                matchPatterns: {
                    narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
                    any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
                },
                defaultMatchWidth: "any",
                parsePatterns: {
                    any: {
                        am: /^a/i,
                        pm: /^p/i,
                        midnight: /^mi/i,
                        noon: /^no/i,
                        morning: /morning/i,
                        afternoon: /afternoon/i,
                        evening: /evening/i,
                        night: /night/i
                    }
                },
                defaultParseWidth: "any"
            })
        };
        var gh = {
            name: "en-US",
            locale: {
                code: "en-US",
                formatDistance: lh,
                formatLong: sh,
                formatRelative: uh,
                localize: fh,
                match: vh,
                options: {
                    weekStartsOn: 0,
                    firstWeekContainsDate: 1
                }
            }
        };

        function bh(e) {
            const {
                mergedLocaleRef: t,
                mergedDateLocaleRef: n
            } = _o($c, null) || {}, o = zi((() => {
                var n, o;
                return null !== (o = null === (n = null == t ? void 0 : t.value) || void 0 === n ? void 0 : n[e]) && void 0 !== o ? o : rh[e]
            }));
            return {
                dateLocaleRef: zi((() => {
                    var e;
                    return null !== (e = null == n ? void 0 : n.value) && void 0 !== e ? e : gh
                })),
                localeRef: o
            }
        }
        var mh = {
            paddingTiny: "0 8px",
            paddingSmall: "0 10px",
            paddingMedium: "0 12px",
            paddingLarge: "0 14px",
            clearSize: "16px"
        };
        const yh = {
            name: "Input",
            common: of,
            self: function(e) {
                const {
                    textColor2: t,
                    textColor3: n,
                    textColorDisabled: o,
                    primaryColor: r,
                    primaryColorHover: i,
                    inputColor: l,
                    inputColorDisabled: a,
                    borderColor: s,
                    warningColor: c,
                    warningColorHover: u,
                    errorColor: d,
                    errorColorHover: f,
                    borderRadius: p,
                    lineHeight: h,
                    fontSizeTiny: v,
                    fontSizeSmall: g,
                    fontSizeMedium: b,
                    fontSizeLarge: m,
                    heightTiny: y,
                    heightSmall: x,
                    heightMedium: w,
                    heightLarge: C,
                    actionColor: S,
                    clearColor: k,
                    clearColorHover: $,
                    clearColorPressed: _,
                    placeholderColor: z,
                    placeholderColorDisabled: T,
                    iconColor: P,
                    iconColorDisabled: F,
                    iconColorHover: M,
                    iconColorPressed: R
                } = e;
                return Object.assign(Object.assign({}, mh), {
                    countTextColorDisabled: o,
                    countTextColor: n,
                    heightTiny: y,
                    heightSmall: x,
                    heightMedium: w,
                    heightLarge: C,
                    fontSizeTiny: v,
                    fontSizeSmall: g,
                    fontSizeMedium: b,
                    fontSizeLarge: m,
                    lineHeight: h,
                    lineHeightTextarea: h,
                    borderRadius: p,
                    iconSize: "16px",
                    groupLabelColor: S,
                    groupLabelTextColor: t,
                    textColor: t,
                    textColorDisabled: o,
                    textDecorationColor: t,
                    caretColor: r,
                    placeholderColor: z,
                    placeholderColorDisabled: T,
                    color: l,
                    colorDisabled: a,
                    colorFocus: l,
                    groupLabelBorder: `1px solid ${s}`,
                    border: `1px solid ${s}`,
                    borderHover: `1px solid ${i}`,
                    borderDisabled: `1px solid ${s}`,
                    borderFocus: `1px solid ${i}`,
                    boxShadowFocus: `0 0 0 2px ${Kc(r,{alpha:.2})}`,
                    loadingColor: r,
                    loadingColorWarning: c,
                    borderWarning: `1px solid ${c}`,
                    borderHoverWarning: `1px solid ${u}`,
                    colorFocusWarning: l,
                    borderFocusWarning: `1px solid ${u}`,
                    boxShadowFocusWarning: `0 0 0 2px ${Kc(c,{alpha:.2})}`,
                    caretColorWarning: c,
                    loadingColorError: d,
                    borderError: `1px solid ${d}`,
                    borderHoverError: `1px solid ${f}`,
                    colorFocusError: l,
                    borderFocusError: `1px solid ${f}`,
                    boxShadowFocusError: `0 0 0 2px ${Kc(d,{alpha:.2})}`,
                    caretColorError: d,
                    clearColor: k,
                    clearColorHover: $,
                    clearColorPressed: _,
                    iconColor: P,
                    iconColorDisabled: F,
                    iconColorHover: M,
                    iconColorPressed: R,
                    suffixTextColor: t
                })
            }
        };
        var xh = yh;
        const wh = "n-input";

        function Ch(e) {
            let t = 0;
            for (const n of e) t++;
            return t
        }

        function Sh(e) {
            return "" === e || null == e
        }
        var kh = Tn({
                name: "InputWordCount",
                setup(e, {
                    slots: t
                }) {
                    const {
                        mergedValueRef: n,
                        maxlengthRef: o,
                        mergedClsPrefixRef: r,
                        countGraphemesRef: i
                    } = _o(wh), l = zi((() => {
                        const {
                            value: e
                        } = n;
                        return null === e || Array.isArray(e) ? 0 : (i.value || Ch)(e)
                    }));
                    return () => {
                        const {
                            value: e
                        } = o, {
                            value: i
                        } = n;
                        return Ti("span", {
                            class: `${r.value}-input-word-count`
                        }, ud(t.default, {
                            value: null === i || Array.isArray(i) ? "" : i
                        }, (() => [void 0 === e ? l.value : `${l.value} / ${e}`])))
                    }
                }
            }),
            $h = Ru("input", "\n max-width: 100%;\n cursor: text;\n line-height: 1.5;\n z-index: auto;\n outline: none;\n box-sizing: border-box;\n position: relative;\n display: inline-flex;\n border-radius: var(--n-border-radius);\n background-color: var(--n-color);\n transition: background-color .3s var(--n-bezier);\n font-size: var(--n-font-size);\n --n-padding-vertical: calc((var(--n-height) - 1.5 * var(--n-font-size)) / 2);\n", [Eu("input, textarea", "\n overflow: hidden;\n flex-grow: 1;\n position: relative;\n "), Eu("input-el, textarea-el, input-mirror, textarea-mirror, separator, placeholder", "\n box-sizing: border-box;\n font-size: inherit;\n line-height: 1.5;\n font-family: inherit;\n border: none;\n outline: none;\n background-color: #0000;\n text-align: inherit;\n transition:\n -webkit-text-fill-color .3s var(--n-bezier),\n caret-color .3s var(--n-bezier),\n color .3s var(--n-bezier),\n text-decoration-color .3s var(--n-bezier);\n "), Eu("input-el, textarea-el", "\n -webkit-appearance: none;\n scrollbar-width: none;\n width: 100%;\n min-width: 0;\n text-decoration-color: var(--n-text-decoration-color);\n color: var(--n-text-color);\n caret-color: var(--n-caret-color);\n background-color: transparent;\n ", [Fu("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb", "\n width: 0;\n height: 0;\n display: none;\n "), Fu("&::placeholder", "\n color: #0000;\n -webkit-text-fill-color: transparent !important;\n "), Fu("&:-webkit-autofill ~", [Eu("placeholder", "display: none;")])]), Ou("round", [Bu("textarea", "border-radius: calc(var(--n-height) / 2);")]), Eu("placeholder", "\n pointer-events: none;\n position: absolute;\n left: 0;\n right: 0;\n top: 0;\n bottom: 0;\n overflow: hidden;\n color: var(--n-placeholder-color);\n ", [Fu("span", "\n width: 100%;\n display: inline-block;\n ")]), Ou("textarea", [Eu("placeholder", "overflow: visible;")]), Bu("autosize", "width: 100%;"), Ou("autosize", [Eu("textarea-el, input-el", "\n position: absolute;\n top: 0;\n left: 0;\n height: 100%;\n ")]), Ru("input-wrapper", "\n overflow: hidden;\n display: inline-flex;\n flex-grow: 1;\n position: relative;\n padding-left: var(--n-padding-left);\n padding-right: var(--n-padding-right);\n "), Eu("input-mirror", "\n padding: 0;\n height: var(--n-height);\n line-height: var(--n-height);\n overflow: hidden;\n visibility: hidden;\n position: static;\n white-space: pre;\n pointer-events: none;\n "), Eu("input-el", "\n padding: 0;\n height: var(--n-height);\n line-height: var(--n-height);\n ", [Fu("&[type=password]::-ms-reveal", "display: none;"), Fu("+", [Eu("placeholder", "\n display: flex;\n align-items: center; \n ")])]), Bu("textarea", [Eu("placeholder", "white-space: nowrap;")]), Eu("eye", "\n display: flex;\n align-items: center;\n justify-content: center;\n transition: color .3s var(--n-bezier);\n "), Ou("textarea", "width: 100%;", [Ru("input-word-count", "\n position: absolute;\n right: var(--n-padding-right);\n bottom: var(--n-padding-vertical);\n "), Ou("resizable", [Ru("input-wrapper", "\n resize: vertical;\n min-height: var(--n-height);\n ")]), Eu("textarea-el, textarea-mirror, placeholder", "\n height: 100%;\n padding-left: 0;\n padding-right: 0;\n padding-top: var(--n-padding-vertical);\n padding-bottom: var(--n-padding-vertical);\n word-break: break-word;\n display: inline-block;\n vertical-align: bottom;\n box-sizing: border-box;\n line-height: var(--n-line-height-textarea);\n margin: 0;\n resize: none;\n white-space: pre-wrap;\n scroll-padding-block-end: var(--n-padding-vertical);\n "), Eu("textarea-mirror", "\n width: 100%;\n pointer-events: none;\n overflow: hidden;\n visibility: hidden;\n position: static;\n white-space: pre-wrap;\n overflow-wrap: break-word;\n ")]), Ou("pair", [Eu("input-el, placeholder", "text-align: center;"), Eu("separator", "\n display: flex;\n align-items: center;\n transition: color .3s var(--n-bezier);\n color: var(--n-text-color);\n white-space: nowrap;\n ", [Ru("icon", "\n color: var(--n-icon-color);\n "), Ru("base-icon", "\n color: var(--n-icon-color);\n ")])]), Ou("disabled", "\n cursor: not-allowed;\n background-color: var(--n-color-disabled);\n ", [Eu("border", "border: var(--n-border-disabled);"), Eu("input-el, textarea-el", "\n cursor: not-allowed;\n color: var(--n-text-color-disabled);\n text-decoration-color: var(--n-text-color-disabled);\n "), Eu("placeholder", "color: var(--n-placeholder-color-disabled);"), Eu("separator", "color: var(--n-text-color-disabled);", [Ru("icon", "\n color: var(--n-icon-color-disabled);\n "), Ru("base-icon", "\n color: var(--n-icon-color-disabled);\n ")]), Ru("input-word-count", "\n color: var(--n-count-text-color-disabled);\n "), Eu("suffix, prefix", "color: var(--n-text-color-disabled);", [Ru("icon", "\n color: var(--n-icon-color-disabled);\n "), Ru("internal-icon", "\n color: var(--n-icon-color-disabled);\n ")])]), Bu("disabled", [Eu("eye", "\n color: var(--n-icon-color);\n cursor: pointer;\n ", [Fu("&:hover", "\n color: var(--n-icon-color-hover);\n "), Fu("&:active", "\n color: var(--n-icon-color-pressed);\n ")]), Fu("&:hover", [Eu("state-border", "border: var(--n-border-hover);")]), Ou("focus", "background-color: var(--n-color-focus);", [Eu("state-border", "\n border: var(--n-border-focus);\n box-shadow: var(--n-box-shadow-focus);\n ")])]), Eu("border, state-border", "\n box-sizing: border-box;\n position: absolute;\n left: 0;\n right: 0;\n top: 0;\n bottom: 0;\n pointer-events: none;\n border-radius: inherit;\n border: var(--n-border);\n transition:\n box-shadow .3s var(--n-bezier),\n border-color .3s var(--n-bezier);\n "), Eu("state-border", "\n border-color: #0000;\n z-index: 1;\n "), Eu("prefix", "margin-right: 4px;"), Eu("suffix", "\n margin-left: 4px;\n "), Eu("suffix, prefix", "\n transition: color .3s var(--n-bezier);\n flex-wrap: nowrap;\n flex-shrink: 0;\n line-height: var(--n-height);\n white-space: nowrap;\n display: inline-flex;\n align-items: center;\n justify-content: center;\n color: var(--n-suffix-text-color);\n ", [Ru("base-loading", "\n font-size: var(--n-icon-size);\n margin: 0 2px;\n color: var(--n-loading-color);\n "), Ru("base-clear", "\n font-size: var(--n-icon-size);\n ", [Eu("placeholder", [Ru("base-icon", "\n transition: color .3s var(--n-bezier);\n color: var(--n-icon-color);\n font-size: var(--n-icon-size);\n ")])]), Fu(">", [Ru("icon", "\n transition: color .3s var(--n-bezier);\n color: var(--n-icon-color);\n font-size: var(--n-icon-size);\n ")]), Ru("base-icon", "\n font-size: var(--n-icon-size);\n ")]), Ru("input-word-count", "\n pointer-events: none;\n line-height: 1.5;\n font-size: .85em;\n color: var(--n-count-text-color);\n transition: color .3s var(--n-bezier);\n margin-left: 4px;\n font-variant: tabular-nums;\n "), ["warning", "error"].map((e => Ou(`${e}-status`, [Bu("disabled", [Ru("base-loading", `\n color: var(--n-loading-color-${e})\n `), Eu("input-el, textarea-el", `\n caret-color: var(--n-caret-color-${e});\n `), Eu("state-border", `\n border: var(--n-border-${e});\n `), Fu("&:hover", [Eu("state-border", `\n border: var(--n-border-hover-${e});\n `)]), Fu("&:focus", `\n background-color: var(--n-color-focus-${e});\n `, [Eu("state-border", `\n box-shadow: var(--n-box-shadow-focus-${e});\n border: var(--n-border-focus-${e});\n `)]), Ou("focus", `\n background-color: var(--n-color-focus-${e});\n `, [Eu("state-border", `\n box-shadow: var(--n-box-shadow-focus-${e});\n border: var(--n-border-focus-${e});\n `)])])])))]);
        const _h = Ru("input", [Ou("disabled", [Eu("input-el, textarea-el", "\n -webkit-text-fill-color: var(--n-text-color-disabled);\n ")])]);
        var zh = Tn({
            name: "Input",
            props: Object.assign(Object.assign({}, Vu.props), {
                bordered: {
                    type: Boolean,
                    default: void 0
                },
                type: {
                    type: String,
                    default: "text"
                },
                placeholder: [Array, String],
                defaultValue: {
                    type: [String, Array],
                    default: null
                },
                value: [String, Array],
                disabled: {
                    type: Boolean,
                    default: void 0
                },
                size: String,
                rows: {
                    type: [Number, String],
                    default: 3
                },
                round: Boolean,
                minlength: [String, Number],
                maxlength: [String, Number],
                clearable: Boolean,
                autosize: {
                    type: [Boolean, Object],
                    default: !1
                },
                pair: Boolean,
                separator: String,
                readonly: {
                    type: [String, Boolean],
                    default: !1
                },
                passivelyActivated: Boolean,
                showPasswordOn: String,
                stateful: {
                    type: Boolean,
                    default: !0
                },
                autofocus: Boolean,
                inputProps: Object,
                resizable: {
                    type: Boolean,
                    default: !0
                },
                showCount: Boolean,
                loading: {
                    type: Boolean,
                    default: void 0
                },
                allowInput: Function,
                renderCount: Function,
                onMousedown: Function,
                onKeydown: Function,
                onKeyup: [Function, Array],
                onInput: [Function, Array],
                onFocus: [Function, Array],
                onBlur: [Function, Array],
                onClick: [Function, Array],
                onChange: [Function, Array],
                onClear: [Function, Array],
                countGraphemes: Function,
                status: String,
                "onUpdate:value": [Function, Array],
                onUpdateValue: [Function, Array],
                textDecoration: [String, Array],
                attrSize: {
                    type: Number,
                    default: 20
                },
                onInputBlur: [Function, Array],
                onInputFocus: [Function, Array],
                onDeactivate: [Function, Array],
                onActivate: [Function, Array],
                onWrapperFocus: [Function, Array],
                onWrapperBlur: [Function, Array],
                internalDeactivateOnEnter: Boolean,
                internalForceFocus: Boolean,
                internalLoadingBeforeSuffix: {
                    type: Boolean,
                    default: !0
                },
                showPasswordToggle: Boolean
            }),
            setup(e) {
                const {
                    mergedClsPrefixRef: t,
                    mergedBorderedRef: n,
                    inlineThemeDisabled: o,
                    mergedRtlRef: r
                } = zc(e), i = Vu("Input", "-input", $h, xh, e, t);
                cu && Zu("-input-safari", _h, t);
                const l = Ft(null),
                    a = Ft(null),
                    s = Ft(null),
                    c = Ft(null),
                    u = Ft(null),
                    d = Ft(null),
                    f = Ft(null),
                    p = function(e) {
                        const t = Ft(null);

                        function n() {
                            t.value = null
                        }
                        return vr(e, n), {
                            recordCursor: function() {
                                const {
                                    value: o
                                } = e;
                                if (!(null == o ? void 0 : o.focus)) return void n();
                                const {
                                    selectionStart: r,
                                    selectionEnd: i,
                                    value: l
                                } = o;
                                null != r && null != i ? t.value = {
                                    start: r,
                                    end: i,
                                    beforeText: l.slice(0, r),
                                    afterText: l.slice(i)
                                } : n()
                            },
                            restoreCursor: function() {
                                var n;
                                const {
                                    value: o
                                } = t, {
                                    value: r
                                } = e;
                                if (!o || !r) return;
                                const {
                                    value: i
                                } = r, {
                                    start: l,
                                    beforeText: a,
                                    afterText: s
                                } = o;
                                let c = i.length;
                                if (i.endsWith(s)) c = i.length - s.length;
                                else if (i.startsWith(a)) c = a.length;
                                else {
                                    const e = a[l - 1],
                                        t = i.indexOf(e, l - 1); - 1 !== t && (c = t + 1)
                                }
                                null === (n = r.setSelectionRange) || void 0 === n || n.call(r, c, c)
                            }
                        }
                    }(f),
                    h = Ft(null),
                    {
                        localeRef: v
                    } = bh("Input"),
                    g = Ft(e.defaultValue),
                    b = df(Dt(e, "value"), g),
                    m = Uu(e),
                    {
                        mergedSizeRef: y,
                        mergedDisabledRef: x,
                        mergedStatusRef: w
                    } = m,
                    C = Ft(!1),
                    S = Ft(!1),
                    k = Ft(!1),
                    $ = Ft(!1);
                let _ = null;
                const z = zi((() => {
                        const {
                            placeholder: t,
                            pair: n
                        } = e;
                        return n ? Array.isArray(t) ? t : void 0 === t ? ["", ""] : [t, t] : void 0 === t ? [v.value.placeholder] : [t]
                    })),
                    T = zi((() => {
                        const {
                            value: e
                        } = k, {
                            value: t
                        } = b, {
                            value: n
                        } = z;
                        return !e && (Sh(t) || Array.isArray(t) && Sh(t[0])) && n[0]
                    })),
                    P = zi((() => {
                        const {
                            value: e
                        } = k, {
                            value: t
                        } = b, {
                            value: n
                        } = z;
                        return !e && n[1] && (Sh(t) || Array.isArray(t) && Sh(t[1]))
                    })),
                    F = Il((() => e.internalForceFocus || C.value)),
                    M = Il((() => {
                        if (x.value || e.readonly || !e.clearable || !F.value && !S.value) return !1;
                        const {
                            value: t
                        } = b, {
                            value: n
                        } = F;
                        return e.pair ? !(!Array.isArray(t) || !t[0] && !t[1]) && (S.value || n) : !!t && (S.value || n)
                    })),
                    R = zi((() => {
                        const {
                            showPasswordOn: t
                        } = e;
                        return t || (e.showPasswordToggle ? "click" : void 0)
                    })),
                    E = Ft(!1),
                    O = zi((() => {
                        const {
                            textDecoration: t
                        } = e;
                        return t ? Array.isArray(t) ? t.map((e => ({
                            textDecoration: e
                        }))) : [{
                            textDecoration: t
                        }] : ["", ""]
                    })),
                    B = Ft(void 0),
                    A = zi((() => {
                        const {
                            maxlength: t
                        } = e;
                        return void 0 === t ? void 0 : Number(t)
                    }));
                Nn((() => {
                    const {
                        value: e
                    } = b;
                    Array.isArray(e) || q(e)
                }));
                const I = ui().proxy;

                function D(t, n) {
                    const {
                        onUpdateValue: o,
                        "onUpdate:value": r,
                        onInput: i
                    } = e, {
                        nTriggerFormInput: l
                    } = m;
                    o && ld(o, t, n), r && ld(r, t, n), i && ld(i, t, n), g.value = t, l()
                }

                function L(t, n) {
                    const {
                        onChange: o
                    } = e, {
                        nTriggerFormChange: r
                    } = m;
                    o && ld(o, t, n), g.value = t, r()
                }

                function j(t, n = 0, o = "input") {
                    const r = t.target.value;
                    if (q(r), t instanceof InputEvent && !t.isComposing && (k.value = !1), "textarea" === e.type) {
                        const {
                            value: e
                        } = h;
                        e && e.syncUnifiedContainer()
                    }
                    if (_ = r, k.value) return;
                    p.recordCursor();
                    const i = function(t) {
                        const {
                            countGraphemes: n,
                            maxlength: o,
                            minlength: r
                        } = e;
                        if (n) {
                            let e;
                            if (void 0 !== o && (void 0 === e && (e = n(t)), e > Number(o))) return !1;
                            if (void 0 !== r && (void 0 === e && (e = n(t)), e < Number(o))) return !1
                        }
                        const {
                            allowInput: i
                        } = e;
                        if ("function" == typeof i) return i(t);
                        return !0
                    }(r);
                    if (i)
                        if (e.pair) {
                            let {
                                value: e
                            } = b;
                            e = Array.isArray(e) ? [e[0], e[1]] : ["", ""], e[n] = r, "input" === o ? D(e, {
                                source: n
                            }) : L(e, {
                                source: n
                            })
                        } else "input" === o ? D(r, {
                            source: n
                        }) : L(r, {
                            source: n
                        });
                    I.$forceUpdate(), i || Jt(p.restoreCursor)
                }

                function N(t, n) {
                    (null === t.relatedTarget || t.relatedTarget !== u.value && t.relatedTarget !== d.value && t.relatedTarget !== a.value && t.relatedTarget !== l.value) && ("focus" === n ? (! function(t) {
                        const {
                            onFocus: n
                        } = e, {
                            nTriggerFormFocus: o
                        } = m;
                        n && ld(n, t), o()
                    }(t), C.value = !0) : "blur" === n && (! function(t) {
                        const {
                            onBlur: n
                        } = e, {
                            nTriggerFormBlur: o
                        } = m;
                        n && ld(n, t), o()
                    }(t), C.value = !1))
                }

                function H() {
                    e.pair ? (D(["", ""], {
                        source: "clear"
                    }), L(["", ""], {
                        source: "clear"
                    })) : (D("", {
                        source: "clear"
                    }), L("", {
                        source: "clear"
                    }))
                }

                function W() {
                    e.passivelyActivated && ($.value = !1, Jt((() => {
                        var e;
                        null === (e = l.value) || void 0 === e || e.focus()
                    })))
                }

                function V() {
                    var t, n, o;
                    x.value || (e.passivelyActivated ? null === (t = l.value) || void 0 === t || t.focus() : (null === (n = a.value) || void 0 === n || n.focus(), null === (o = u.value) || void 0 === o || o.focus()))
                }

                function q(t) {
                    const {
                        type: n,
                        pair: o,
                        autosize: r
                    } = e;
                    if (!o && r)
                        if ("textarea" === n) {
                            const {
                                value: e
                            } = s;
                            e && (e.textContent = `${null!=t?t:""}\r\n`)
                        } else {
                            const {
                                value: e
                            } = c;
                            e && (t ? e.textContent = t : e.innerHTML = "&nbsp;")
                        }
                }
                const U = Ft({
                    top: "0"
                });
                let K = null;
                pr((() => {
                    const {
                        autosize: t,
                        type: n
                    } = e;
                    t && "textarea" === n ? K = vr(b, (e => {
                        Array.isArray(e) || e === _ || q(e)
                    })) : null == K || K()
                }));
                let G = null;
                pr((() => {
                    "textarea" === e.type ? G = vr(b, (e => {
                        var t;
                        Array.isArray(e) || e === _ || null === (t = h.value) || void 0 === t || t.syncUnifiedContainer()
                    })) : null == G || G()
                })), $o(wh, {
                    mergedValueRef: b,
                    maxlengthRef: A,
                    mergedClsPrefixRef: t,
                    countGraphemesRef: Dt(e, "countGraphemes")
                });
                const X = {
                        wrapperElRef: l,
                        inputElRef: u,
                        textareaElRef: a,
                        isCompositing: k,
                        clear: H,
                        focus: V,
                        blur: function() {
                            var e;
                            (null === (e = l.value) || void 0 === e ? void 0 : e.contains(document.activeElement)) && document.activeElement.blur()
                        },
                        select: function() {
                            var e, t;
                            null === (e = a.value) || void 0 === e || e.select(), null === (t = u.value) || void 0 === t || t.select()
                        },
                        deactivate: function() {
                            const {
                                value: e
                            } = l;
                            (null == e ? void 0 : e.contains(document.activeElement)) && e !== document.activeElement && W()
                        },
                        activate: function() {
                            x.value || (a.value ? a.value.focus() : u.value && u.value.focus())
                        },
                        scrollTo: function(t) {
                            if ("textarea" === e.type) {
                                const {
                                    value: e
                                } = a;
                                null == e || e.scrollTo(t)
                            } else {
                                const {
                                    value: e
                                } = u;
                                null == e || e.scrollTo(t)
                            }
                        }
                    },
                    Y = lu("Input", r, t),
                    Z = zi((() => {
                        const {
                            value: e
                        } = y, {
                            common: {
                                cubicBezierEaseInOut: t
                            },
                            self: {
                                color: n,
                                borderRadius: o,
                                textColor: r,
                                caretColor: l,
                                caretColorError: a,
                                caretColorWarning: s,
                                textDecorationColor: c,
                                border: u,
                                borderDisabled: d,
                                borderHover: f,
                                borderFocus: p,
                                placeholderColor: h,
                                placeholderColorDisabled: v,
                                lineHeightTextarea: g,
                                colorDisabled: b,
                                colorFocus: m,
                                textColorDisabled: x,
                                boxShadowFocus: w,
                                iconSize: C,
                                colorFocusWarning: S,
                                boxShadowFocusWarning: k,
                                borderWarning: $,
                                borderFocusWarning: _,
                                borderHoverWarning: z,
                                colorFocusError: T,
                                boxShadowFocusError: P,
                                borderError: F,
                                borderFocusError: M,
                                borderHoverError: R,
                                clearSize: E,
                                clearColor: O,
                                clearColorHover: B,
                                clearColorPressed: A,
                                iconColor: I,
                                iconColorDisabled: D,
                                suffixTextColor: L,
                                countTextColor: j,
                                countTextColorDisabled: N,
                                iconColorHover: H,
                                iconColorPressed: W,
                                loadingColor: V,
                                loadingColorError: q,
                                loadingColorWarning: U,
                                [Iu("padding", e)]: K,
                                [Iu("fontSize", e)]: G,
                                [Iu("height", e)]: X
                            }
                        } = i.value, {
                            left: Y,
                            right: Z
                        } = hf(K);
                        return {
                            "--n-bezier": t,
                            "--n-count-text-color": j,
                            "--n-count-text-color-disabled": N,
                            "--n-color": n,
                            "--n-font-size": G,
                            "--n-border-radius": o,
                            "--n-height": X,
                            "--n-padding-left": Y,
                            "--n-padding-right": Z,
                            "--n-text-color": r,
                            "--n-caret-color": l,
                            "--n-text-decoration-color": c,
                            "--n-border": u,
                            "--n-border-disabled": d,
                            "--n-border-hover": f,
                            "--n-border-focus": p,
                            "--n-placeholder-color": h,
                            "--n-placeholder-color-disabled": v,
                            "--n-icon-size": C,
                            "--n-line-height-textarea": g,
                            "--n-color-disabled": b,
                            "--n-color-focus": m,
                            "--n-text-color-disabled": x,
                            "--n-box-shadow-focus": w,
                            "--n-loading-color": V,
                            "--n-caret-color-warning": s,
                            "--n-color-focus-warning": S,
                            "--n-box-shadow-focus-warning": k,
                            "--n-border-warning": $,
                            "--n-border-focus-warning": _,
                            "--n-border-hover-warning": z,
                            "--n-loading-color-warning": U,
                            "--n-caret-color-error": a,
                            "--n-color-focus-error": T,
                            "--n-box-shadow-focus-error": P,
                            "--n-border-error": F,
                            "--n-border-focus-error": M,
                            "--n-border-hover-error": R,
                            "--n-loading-color-error": q,
                            "--n-clear-color": O,
                            "--n-clear-size": E,
                            "--n-clear-color-hover": B,
                            "--n-clear-color-pressed": A,
                            "--n-icon-color": I,
                            "--n-icon-color-hover": H,
                            "--n-icon-color-pressed": W,
                            "--n-icon-color-disabled": D,
                            "--n-suffix-text-color": L
                        }
                    })),
                    J = o ? Ku("input", zi((() => {
                        const {
                            value: e
                        } = y;
                        return e[0]
                    })), Z, e) : void 0;
                return Object.assign(Object.assign({}, X), {
                    wrapperElRef: l,
                    inputElRef: u,
                    inputMirrorElRef: c,
                    inputEl2Ref: d,
                    textareaElRef: a,
                    textareaMirrorElRef: s,
                    textareaScrollbarInstRef: h,
                    rtlEnabled: Y,
                    uncontrolledValue: g,
                    mergedValue: b,
                    passwordVisible: E,
                    mergedPlaceholder: z,
                    showPlaceholder1: T,
                    showPlaceholder2: P,
                    mergedFocus: F,
                    isComposing: k,
                    activated: $,
                    showClearButton: M,
                    mergedSize: y,
                    mergedDisabled: x,
                    textDecorationStyle: O,
                    mergedClsPrefix: t,
                    mergedBordered: n,
                    mergedShowPasswordOn: R,
                    placeholderStyle: U,
                    mergedStatus: w,
                    textAreaScrollContainerWidth: B,
                    handleTextAreaScroll: function(e) {
                        var t;
                        const {
                            scrollTop: n
                        } = e.target;
                        U.value.top = -n + "px", null === (t = h.value) || void 0 === t || t.syncUnifiedContainer()
                    },
                    handleCompositionStart: function() {
                        k.value = !0
                    },
                    handleCompositionEnd: function(e) {
                        k.value = !1, e.target === d.value ? j(e, 1) : j(e, 0)
                    },
                    handleInput: j,
                    handleInputBlur: function(t) {
                        ! function(t) {
                            const {
                                onInputBlur: n
                            } = e;
                            n && ld(n, t)
                        }(t), t.relatedTarget === l.value && function() {
                            const {
                                onDeactivate: t
                            } = e;
                            t && ld(t)
                        }(), (null === t.relatedTarget || t.relatedTarget !== u.value && t.relatedTarget !== d.value && t.relatedTarget !== a.value) && ($.value = !1), N(t, "blur"), f.value = null
                    },
                    handleInputFocus: function(t, n) {
                        ! function(t) {
                            const {
                                onInputFocus: n
                            } = e;
                            n && ld(n, t)
                        }(t), C.value = !0, $.value = !0,
                            function() {
                                const {
                                    onActivate: t
                                } = e;
                                t && ld(t)
                            }(), N(t, "focus"), 0 === n ? f.value = u.value : 1 === n ? f.value = d.value : 2 === n && (f.value = a.value)
                    },
                    handleWrapperBlur: function(t) {
                        e.passivelyActivated && (! function(t) {
                            const {
                                onWrapperBlur: n
                            } = e;
                            n && ld(n, t)
                        }(t), N(t, "blur"))
                    },
                    handleWrapperFocus: function(t) {
                        e.passivelyActivated && (C.value = !0, function(t) {
                            const {
                                onWrapperFocus: n
                            } = e;
                            n && ld(n, t)
                        }(t), N(t, "focus"))
                    },
                    handleMouseEnter: function() {
                        var t;
                        S.value = !0, "textarea" === e.type && (null === (t = h.value) || void 0 === t || t.handleMouseEnterWrapper())
                    },
                    handleMouseLeave: function() {
                        var t;
                        S.value = !1, "textarea" === e.type && (null === (t = h.value) || void 0 === t || t.handleMouseLeaveWrapper())
                    },
                    handleMouseDown: function(t) {
                        const {
                            onMousedown: n
                        } = e;
                        n && n(t);
                        const {
                            tagName: o
                        } = t.target;
                        if ("INPUT" !== o && "TEXTAREA" !== o) {
                            if (e.resizable) {
                                const {
                                    value: e
                                } = l;
                                if (e) {
                                    const {
                                        left: n,
                                        top: o,
                                        width: r,
                                        height: i
                                    } = e.getBoundingClientRect(), l = 14;
                                    if (n + r - l < t.clientX && t.clientX < n + r && o + i - l < t.clientY && t.clientY < o + i) return
                                }
                            }
                            t.preventDefault(), C.value || V()
                        }
                    },
                    handleChange: function(e, t) {
                        j(e, t, "change")
                    },
                    handleClick: function(t) {
                        ! function(t) {
                            const {
                                onClick: n
                            } = e;
                            n && ld(n, t)
                        }(t)
                    },
                    handleClear: function(t) {
                        ! function(t) {
                            const {
                                onClear: n
                            } = e;
                            n && ld(n, t)
                        }(t), H()
                    },
                    handlePasswordToggleClick: function() {
                        x.value || "click" === R.value && (E.value = !E.value)
                    },
                    handlePasswordToggleMousedown: function(e) {
                        if (x.value) return;
                        e.preventDefault();
                        const t = e => {
                            e.preventDefault(), cp("mouseup", document, t)
                        };
                        if (sp("mouseup", document, t), "mousedown" !== R.value) return;
                        E.value = !0;
                        const n = () => {
                            E.value = !1, cp("mouseup", document, n)
                        };
                        sp("mouseup", document, n)
                    },
                    handleWrapperKeydown: function(t) {
                        switch (e.onKeydown && ld(e.onKeydown, t), t.key) {
                            case "Escape":
                                W();
                                break;
                            case "Enter":
                                ! function(t) {
                                    var n, o;
                                    if (e.passivelyActivated) {
                                        const {
                                            value: r
                                        } = $;
                                        if (r) return void(e.internalDeactivateOnEnter && W());
                                        t.preventDefault(), "textarea" === e.type ? null === (n = a.value) || void 0 === n || n.focus() : null === (o = u.value) || void 0 === o || o.focus()
                                    }
                                }(t)
                        }
                    },
                    handleWrapperKeyup: function(t) {
                        e.onKeyup && ld(e.onKeyup, t)
                    },
                    handleTextAreaMirrorResize: function() {
                        (() => {
                            var t, n;
                            if ("textarea" === e.type) {
                                const {
                                    autosize: o
                                } = e;
                                if (o && (B.value = null === (n = null === (t = h.value) || void 0 === t ? void 0 : t.$el) || void 0 === n ? void 0 : n.offsetWidth), !a.value) return;
                                if ("boolean" == typeof o) return;
                                const {
                                    paddingTop: r,
                                    paddingBottom: i,
                                    lineHeight: l
                                } = window.getComputedStyle(a.value), c = Number(r.slice(0, -2)), u = Number(i.slice(0, -2)), d = Number(l.slice(0, -2)), {
                                    value: f
                                } = s;
                                if (!f) return;
                                if (o.minRows) {
                                    const e = `${c+u+d*Math.max(o.minRows,1)}px`;
                                    f.style.minHeight = e
                                }
                                if (o.maxRows) {
                                    const e = `${c+u+d*o.maxRows}px`;
                                    f.style.maxHeight = e
                                }
                            }
                        })()
                    },
                    getTextareaScrollContainer: () => a.value,
                    mergedTheme: i,
                    cssVars: o ? void 0 : Z,
                    themeClass: null == J ? void 0 : J.themeClass,
                    onRender: null == J ? void 0 : J.onRender
                })
            },
            render() {
                var e, t;
                const {
                    mergedClsPrefix: n,
                    mergedStatus: o,
                    themeClass: r,
                    type: i,
                    countGraphemes: l,
                    onRender: a
                } = this, s = this.$slots;
                return null == a || a(), Ti("div", {
                    ref: "wrapperElRef",
                    class: [`${n}-input`, r, o && `${n}-input--${o}-status`, {
                        [`${n}-input--rtl`]: this.rtlEnabled,
                        [`${n}-input--disabled`]: this.mergedDisabled,
                        [`${n}-input--textarea`]: "textarea" === i,
                        [`${n}-input--resizable`]: this.resizable && !this.autosize,
                        [`${n}-input--autosize`]: this.autosize,
                        [`${n}-input--round`]: this.round && !("textarea" === i),
                        [`${n}-input--pair`]: this.pair,
                        [`${n}-input--focus`]: this.mergedFocus,
                        [`${n}-input--stateful`]: this.stateful
                    }],
                    style: this.cssVars,
                    tabindex: this.mergedDisabled || !this.passivelyActivated || this.activated ? void 0 : 0,
                    onFocus: this.handleWrapperFocus,
                    onBlur: this.handleWrapperBlur,
                    onClick: this.handleClick,
                    onMousedown: this.handleMouseDown,
                    onMouseenter: this.handleMouseEnter,
                    onMouseleave: this.handleMouseLeave,
                    onCompositionstart: this.handleCompositionStart,
                    onCompositionend: this.handleCompositionEnd,
                    onKeyup: this.handleWrapperKeyup,
                    onKeydown: this.handleWrapperKeydown
                }, Ti("div", {
                    class: `${n}-input-wrapper`
                }, dd(s.prefix, (e => e && Ti("div", {
                    class: `${n}-input__prefix`
                }, e))), "textarea" === i ? Ti(Cp, {
                    ref: "textareaScrollbarInstRef",
                    class: `${n}-input__textarea`,
                    container: this.getTextareaScrollContainer,
                    triggerDisplayManually: !0,
                    useUnifiedContainer: !0,
                    internalHoistYRail: !0
                }, {
                    default: () => {
                        var e, t;
                        const {
                            textAreaScrollContainerWidth: o
                        } = this, r = {
                            width: this.autosize && o && `${o}px`
                        };
                        return Ti(Mr, null, Ti("textarea", Object.assign({}, this.inputProps, {
                            ref: "textareaElRef",
                            class: [`${n}-input__textarea-el`, null === (e = this.inputProps) || void 0 === e ? void 0 : e.class],
                            autofocus: this.autofocus,
                            rows: Number(this.rows),
                            placeholder: this.placeholder,
                            value: this.mergedValue,
                            disabled: this.mergedDisabled,
                            maxlength: l ? void 0 : this.maxlength,
                            minlength: l ? void 0 : this.minlength,
                            readonly: this.readonly,
                            tabindex: this.passivelyActivated && !this.activated ? -1 : void 0,
                            style: [this.textDecorationStyle[0], null === (t = this.inputProps) || void 0 === t ? void 0 : t.style, r],
                            onBlur: this.handleInputBlur,
                            onFocus: e => {
                                this.handleInputFocus(e, 2)
                            },
                            onInput: this.handleInput,
                            onChange: this.handleChange,
                            onScroll: this.handleTextAreaScroll
                        })), this.showPlaceholder1 ? Ti("div", {
                            class: `${n}-input__placeholder`,
                            style: [this.placeholderStyle, r],
                            key: "placeholder"
                        }, this.mergedPlaceholder[0]) : null, this.autosize ? Ti(np, {
                            onResize: this.handleTextAreaMirrorResize
                        }, {
                            default: () => Ti("div", {
                                ref: "textareaMirrorElRef",
                                class: `${n}-input__textarea-mirror`,
                                key: "mirror"
                            })
                        }) : null)
                    }
                }) : Ti("div", {
                    class: `${n}-input__input`
                }, Ti("input", Object.assign({
                    type: "password" === i && this.mergedShowPasswordOn && this.passwordVisible ? "text" : i
                }, this.inputProps, {
                    ref: "inputElRef",
                    class: [`${n}-input__input-el`, null === (e = this.inputProps) || void 0 === e ? void 0 : e.class],
                    style: [this.textDecorationStyle[0], null === (t = this.inputProps) || void 0 === t ? void 0 : t.style],
                    tabindex: this.passivelyActivated && !this.activated ? -1 : void 0,
                    placeholder: this.mergedPlaceholder[0],
                    disabled: this.mergedDisabled,
                    maxlength: l ? void 0 : this.maxlength,
                    minlength: l ? void 0 : this.minlength,
                    value: Array.isArray(this.mergedValue) ? this.mergedValue[0] : this.mergedValue,
                    readonly: this.readonly,
                    autofocus: this.autofocus,
                    size: this.attrSize,
                    onBlur: this.handleInputBlur,
                    onFocus: e => {
                        this.handleInputFocus(e, 0)
                    },
                    onInput: e => {
                        this.handleInput(e, 0)
                    },
                    onChange: e => {
                        this.handleChange(e, 0)
                    }
                })), this.showPlaceholder1 ? Ti("div", {
                    class: `${n}-input__placeholder`
                }, Ti("span", null, this.mergedPlaceholder[0])) : null, this.autosize ? Ti("div", {
                    class: `${n}-input__input-mirror`,
                    key: "mirror",
                    ref: "inputMirrorElRef"
                }, " ") : null), !this.pair && dd(s.suffix, (e => e || this.clearable || this.showCount || this.mergedShowPasswordOn || void 0 !== this.loading ? Ti("div", {
                    class: `${n}-input__suffix`
                }, [dd(s["clear-icon-placeholder"], (e => (this.clearable || e) && Ti(th, {
                    clsPrefix: n,
                    show: this.showClearButton,
                    onClear: this.handleClear
                }, {
                    placeholder: () => e,
                    icon: () => {
                        var e, t;
                        return null === (t = (e = this.$slots)["clear-icon"]) || void 0 === t ? void 0 : t.call(e)
                    }
                }))), this.internalLoadingBeforeSuffix ? null : e, void 0 !== this.loading ? Ti(oh, {
                    clsPrefix: n,
                    loading: this.loading,
                    showArrow: !1,
                    showClear: !1,
                    style: this.cssVars
                }) : null, this.internalLoadingBeforeSuffix ? e : null, this.showCount && "textarea" !== this.type ? Ti(kh, null, {
                    default: e => {
                        var t;
                        return null === (t = s.count) || void 0 === t ? void 0 : t.call(s, e)
                    }
                }) : null, this.mergedShowPasswordOn && "password" === this.type ? Ti("div", {
                    class: `${n}-input__eye`,
                    onMousedown: this.handlePasswordToggleMousedown,
                    onClick: this.handlePasswordToggleClick
                }, this.passwordVisible ? cd(s["password-visible-icon"], (() => [Ti(Qp, {
                    clsPrefix: n
                }, {
                    default: () => Ti(up, null)
                })])) : cd(s["password-invisible-icon"], (() => [Ti(Qp, {
                    clsPrefix: n
                }, {
                    default: () => Ti(dp, null)
                })]))) : null]) : null))), this.pair ? Ti("span", {
                    class: `${n}-input__separator`
                }, cd(s.separator, (() => [this.separator]))) : null, this.pair ? Ti("div", {
                    class: `${n}-input-wrapper`
                }, Ti("div", {
                    class: `${n}-input__input`
                }, Ti("input", {
                    ref: "inputEl2Ref",
                    type: this.type,
                    class: `${n}-input__input-el`,
                    tabindex: this.passivelyActivated && !this.activated ? -1 : void 0,
                    placeholder: this.mergedPlaceholder[1],
                    disabled: this.mergedDisabled,
                    maxlength: l ? void 0 : this.maxlength,
                    minlength: l ? void 0 : this.minlength,
                    value: Array.isArray(this.mergedValue) ? this.mergedValue[1] : void 0,
                    readonly: this.readonly,
                    style: this.textDecorationStyle[1],
                    onBlur: this.handleInputBlur,
                    onFocus: e => {
                        this.handleInputFocus(e, 1)
                    },
                    onInput: e => {
                        this.handleInput(e, 1)
                    },
                    onChange: e => {
                        this.handleChange(e, 1)
                    }
                }), this.showPlaceholder2 ? Ti("div", {
                    class: `${n}-input__placeholder`
                }, Ti("span", null, this.mergedPlaceholder[1])) : null), dd(s.suffix, (e => (this.clearable || e) && Ti("div", {
                    class: `${n}-input__suffix`
                }, [this.clearable && Ti(th, {
                    clsPrefix: n,
                    show: this.showClearButton,
                    onClear: this.handleClear
                }, {
                    icon: () => {
                        var e;
                        return null === (e = s["clear-icon"]) || void 0 === e ? void 0 : e.call(s)
                    },
                    placeholder: () => {
                        var e;
                        return null === (e = s["clear-icon-placeholder"]) || void 0 === e ? void 0 : e.call(s)
                    }
                }), e])))) : null, this.mergedBordered ? Ti("div", {
                    class: `${n}-input__border`
                }) : null, this.mergedBordered ? Ti("div", {
                    class: `${n}-input__state-border`
                }) : null, this.showCount && "textarea" === i ? Ti(kh, null, {
                    default: e => {
                        var t;
                        const {
                            renderCount: n
                        } = this;
                        return n ? n(e) : null === (t = s.count) || void 0 === t ? void 0 : t.call(s, e)
                    }
                }) : null)
            }
        });
        const Th = {
            name: "Collapse",
            common: of,
            self: function(e) {
                const {
                    fontWeight: t,
                    textColor1: n,
                    textColor2: o,
                    textColorDisabled: r,
                    dividerColor: i,
                    fontSize: l
                } = e;
                return {
                    titleFontSize: l,
                    titleFontWeight: t,
                    dividerColor: i,
                    titleTextColor: n,
                    titleTextColorDisabled: r,
                    fontSize: l,
                    textColor: o,
                    arrowColor: o,
                    arrowColorDisabled: r,
                    itemMargin: "16px 0 0 0",
                    titlePadding: "16px 0 0 0"
                }
            }
        };
        var Ph = Th;
        const {
            cubicBezierEaseInOut: Fh,
            cubicBezierEaseOut: Mh,
            cubicBezierEaseIn: Rh
        } = Du;
        var Eh = Ru("collapse", "width: 100%;", [Ru("collapse-item", "\n font-size: var(--n-font-size);\n color: var(--n-text-color);\n transition:\n color .3s var(--n-bezier),\n border-color .3s var(--n-bezier);\n margin: var(--n-item-margin);\n ", [Ou("disabled", [Eu("header", "cursor: not-allowed;", [Eu("header-main", "\n color: var(--n-title-text-color-disabled);\n "), Ru("collapse-item-arrow", "\n color: var(--n-arrow-color-disabled);\n ")])]), Ru("collapse-item", "margin-left: 32px;"), Fu("&:first-child", "margin-top: 0;"), Fu("&:first-child >", [Eu("header", "padding-top: 0;")]), Ou("left-arrow-placement", [Eu("header", [Ru("collapse-item-arrow", "margin-right: 4px;")])]), Ou("right-arrow-placement", [Eu("header", [Ru("collapse-item-arrow", "margin-left: 4px;")])]), Eu("content-wrapper", [Eu("content-inner", "padding-top: 16px;"), function({
            overflow: e = "hidden",
            duration: t = ".3s",
            originalTransition: n = "",
            leavingDelay: o = "0s",
            foldPadding: r = !1,
            enterToProps: i,
            leaveToProps: l,
            reverse: a = !1
        } = {}) {
            const s = a ? "leave" : "enter",
                c = a ? "enter" : "leave";
            return [Fu(`&.fade-in-height-expand-transition-${c}-from,\n &.fade-in-height-expand-transition-${s}-to`, Object.assign(Object.assign({}, i), {
                opacity: 1
            })), Fu(`&.fade-in-height-expand-transition-${c}-to,\n &.fade-in-height-expand-transition-${s}-from`, Object.assign(Object.assign({}, l), {
                opacity: 0,
                marginTop: "0 !important",
                marginBottom: "0 !important",
                paddingTop: r ? "0 !important" : void 0,
                paddingBottom: r ? "0 !important" : void 0
            })), Fu(`&.fade-in-height-expand-transition-${c}-active`, `\n overflow: ${e};\n transition:\n max-height ${t} ${Fh} ${o},\n opacity ${t} ${Mh} ${o},\n margin-top ${t} ${Fh} ${o},\n margin-bottom ${t} ${Fh} ${o},\n padding-top ${t} ${Fh} ${o},\n padding-bottom ${t} ${Fh} ${o}\n ${n?`,${n}`:""}\n `), Fu(`&.fade-in-height-expand-transition-${s}-active`, `\n overflow: ${e};\n transition:\n max-height ${t} ${Fh},\n opacity ${t} ${Rh},\n margin-top ${t} ${Fh},\n margin-bottom ${t} ${Fh},\n padding-top ${t} ${Fh},\n padding-bottom ${t} ${Fh}\n ${n?`,${n}`:""}\n `)]
        }({
            duration: "0.15s"
        })]), Ou("active", [Eu("header", [Ou("active", [Ru("collapse-item-arrow", "transform: rotate(90deg);")])])]), Fu("&:not(:first-child)", "border-top: 1px solid var(--n-divider-color);"), Bu("disabled", [Ou("trigger-area-main", [Eu("header", [Eu("header-main", "cursor: pointer;"), Ru("collapse-item-arrow", "cursor: default;")])]), Ou("trigger-area-arrow", [Eu("header", [Ru("collapse-item-arrow", "cursor: pointer;")])]), Ou("trigger-area-extra", [Eu("header", [Eu("header-extra", "cursor: pointer;")])])]), Eu("header", "\n font-size: var(--n-title-font-size);\n display: flex;\n flex-wrap: nowrap;\n align-items: center;\n transition: color .3s var(--n-bezier);\n position: relative;\n padding: var(--n-title-padding);\n color: var(--n-title-text-color);\n ", [Eu("header-main", "\n display: flex;\n flex-wrap: nowrap;\n align-items: center;\n font-weight: var(--n-title-font-weight);\n transition: color .3s var(--n-bezier);\n flex: 1;\n color: var(--n-title-text-color);\n "), Eu("header-extra", "\n display: flex;\n align-items: center;\n transition: color .3s var(--n-bezier);\n color: var(--n-text-color);\n "), Ru("collapse-item-arrow", "\n display: flex;\n transition:\n transform .15s var(--n-bezier),\n color .3s var(--n-bezier);\n font-size: 18px;\n color: var(--n-arrow-color);\n ")])])]);
        const Oh = Object.assign(Object.assign({}, Vu.props), {
                defaultExpandedNames: {
                    type: [Array, String],
                    default: null
                },
                expandedNames: [Array, String],
                arrowPlacement: {
                    type: String,
                    default: "left"
                },
                accordion: {
                    type: Boolean,
                    default: !1
                },
                displayDirective: {
                    type: String,
                    default: "if"
                },
                triggerAreas: {
                    type: Array,
                    default: () => ["main", "extra", "arrow"]
                },
                onItemHeaderClick: [Function, Array],
                "onUpdate:expandedNames": [Function, Array],
                onUpdateExpandedNames: [Function, Array],
                onExpandedNamesChange: {
                    type: [Function, Array],
                    validator: () => !0,
                    default: void 0
                }
            }),
            Bh = "n-collapse";
        var Ah = Tn({
            name: "Collapse",
            props: Oh,
            setup(e, {
                slots: t
            }) {
                const {
                    mergedClsPrefixRef: n,
                    inlineThemeDisabled: o,
                    mergedRtlRef: r
                } = zc(e), i = Ft(e.defaultExpandedNames), l = df(zi((() => e.expandedNames)), i), a = Vu("Collapse", "-collapse", Eh, Ph, e, n);

                function s(t) {
                    const {
                        "onUpdate:expandedNames": n,
                        onUpdateExpandedNames: o,
                        onExpandedNamesChange: r
                    } = e;
                    o && ld(o, t), n && ld(n, t), r && ld(r, t), i.value = t
                }

                function c(t) {
                    const {
                        onItemHeaderClick: n
                    } = e;
                    n && ld(n, t)
                }
                $o(Bh, {
                    props: e,
                    mergedClsPrefixRef: n,
                    expandedNamesRef: l,
                    slots: t,
                    toggleItem: function(t, n, o) {
                        const {
                            accordion: r
                        } = e, {
                            value: i
                        } = l;
                        if (r) t ? (s([n]), c({
                            name: n,
                            expanded: !0,
                            event: o
                        })) : (s([]), c({
                            name: n,
                            expanded: !1,
                            event: o
                        }));
                        else if (Array.isArray(i)) {
                            const e = i.slice(),
                                t = e.findIndex((e => n === e));
                            ~t ? (e.splice(t, 1), s(e), c({
                                name: n,
                                expanded: !1,
                                event: o
                            })) : (e.push(n), s(e), c({
                                name: n,
                                expanded: !0,
                                event: o
                            }))
                        } else s([n]), c({
                            name: n,
                            expanded: !0,
                            event: o
                        })
                    }
                });
                const u = lu("Collapse", r, n),
                    d = zi((() => {
                        const {
                            common: {
                                cubicBezierEaseInOut: e
                            },
                            self: {
                                titleFontWeight: t,
                                dividerColor: n,
                                titlePadding: o,
                                titleTextColor: r,
                                titleTextColorDisabled: i,
                                textColor: l,
                                arrowColor: s,
                                fontSize: c,
                                titleFontSize: u,
                                arrowColorDisabled: d,
                                itemMargin: f
                            }
                        } = a.value;
                        return {
                            "--n-font-size": c,
                            "--n-bezier": e,
                            "--n-text-color": l,
                            "--n-divider-color": n,
                            "--n-title-padding": o,
                            "--n-title-font-size": u,
                            "--n-title-text-color": r,
                            "--n-title-text-color-disabled": i,
                            "--n-title-font-weight": t,
                            "--n-arrow-color": s,
                            "--n-arrow-color-disabled": d,
                            "--n-item-margin": f
                        }
                    })),
                    f = o ? Ku("collapse", void 0, d, e) : void 0;
                return {
                    rtlEnabled: u,
                    mergedTheme: a,
                    mergedClsPrefix: n,
                    cssVars: o ? void 0 : d,
                    themeClass: null == f ? void 0 : f.themeClass,
                    onRender: null == f ? void 0 : f.onRender
                }
            },
            render() {
                var e;
                return null === (e = this.onRender) || void 0 === e || e.call(this), Ti("div", {
                    class: [`${this.mergedClsPrefix}-collapse`, this.rtlEnabled && `${this.mergedClsPrefix}-collapse--rtl`, this.themeClass],
                    style: this.cssVars
                }, this.$slots)
            }
        });

        function Ih(e = 8) {
            return Math.random().toString(16).slice(2, 2 + e)
        }

        function Dh(e, t) {
            let {
                target: n
            } = e;
            for (; n;) {
                if (n.dataset && void 0 !== n.dataset[t]) return !0;
                n = n.parentElement
            }
            return !1
        }
        var Lh = Tn({
                name: "ChevronLeft",
                render() {
                    return Ti("svg", {
                        viewBox: "0 0 16 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, Ti("path", {
                        d: "M10.3536 3.14645C10.5488 3.34171 10.5488 3.65829 10.3536 3.85355L6.20711 8L10.3536 12.1464C10.5488 12.3417 10.5488 12.6583 10.3536 12.8536C10.1583 13.0488 9.84171 13.0488 9.64645 12.8536L5.14645 8.35355C4.95118 8.15829 4.95118 7.84171 5.14645 7.64645L9.64645 3.14645C9.84171 2.95118 10.1583 2.95118 10.3536 3.14645Z",
                        fill: "currentColor"
                    }))
                }
            }),
            jh = Tn({
                name: "ChevronRight",
                render() {
                    return Ti("svg", {
                        viewBox: "0 0 16 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, Ti("path", {
                        d: "M5.64645 3.14645C5.45118 3.34171 5.45118 3.65829 5.64645 3.85355L9.79289 8L5.64645 12.1464C5.45118 12.3417 5.45118 12.6583 5.64645 12.8536C5.84171 13.0488 6.15829 13.0488 6.35355 12.8536L10.8536 8.35355C11.0488 8.15829 11.0488 7.84171 10.8536 7.64645L6.35355 3.14645C6.15829 2.95118 5.84171 2.95118 5.64645 3.14645Z",
                        fill: "currentColor"
                    }))
                }
            });

        function Nh(e) {
            const t = Ft(!!e.value);
            if (t.value) return vt(t);
            const n = vr(e, (e => {
                e && (t.value = !0, n())
            }));
            return vt(t)
        }
        var Hh = Tn({
            name: "CollapseItemContent",
            props: {
                displayDirective: {
                    type: String,
                    required: !0
                },
                show: Boolean,
                clsPrefix: {
                    type: String,
                    required: !0
                }
            },
            setup(e) {
                return {
                    onceTrue: Nh(Dt(e, "show"))
                }
            },
            render() {
                return Ti(Gu, null, {
                    default: () => {
                        const {
                            show: e,
                            displayDirective: t,
                            onceTrue: n,
                            clsPrefix: o
                        } = this, r = "show" === t && n, i = Ti("div", {
                            class: `${o}-collapse-item__content-wrapper`
                        }, Ti("div", {
                            class: `${o}-collapse-item__content-inner`
                        }, this.$slots));
                        return r ? fn(i, [
                            [el, e]
                        ]) : e ? i : null
                    }
                })
            }
        });
        var Wh = Tn({
                name: "CollapseItem",
                props: {
                    title: String,
                    name: [String, Number],
                    disabled: Boolean,
                    displayDirective: String
                },
                setup(e) {
                    const {
                        mergedRtlRef: t
                    } = zc(e), n = Ih(), o = Il((() => {
                        var t;
                        return null !== (t = e.name) && void 0 !== t ? t : n
                    })), r = _o(Bh);
                    r || kc("collapse-item", "`n-collapse-item` must be placed inside `n-collapse`.");
                    const {
                        expandedNamesRef: i,
                        props: l,
                        mergedClsPrefixRef: a,
                        slots: s
                    } = r, c = zi((() => {
                        const {
                            value: e
                        } = i;
                        if (Array.isArray(e)) {
                            const {
                                value: t
                            } = o;
                            return !~e.findIndex((e => e === t))
                        }
                        if (e) {
                            const {
                                value: t
                            } = o;
                            return t !== e
                        }
                        return !0
                    }));
                    return {
                        rtlEnabled: lu("Collapse", t, a),
                        collapseSlots: s,
                        randomName: n,
                        mergedClsPrefix: a,
                        collapsed: c,
                        triggerAreas: Dt(l, "triggerAreas"),
                        mergedDisplayDirective: zi((() => {
                            const {
                                displayDirective: t
                            } = e;
                            return t || l.displayDirective
                        })),
                        arrowPlacement: zi((() => l.arrowPlacement)),
                        handleClick(t) {
                            let n = "main";
                            Dh(t, "arrow") && (n = "arrow"), Dh(t, "extra") && (n = "extra"), l.triggerAreas.includes(n) && r && !e.disabled && r.toggleItem(c.value, o.value, t)
                        }
                    }
                },
                render() {
                    const {
                        collapseSlots: e,
                        $slots: t,
                        arrowPlacement: n,
                        collapsed: o,
                        mergedDisplayDirective: r,
                        mergedClsPrefix: i,
                        disabled: l,
                        triggerAreas: a
                    } = this, s = ud(t.header, {
                        collapsed: o
                    }, (() => [this.title])), c = t["header-extra"] || e["header-extra"], u = t.arrow || e.arrow;
                    return Ti("div", {
                        class: [`${i}-collapse-item`, `${i}-collapse-item--${n}-arrow-placement`, l && `${i}-collapse-item--disabled`, !o && `${i}-collapse-item--active`, a.map((e => `${i}-collapse-item--trigger-area-${e}`))]
                    }, Ti("div", {
                        class: [`${i}-collapse-item__header`, !o && `${i}-collapse-item__header--active`]
                    }, Ti("div", {
                        class: `${i}-collapse-item__header-main`,
                        onClick: this.handleClick
                    }, "right" === n && s, Ti("div", {
                        class: `${i}-collapse-item-arrow`,
                        key: this.rtlEnabled ? 0 : 1,
                        "data-arrow": !0
                    }, ud(u, {
                        collapsed: o
                    }, (() => {
                        var t;
                        return [Ti(Qp, {
                            clsPrefix: i
                        }, {
                            default: null !== (t = e.expandIcon) && void 0 !== t ? t : () => this.rtlEnabled ? Ti(Lh, null) : Ti(jh, null)
                        })]
                    }))), "left" === n && s), (f = {
                        collapsed: o
                    }, (e => Ti("div", {
                        class: `${i}-collapse-item__header-extra`,
                        onClick: this.handleClick,
                        "data-extra": !0
                    }, e))((d = c) && sd(d(f)) || null))), Ti(Hh, {
                        clsPrefix: i,
                        displayDirective: r,
                        show: !o
                    }, t));
                    var d, f
                }
            }),
            Vh = {
                sizeSmall: "14px",
                sizeMedium: "16px",
                sizeLarge: "18px",
                labelPadding: "0 8px",
                labelFontWeight: "400"
            };
        const qh = {
            name: "Checkbox",
            common: of,
            self: function(e) {
                const {
                    baseColor: t,
                    inputColorDisabled: n,
                    cardColor: o,
                    modalColor: r,
                    popoverColor: i,
                    textColorDisabled: l,
                    borderColor: a,
                    primaryColor: s,
                    textColor2: c,
                    fontSizeSmall: u,
                    fontSizeMedium: d,
                    fontSizeLarge: f,
                    borderRadiusSmall: p,
                    lineHeight: h
                } = e;
                return Object.assign(Object.assign({}, Vh), {
                    labelLineHeight: h,
                    fontSizeSmall: u,
                    fontSizeMedium: d,
                    fontSizeLarge: f,
                    borderRadius: p,
                    color: t,
                    colorChecked: s,
                    colorDisabled: n,
                    colorDisabledChecked: n,
                    colorTableHeader: o,
                    colorTableHeaderModal: r,
                    colorTableHeaderPopover: i,
                    checkMarkColor: t,
                    checkMarkColorDisabled: l,
                    checkMarkColorDisabledChecked: l,
                    border: `1px solid ${a}`,
                    borderDisabled: `1px solid ${a}`,
                    borderDisabledChecked: `1px solid ${a}`,
                    borderChecked: `1px solid ${s}`,
                    borderFocus: `1px solid ${s}`,
                    boxShadowFocus: `0 0 0 2px ${Kc(s,{alpha:.3})}`,
                    textColor: c,
                    textColorDisabled: l
                })
            }
        };
        var Uh = qh,
            Kh = Ti("svg", {
                viewBox: "0 0 64 64",
                class: "check-icon"
            }, Ti("path", {
                d: "M50.42,16.76L22.34,39.45l-8.1-11.46c-1.12-1.58-3.3-1.96-4.88-0.84c-1.58,1.12-1.95,3.3-0.84,4.88l10.26,14.51  c0.56,0.79,1.42,1.31,2.38,1.45c0.16,0.02,0.32,0.03,0.48,0.03c0.8,0,1.57-0.27,2.2-0.78l30.99-25.03c1.5-1.21,1.74-3.42,0.52-4.92  C54.13,15.78,51.93,15.55,50.42,16.76z"
            })),
            Gh = Ti("svg", {
                viewBox: "0 0 100 100",
                class: "line-icon"
            }, Ti("path", {
                d: "M80.2,55.5H21.4c-2.8,0-5.1-2.5-5.1-5.5l0,0c0-3,2.3-5.5,5.1-5.5h58.7c2.8,0,5.1,2.5,5.1,5.5l0,0C85.2,53.1,82.9,55.5,80.2,55.5z"
            }));
        const Xh = "n-checkbox-group";
        Tn({
            name: "CheckboxGroup",
            props: {
                min: Number,
                max: Number,
                size: String,
                value: Array,
                defaultValue: {
                    type: Array,
                    default: null
                },
                disabled: {
                    type: Boolean,
                    default: void 0
                },
                "onUpdate:value": [Function, Array],
                onUpdateValue: [Function, Array],
                onChange: [Function, Array]
            },
            setup(e) {
                const {
                    mergedClsPrefixRef: t
                } = zc(e), n = Uu(e), {
                    mergedSizeRef: o,
                    mergedDisabledRef: r
                } = n, i = Ft(e.defaultValue), l = df(zi((() => e.value)), i), a = zi((() => {
                    var e;
                    return (null === (e = l.value) || void 0 === e ? void 0 : e.length) || 0
                })), s = zi((() => Array.isArray(l.value) ? new Set(l.value) : new Set));
                return $o(Xh, {
                    checkedCountRef: a,
                    maxRef: Dt(e, "max"),
                    minRef: Dt(e, "min"),
                    valueSetRef: s,
                    disabledRef: r,
                    mergedSizeRef: o,
                    toggleCheckbox: function(t, o) {
                        const {
                            nTriggerFormInput: r,
                            nTriggerFormChange: a
                        } = n, {
                            onChange: s,
                            "onUpdate:value": c,
                            onUpdateValue: u
                        } = e;
                        if (Array.isArray(l.value)) {
                            const e = Array.from(l.value),
                                n = e.findIndex((e => e === o));
                            t ? ~n || (e.push(o), u && ld(u, e, {
                                actionType: "check",
                                value: o
                            }), c && ld(c, e, {
                                actionType: "check",
                                value: o
                            }), r(), a(), i.value = e, s && ld(s, e)) : ~n && (e.splice(n, 1), u && ld(u, e, {
                                actionType: "uncheck",
                                value: o
                            }), c && ld(c, e, {
                                actionType: "uncheck",
                                value: o
                            }), s && ld(s, e), i.value = e, r(), a())
                        } else t ? (u && ld(u, [o], {
                            actionType: "check",
                            value: o
                        }), c && ld(c, [o], {
                            actionType: "check",
                            value: o
                        }), s && ld(s, [o]), i.value = [o], r(), a()) : (u && ld(u, [], {
                            actionType: "uncheck",
                            value: o
                        }), c && ld(c, [], {
                            actionType: "uncheck",
                            value: o
                        }), s && ld(s, []), i.value = [], r(), a())
                    }
                }), {
                    mergedClsPrefix: t
                }
            },
            render() {
                return Ti("div", {
                    class: `${this.mergedClsPrefix}-checkbox-group`,
                    role: "group"
                }, this.$slots)
            }
        });
        var Yh = Fu([Ru("checkbox", "\n font-size: var(--n-font-size);\n outline: none;\n cursor: pointer;\n display: inline-flex;\n flex-wrap: nowrap;\n align-items: flex-start;\n word-break: break-word;\n line-height: var(--n-size);\n --n-merged-color-table: var(--n-color-table);\n ", [Ou("show-label", "line-height: var(--n-label-line-height);"), Fu("&:hover", [Ru("checkbox-box", [Eu("border", "border: var(--n-border-checked);")])]), Fu("&:focus:not(:active)", [Ru("checkbox-box", [Eu("border", "\n border: var(--n-border-focus);\n box-shadow: var(--n-box-shadow-focus);\n ")])]), Ou("inside-table", [Ru("checkbox-box", "\n background-color: var(--n-merged-color-table);\n ")]), Ou("checked", [Ru("checkbox-box", "\n background-color: var(--n-color-checked);\n ", [Ru("checkbox-icon", [Fu(".check-icon", "\n opacity: 1;\n transform: scale(1);\n ")])])]), Ou("indeterminate", [Ru("checkbox-box", [Ru("checkbox-icon", [Fu(".check-icon", "\n opacity: 0;\n transform: scale(.5);\n "), Fu(".line-icon", "\n opacity: 1;\n transform: scale(1);\n ")])])]), Ou("checked, indeterminate", [Fu("&:focus:not(:active)", [Ru("checkbox-box", [Eu("border", "\n border: var(--n-border-checked);\n box-shadow: var(--n-box-shadow-focus);\n ")])]), Ru("checkbox-box", "\n background-color: var(--n-color-checked);\n border-left: 0;\n border-top: 0;\n ", [Eu("border", {
            border: "var(--n-border-checked)"
        })])]), Ou("disabled", {
            cursor: "not-allowed"
        }, [Ou("checked", [Ru("checkbox-box", "\n background-color: var(--n-color-disabled-checked);\n ", [Eu("border", {
            border: "var(--n-border-disabled-checked)"
        }), Ru("checkbox-icon", [Fu(".check-icon, .line-icon", {
            fill: "var(--n-check-mark-color-disabled-checked)"
        })])])]), Ru("checkbox-box", "\n background-color: var(--n-color-disabled);\n ", [Eu("border", "\n border: var(--n-border-disabled);\n "), Ru("checkbox-icon", [Fu(".check-icon, .line-icon", "\n fill: var(--n-check-mark-color-disabled);\n ")])]), Eu("label", "\n color: var(--n-text-color-disabled);\n ")]), Ru("checkbox-box-wrapper", "\n position: relative;\n width: var(--n-size);\n flex-shrink: 0;\n flex-grow: 0;\n user-select: none;\n -webkit-user-select: none;\n "), Ru("checkbox-box", "\n position: absolute;\n left: 0;\n top: 50%;\n transform: translateY(-50%);\n height: var(--n-size);\n width: var(--n-size);\n display: inline-block;\n box-sizing: border-box;\n border-radius: var(--n-border-radius);\n background-color: var(--n-color);\n transition: background-color 0.3s var(--n-bezier);\n ", [Eu("border", "\n transition:\n border-color .3s var(--n-bezier),\n box-shadow .3s var(--n-bezier);\n border-radius: inherit;\n position: absolute;\n left: 0;\n right: 0;\n top: 0;\n bottom: 0;\n border: var(--n-border);\n "), Ru("checkbox-icon", "\n display: flex;\n align-items: center;\n justify-content: center;\n position: absolute;\n left: 1px;\n right: 1px;\n top: 1px;\n bottom: 1px;\n ", [Fu(".check-icon, .line-icon", "\n width: 100%;\n fill: var(--n-check-mark-color);\n opacity: 0;\n transform: scale(0.5);\n transform-origin: center;\n transition:\n fill 0.3s var(--n-bezier),\n transform 0.3s var(--n-bezier),\n opacity 0.3s var(--n-bezier),\n border-color 0.3s var(--n-bezier);\n "), Qu({
            left: "1px",
            top: "1px"
        })])]), Eu("label", "\n color: var(--n-text-color);\n transition: color .3s var(--n-bezier);\n user-select: none;\n -webkit-user-select: none;\n padding: var(--n-label-padding);\n font-weight: var(--n-label-font-weight);\n ", [Fu("&:empty", {
            display: "none"
        })])]), function(e) {
            return Fu((({
                props: {
                    bPrefix: e
                }
            }) => `${e||zu}modal, ${e||zu}drawer`), [e])
        }(Ru("checkbox", "\n --n-merged-color-table: var(--n-color-table-modal);\n ")), function(e) {
            return Fu((({
                props: {
                    bPrefix: e
                }
            }) => `${e||zu}popover`), [e])
        }(Ru("checkbox", "\n --n-merged-color-table: var(--n-color-table-popover);\n "))]);
        var Zh = Tn({
            name: "Checkbox",
            props: Object.assign(Object.assign({}, Vu.props), {
                size: String,
                checked: {
                    type: [Boolean, String, Number],
                    default: void 0
                },
                defaultChecked: {
                    type: [Boolean, String, Number],
                    default: !1
                },
                value: [String, Number],
                disabled: {
                    type: Boolean,
                    default: void 0
                },
                indeterminate: Boolean,
                label: String,
                focusable: {
                    type: Boolean,
                    default: !0
                },
                checkedValue: {
                    type: [Boolean, String, Number],
                    default: !0
                },
                uncheckedValue: {
                    type: [Boolean, String, Number],
                    default: !1
                },
                "onUpdate:checked": [Function, Array],
                onUpdateChecked: [Function, Array],
                privateInsideTable: Boolean,
                onChange: [Function, Array]
            }),
            setup(e) {
                const t = _o(Xh, null),
                    n = Ft(null),
                    {
                        mergedClsPrefixRef: o,
                        inlineThemeDisabled: r,
                        mergedRtlRef: i
                    } = zc(e),
                    l = Ft(e.defaultChecked),
                    a = df(Dt(e, "checked"), l),
                    s = Il((() => {
                        if (t) {
                            const n = t.valueSetRef.value;
                            return !(!n || void 0 === e.value) && n.has(e.value)
                        }
                        return a.value === e.checkedValue
                    })),
                    c = Uu(e, {
                        mergedSize(n) {
                            const {
                                size: o
                            } = e;
                            if (void 0 !== o) return o;
                            if (t) {
                                const {
                                    value: e
                                } = t.mergedSizeRef;
                                if (void 0 !== e) return e
                            }
                            if (n) {
                                const {
                                    mergedSize: e
                                } = n;
                                if (void 0 !== e) return e.value
                            }
                            return "medium"
                        },
                        mergedDisabled(n) {
                            const {
                                disabled: o
                            } = e;
                            if (void 0 !== o) return o;
                            if (t) {
                                if (t.disabledRef.value) return !0;
                                const {
                                    maxRef: {
                                        value: e
                                    },
                                    checkedCountRef: n
                                } = t;
                                if (void 0 !== e && n.value >= e && !s.value) return !0;
                                const {
                                    minRef: {
                                        value: o
                                    }
                                } = t;
                                if (void 0 !== o && n.value <= o && s.value) return !0
                            }
                            return !!n && n.disabled.value
                        }
                    }),
                    {
                        mergedDisabledRef: u,
                        mergedSizeRef: d
                    } = c,
                    f = Vu("Checkbox", "-checkbox", Yh, Uh, e, o);

                function p(n) {
                    if (t && void 0 !== e.value) t.toggleCheckbox(!s.value, e.value);
                    else {
                        const {
                            onChange: t,
                            "onUpdate:checked": o,
                            onUpdateChecked: r
                        } = e, {
                            nTriggerFormInput: i,
                            nTriggerFormChange: a
                        } = c, u = s.value ? e.uncheckedValue : e.checkedValue;
                        o && ld(o, u, n), r && ld(r, u, n), t && ld(t, u, n), i(), a(), l.value = u
                    }
                }
                const h = {
                        focus: () => {
                            var e;
                            null === (e = n.value) || void 0 === e || e.focus()
                        },
                        blur: () => {
                            var e;
                            null === (e = n.value) || void 0 === e || e.blur()
                        }
                    },
                    v = lu("Checkbox", i, o),
                    g = zi((() => {
                        const {
                            value: e
                        } = d, {
                            common: {
                                cubicBezierEaseInOut: t
                            },
                            self: {
                                borderRadius: n,
                                color: o,
                                colorChecked: r,
                                colorDisabled: i,
                                colorTableHeader: l,
                                colorTableHeaderModal: a,
                                colorTableHeaderPopover: s,
                                checkMarkColor: c,
                                checkMarkColorDisabled: u,
                                border: p,
                                borderFocus: h,
                                borderDisabled: v,
                                borderChecked: g,
                                boxShadowFocus: b,
                                textColor: m,
                                textColorDisabled: y,
                                checkMarkColorDisabledChecked: x,
                                colorDisabledChecked: w,
                                borderDisabledChecked: C,
                                labelPadding: S,
                                labelLineHeight: k,
                                labelFontWeight: $,
                                [Iu("fontSize", e)]: _,
                                [Iu("size", e)]: z
                            }
                        } = f.value;
                        return {
                            "--n-label-line-height": k,
                            "--n-label-font-weight": $,
                            "--n-size": z,
                            "--n-bezier": t,
                            "--n-border-radius": n,
                            "--n-border": p,
                            "--n-border-checked": g,
                            "--n-border-focus": h,
                            "--n-border-disabled": v,
                            "--n-border-disabled-checked": C,
                            "--n-box-shadow-focus": b,
                            "--n-color": o,
                            "--n-color-checked": r,
                            "--n-color-table": l,
                            "--n-color-table-modal": a,
                            "--n-color-table-popover": s,
                            "--n-color-disabled": i,
                            "--n-color-disabled-checked": w,
                            "--n-text-color": m,
                            "--n-text-color-disabled": y,
                            "--n-check-mark-color": c,
                            "--n-check-mark-color-disabled": u,
                            "--n-check-mark-color-disabled-checked": x,
                            "--n-font-size": _,
                            "--n-label-padding": S
                        }
                    })),
                    b = r ? Ku("checkbox", zi((() => d.value[0])), g, e) : void 0;
                return Object.assign(c, h, {
                    rtlEnabled: v,
                    selfRef: n,
                    mergedClsPrefix: o,
                    mergedDisabled: u,
                    renderedChecked: s,
                    mergedTheme: f,
                    labelId: Ih(),
                    handleClick: function(e) {
                        u.value || p(e)
                    },
                    handleKeyUp: function(e) {
                        if (!u.value) switch (e.key) {
                            case " ":
                            case "Enter":
                                p(e)
                        }
                    },
                    handleKeyDown: function(e) {
                        if (" " === e.key) e.preventDefault()
                    },
                    cssVars: r ? void 0 : g,
                    themeClass: null == b ? void 0 : b.themeClass,
                    onRender: null == b ? void 0 : b.onRender
                })
            },
            render() {
                var e;
                const {
                    $slots: t,
                    renderedChecked: n,
                    mergedDisabled: o,
                    indeterminate: r,
                    privateInsideTable: i,
                    cssVars: l,
                    labelId: a,
                    label: s,
                    mergedClsPrefix: c,
                    focusable: u,
                    handleKeyUp: d,
                    handleKeyDown: f,
                    handleClick: p
                } = this;
                null === (e = this.onRender) || void 0 === e || e.call(this);
                const h = dd(t.default, (e => s || e ? Ti("span", {
                    class: `${c}-checkbox__label`,
                    id: a
                }, s || e) : null));
                return Ti("div", {
                    ref: "selfRef",
                    class: [`${c}-checkbox`, this.themeClass, this.rtlEnabled && `${c}-checkbox--rtl`, n && `${c}-checkbox--checked`, o && `${c}-checkbox--disabled`, r && `${c}-checkbox--indeterminate`, i && `${c}-checkbox--inside-table`, h && `${c}-checkbox--show-label`],
                    tabindex: o || !u ? void 0 : 0,
                    role: "checkbox",
                    "aria-checked": r ? "mixed" : n,
                    "aria-labelledby": a,
                    style: l,
                    onKeyup: d,
                    onKeydown: f,
                    onClick: p,
                    onMousedown: () => {
                        sp("selectstart", window, (e => {
                            e.preventDefault()
                        }), {
                            once: !0
                        })
                    }
                }, Ti("div", {
                    class: `${c}-checkbox-box-wrapper`
                }, " ", Ti("div", {
                    class: `${c}-checkbox-box`
                }, Ti(Yu, null, {
                    default: () => this.indeterminate ? Ti("div", {
                        key: "indeterminate",
                        class: `${c}-checkbox-icon`
                    }, Gh) : Ti("div", {
                        key: "check",
                        class: `${c}-checkbox-icon`
                    }, Kh)
                }), Ti("div", {
                    class: `${c}-checkbox-box__border`
                }))), h)
            }
        });

        function Jh(e) {
            return Array.isArray(e) ? e : [e]
        }
        const Qh = {
            STOP: "STOP"
        };

        function ev(e, t) {
            const n = t(e);
            void 0 !== e.children && n !== Qh.STOP && e.children.forEach((e => ev(e, t)))
        }

        function tv(e) {
            return e.children
        }

        function nv(e) {
            return e.key
        }

        function ov() {
            return !1
        }

        function rv(e) {
            return !0 === e.disabled
        }

        function iv(e) {
            var t;
            return null == e ? [] : Array.isArray(e) ? e : null !== (t = e.checkedKeys) && void 0 !== t ? t : []
        }

        function lv(e) {
            var t;
            return null == e || Array.isArray(e) ? [] : null !== (t = e.indeterminateKeys) && void 0 !== t ? t : []
        }

        function av(e, t) {
            const n = new Set(e);
            return t.forEach((e => {
                n.has(e) || n.add(e)
            })), Array.from(n)
        }

        function sv(e, t) {
            const n = new Set(e);
            return t.forEach((e => {
                n.has(e) && n.delete(e)
            })), Array.from(n)
        }

        function cv(e) {
            return "group" === (null == e ? void 0 : e.type)
        }
        class uv extends Error {
            constructor() {
                super(), this.message = "SubtreeNotLoadedError: checking a subtree whose required nodes are not fully loaded."
            }
        }

        function dv(e, t, n, o) {
            const r = pv(t, n, o, !1),
                i = pv(e, n, o, !0),
                l = function(e, t) {
                    const n = new Set;
                    return e.forEach((e => {
                        const o = t.treeNodeMap.get(e);
                        if (void 0 !== o) {
                            let e = o.parent;
                            for (; null !== e && !e.disabled && !n.has(e.key);) n.add(e.key), e = e.parent
                        }
                    })), n
                }(e, n),
                a = [];
            return r.forEach((e => {
                (i.has(e) || l.has(e)) && a.push(e)
            })), a.forEach((e => r.delete(e))), r
        }

        function fv(e, t) {
            const {
                checkedKeys: n,
                keysToCheck: o,
                keysToUncheck: r,
                indeterminateKeys: i,
                cascade: l,
                leafOnly: a,
                checkStrategy: s,
                allowNotLoaded: c
            } = e;
            if (!l) return void 0 !== o ? {
                checkedKeys: av(n, o),
                indeterminateKeys: Array.from(i)
            } : void 0 !== r ? {
                checkedKeys: sv(n, r),
                indeterminateKeys: Array.from(i)
            } : {
                checkedKeys: Array.from(n),
                indeterminateKeys: Array.from(i)
            };
            const {
                levelTreeNodeMap: u
            } = t;
            let d;
            d = void 0 !== r ? dv(r, n, t, c) : void 0 !== o ? function(e, t, n, o) {
                return pv(t.concat(e), n, o, !1)
            }(o, n, t, c) : pv(n, t, c, !1);
            const f = "parent" === s,
                p = "child" === s || a,
                h = d,
                v = new Set;
            for (let e = Math.max.apply(null, Array.from(u.keys())); e >= 0; e -= 1) {
                const t = 0 === e,
                    n = u.get(e);
                for (const e of n) {
                    if (e.isLeaf) continue;
                    const {
                        key: n,
                        shallowLoaded: o
                    } = e;
                    if (p && o && e.children.forEach((e => {
                            !e.disabled && !e.isLeaf && e.shallowLoaded && h.has(e.key) && h.delete(e.key)
                        })), e.disabled || !o) continue;
                    let r = !0,
                        i = !1,
                        l = !0;
                    for (const t of e.children) {
                        const e = t.key;
                        if (!t.disabled)
                            if (l && (l = !1), h.has(e)) i = !0;
                            else {
                                if (v.has(e)) {
                                    i = !0, r = !1;
                                    break
                                }
                                if (r = !1, i) break
                            }
                    }
                    r && !l ? (f && e.children.forEach((e => {
                        !e.disabled && h.has(e.key) && h.delete(e.key)
                    })), h.add(n)) : i && v.add(n), t && p && h.has(n) && h.delete(n)
                }
            }
            return {
                checkedKeys: Array.from(h),
                indeterminateKeys: Array.from(v)
            }
        }

        function pv(e, t, n, o) {
            const {
                treeNodeMap: r,
                getChildren: i
            } = t, l = new Set, a = new Set(e);
            return e.forEach((e => {
                const t = r.get(e);
                void 0 !== t && ev(t, (e => {
                    if (e.disabled) return Qh.STOP;
                    const {
                        key: t
                    } = e;
                    if (!l.has(t) && (l.add(t), a.add(t), function(e, t) {
                            return !1 === e.isLeaf && !Array.isArray(t(e))
                        }(e.rawNode, i))) {
                        if (o) return Qh.STOP;
                        if (!n) throw new uv
                    }
                }))
            })), a
        }

        function hv(e, t) {
            const n = e.siblings,
                o = n.length,
                {
                    index: r
                } = e;
            return t ? n[(r + 1) % o] : r === n.length - 1 ? null : n[r + 1]
        }

        function vv(e, t, {
            loop: n = !1,
            includeDisabled: o = !1
        } = {}) {
            const r = "prev" === t ? gv : hv,
                i = {
                    reverse: "prev" === t
                };
            let l = !1,
                a = null;
            return function t(s) {
                if (null !== s) {
                    if (s === e)
                        if (l) {
                            if (!e.disabled && !e.isGroup) return void(a = e)
                        } else l = !0;
                    else if ((!s.disabled || o) && !s.ignored && !s.isGroup) return void(a = s);
                    if (s.isGroup) {
                        const e = bv(s, i);
                        null !== e ? a = e : t(r(s, n))
                    } else {
                        const e = r(s, !1);
                        if (null !== e) t(e);
                        else {
                            const e = function(e) {
                                return e.parent
                            }(s);
                            (null == e ? void 0 : e.isGroup) ? t(r(e, n)): n && t(r(s, !0))
                        }
                    }
                }
            }(e), a
        }

        function gv(e, t) {
            const n = e.siblings,
                o = n.length,
                {
                    index: r
                } = e;
            return t ? n[(r - 1 + o) % o] : 0 === r ? null : n[r - 1]
        }

        function bv(e, t = {}) {
            const {
                reverse: n = !1
            } = t, {
                children: o
            } = e;
            if (o) {
                const {
                    length: e
                } = o, r = n ? -1 : e, i = n ? -1 : 1;
                for (let l = n ? e - 1 : 0; l !== r; l += i) {
                    const e = o[l];
                    if (!e.disabled && !e.ignored) {
                        if (!e.isGroup) return e;
                        {
                            const n = bv(e, t);
                            if (null !== n) return n
                        }
                    }
                }
            }
            return null
        }
        const mv = {
            getChild() {
                return this.ignored ? null : bv(this)
            },
            getParent() {
                const {
                    parent: e
                } = this;
                return (null == e ? void 0 : e.isGroup) ? e.getParent() : e
            },
            getNext(e = {}) {
                return vv(this, "next", e)
            },
            getPrev(e = {}) {
                return vv(this, "prev", e)
            }
        };

        function yv(e, t, n, o, r, i = null, l = 0) {
            const a = [];
            return e.forEach(((s, c) => {
                var u;
                const d = Object.create(o);
                if (d.rawNode = s, d.siblings = a, d.level = l, d.index = c, d.isFirstChild = 0 === c, d.isLastChild = c + 1 === e.length, d.parent = i, !d.ignored) {
                    const e = r(s);
                    Array.isArray(e) && (d.children = yv(e, t, n, o, r, d, l + 1))
                }
                a.push(d), t.set(d.key, d), n.has(l) || n.set(l, []), null === (u = n.get(l)) || void 0 === u || u.push(d)
            })), a
        }

        function xv(e, t = {}) {
            var n;
            const o = new Map,
                r = new Map,
                {
                    getDisabled: i = rv,
                    getIgnored: l = ov,
                    getIsGroup: a = cv,
                    getKey: s = nv
                } = t,
                c = null !== (n = t.getChildren) && void 0 !== n ? n : tv,
                u = t.ignoreEmptyChildren ? e => {
                    const t = c(e);
                    return Array.isArray(t) ? t.length ? t : null : t
                } : c,
                d = Object.assign({
                    get key() {
                        return s(this.rawNode)
                    },
                    get disabled() {
                        return i(this.rawNode)
                    },
                    get isGroup() {
                        return a(this.rawNode)
                    },
                    get isLeaf() {
                        return function(e, t) {
                            const {
                                isLeaf: n
                            } = e;
                            return void 0 !== n ? n : !t(e)
                        }(this.rawNode, u)
                    },
                    get shallowLoaded() {
                        return function(e, t) {
                            const {
                                isLeaf: n
                            } = e;
                            return !(!1 === n && !Array.isArray(t(e)))
                        }(this.rawNode, u)
                    },
                    get ignored() {
                        return l(this.rawNode)
                    },
                    contains(e) {
                        return function(e, t) {
                            const n = e.key;
                            for (; t;) {
                                if (t.key === n) return !0;
                                t = t.parent
                            }
                            return !1
                        }(this, e)
                    }
                }, mv),
                f = yv(e, o, r, d, u);

            function p(e) {
                if (null == e) return null;
                const t = o.get(e);
                return t && !t.ignored ? t : null
            }
            const h = {
                treeNodes: f,
                treeNodeMap: o,
                levelTreeNodeMap: r,
                maxLevel: Math.max(...r.keys()),
                getChildren: u,
                getFlattenedNodes(e) {
                    return function(e, t) {
                        const n = t ? new Set(t) : void 0,
                            o = [];
                        return function e(t) {
                            t.forEach((t => {
                                o.push(t), t.isLeaf || !t.children || t.ignored || (t.isGroup || void 0 === n || n.has(t.key)) && e(t.children)
                            }))
                        }(e), o
                    }(f, e)
                },
                getNode: function(e) {
                    if (null == e) return null;
                    const t = o.get(e);
                    return !t || t.isGroup || t.ignored ? null : t
                },
                getPrev: function(e, t) {
                    const n = p(e);
                    return n ? n.getPrev(t) : null
                },
                getNext: function(e, t) {
                    const n = p(e);
                    return n ? n.getNext(t) : null
                },
                getParent: function(e) {
                    const t = p(e);
                    return t ? t.getParent() : null
                },
                getChild: function(e) {
                    const t = p(e);
                    return t ? t.getChild() : null
                },
                getFirstAvailableNode() {
                    return function(e) {
                        if (0 === e.length) return null;
                        const t = e[0];
                        return t.isGroup || t.ignored || t.disabled ? t.getNext() : t
                    }(f)
                },
                getPath(e, t = {}) {
                    return function(e, {
                        includeGroup: t = !1,
                        includeSelf: n = !0
                    }, o) {
                        var r;
                        const i = o.treeNodeMap;
                        let l = null == e ? null : null !== (r = i.get(e)) && void 0 !== r ? r : null;
                        const a = {
                            keyPath: [],
                            treeNodePath: [],
                            treeNode: l
                        };
                        if (null == l ? void 0 : l.ignored) return a.treeNode = null, a;
                        for (; l;) l.ignored || !t && l.isGroup || a.treeNodePath.push(l), l = l.parent;
                        return a.treeNodePath.reverse(), n || a.treeNodePath.pop(), a.keyPath = a.treeNodePath.map((e => e.key)), a
                    }(e, t, h)
                },
                getCheckedKeys(e, t = {}) {
                    const {
                        cascade: n = !0,
                        leafOnly: o = !1,
                        checkStrategy: r = "all",
                        allowNotLoaded: i = !1
                    } = t;
                    return fv({
                        checkedKeys: iv(e),
                        indeterminateKeys: lv(e),
                        cascade: n,
                        leafOnly: o,
                        checkStrategy: r,
                        allowNotLoaded: i
                    }, h)
                },
                check(e, t, n = {}) {
                    const {
                        cascade: o = !0,
                        leafOnly: r = !1,
                        checkStrategy: i = "all",
                        allowNotLoaded: l = !1
                    } = n;
                    return fv({
                        checkedKeys: iv(t),
                        indeterminateKeys: lv(t),
                        keysToCheck: null == e ? [] : Jh(e),
                        cascade: o,
                        leafOnly: r,
                        checkStrategy: i,
                        allowNotLoaded: l
                    }, h)
                },
                uncheck(e, t, n = {}) {
                    const {
                        cascade: o = !0,
                        leafOnly: r = !1,
                        checkStrategy: i = "all",
                        allowNotLoaded: l = !1
                    } = n;
                    return fv({
                        checkedKeys: iv(t),
                        indeterminateKeys: lv(t),
                        keysToUncheck: null == e ? [] : Jh(e),
                        cascade: o,
                        leafOnly: r,
                        checkStrategy: i,
                        allowNotLoaded: l
                    }, h)
                },
                getNonLeafKeys(e = {}) {
                    return function(e, t = {}) {
                        const {
                            preserveGroup: n = !1
                        } = t, o = [], r = n ? e => {
                            e.isLeaf || (o.push(e.key), i(e.children))
                        } : e => {
                            e.isLeaf || (e.isGroup || o.push(e.key), i(e.children))
                        };

                        function i(e) {
                            e.forEach(r)
                        }
                        return i(e), o
                    }(f, e)
                }
            };
            return h
        }
        let wv = [];
        const Cv = new WeakMap;

        function Sv() {
            wv.forEach((e => e(...Cv.get(e)))), wv = []
        }

        function kv(e, ...t) {
            Cv.set(e, t), wv.includes(e) || 1 === wv.push(e) && requestAnimationFrame(Sv)
        }

        function $v(e, t, n = "default") {
            const o = t[n];
            if (void 0 === o) throw new Error(`[vueuc/${e}]: slot[${n}] is empty.`);
            return o()
        }

        function _v(e, t = !0, n = []) {
            return e.forEach((e => {
                if (null !== e)
                    if ("object" == typeof e)
                        if (Array.isArray(e)) _v(e, t, n);
                        else if (e.type === Mr) {
                    if (null === e.children) return;
                    Array.isArray(e.children) && _v(e.children, t, n)
                } else e.type !== Er && n.push(e);
                else "string" != typeof e && "number" != typeof e || n.push(Qr(String(e)))
            })), n
        }

        function zv(e, t, n = "default") {
            const o = t[n];
            if (void 0 === o) throw new Error(`[vueuc/${e}]: slot[${n}] is empty.`);
            const r = _v(o());
            if (1 === r.length) return r[0];
            throw new Error(`[vueuc/${e}]: slot[${n}] should have exactly one child.`)
        }
        let Tv = null;

        function Pv() {
            if (null === Tv && (Tv = document.getElementById("v-binder-view-measurer"), null === Tv)) {
                Tv = document.createElement("div"), Tv.id = "v-binder-view-measurer";
                const {
                    style: e
                } = Tv;
                e.position = "fixed", e.left = "0", e.right = "0", e.top = "0", e.bottom = "0", e.pointerEvents = "none", e.visibility = "hidden", document.body.appendChild(Tv)
            }
            return Tv.getBoundingClientRect()
        }

        function Fv(e) {
            const t = e.getBoundingClientRect(),
                n = Pv();
            return {
                left: t.left - n.left,
                top: t.top - n.top,
                bottom: n.height + n.top - t.bottom,
                right: n.width + n.left - t.right,
                width: t.width,
                height: t.height
            }
        }

        function Mv(e) {
            if (null === e) return null;
            const t = function(e) {
                return 9 === e.nodeType ? null : e.parentNode
            }(e);
            if (null === t) return null;
            if (9 === t.nodeType) return document;
            if (1 === t.nodeType) {
                const {
                    overflow: e,
                    overflowX: n,
                    overflowY: o
                } = getComputedStyle(t);
                if (/(auto|scroll|overlay)/.test(e + o + n)) return t
            }
            return Mv(t)
        }
        const Rv = Tn({
            name: "Binder",
            props: {
                syncTargetWithParent: Boolean,
                syncTarget: {
                    type: Boolean,
                    default: !0
                }
            },
            setup(e) {
                var t;
                $o("VBinder", null === (t = ui()) || void 0 === t ? void 0 : t.proxy);
                const n = _o("VBinder", null),
                    o = Ft(null);
                let r = [];
                const i = () => {
                        for (const e of r) cp("scroll", e, a, !0);
                        r = []
                    },
                    l = new Set,
                    a = () => {
                        kv(s)
                    },
                    s = () => {
                        l.forEach((e => e()))
                    },
                    c = new Set,
                    u = () => {
                        c.forEach((e => e()))
                    };
                return Vn((() => {
                    cp("resize", window, u), i()
                })), {
                    targetRef: o,
                    setTargetRef: t => {
                        o.value = t, n && e.syncTargetWithParent && n.setTargetRef(t)
                    },
                    addScrollListener: e => {
                        0 === l.size && (() => {
                            let e = o.value;
                            for (; e = Mv(e), null !== e;) r.push(e);
                            for (const e of r) sp("scroll", e, a, !0)
                        })(), l.has(e) || l.add(e)
                    },
                    removeScrollListener: e => {
                        l.has(e) && l.delete(e), 0 === l.size && i()
                    },
                    addResizeListener: e => {
                        0 === c.size && sp("resize", window, u), c.has(e) || c.add(e)
                    },
                    removeResizeListener: e => {
                        c.has(e) && c.delete(e), 0 === c.size && cp("resize", window, u)
                    }
                }
            },
            render() {
                return $v("binder", this.$slots)
            }
        });
        var Ev = Rv,
            Ov = Tn({
                name: "Target",
                setup() {
                    const {
                        setTargetRef: e,
                        syncTarget: t
                    } = _o("VBinder");
                    return {
                        syncTarget: t,
                        setTargetDirective: {
                            mounted: e,
                            updated: e
                        }
                    }
                },
                render() {
                    const {
                        syncTarget: e,
                        setTargetDirective: t
                    } = this;
                    return e ? fn(zv("follower", this.$slots), [
                        [t]
                    ]) : zv("follower", this.$slots)
                }
            });
        new Set;
        var Bv = new class {
            constructor() {
                this.elementZIndex = new Map, this.nextZIndex = 2e3
            }
            get elementCount() {
                return this.elementZIndex.size
            }
            ensureZIndex(e, t) {
                const {
                    elementZIndex: n
                } = this;
                if (void 0 !== t) return e.style.zIndex = `${t}`, void n.delete(e);
                const {
                    nextZIndex: o
                } = this;
                if (n.has(e)) {
                    if (n.get(e) + 1 === this.nextZIndex) return
                }
                e.style.zIndex = `${o}`, n.set(e, o), this.nextZIndex = o + 1, this.squashState()
            }
            unregister(e, t) {
                const {
                    elementZIndex: n
                } = this;
                n.has(e) && n.delete(e), this.squashState()
            }
            squashState() {
                const {
                    elementCount: e
                } = this;
                e || (this.nextZIndex = 2e3), this.nextZIndex - e > 2500 && this.rearrange()
            }
            rearrange() {
                const e = Array.from(this.elementZIndex.entries());
                e.sort(((e, t) => e[1] - t[1])), this.nextZIndex = 2e3, e.forEach((e => {
                    const t = e[0],
                        n = this.nextZIndex++;
                    `${n}` !== t.style.zIndex && (t.style.zIndex = `${n}`)
                }))
            }
        };
        const Av = "@@ziContext";
        var Iv = {
            mounted(e, t) {
                const {
                    value: n = {}
                } = t, {
                    zIndex: o,
                    enabled: r
                } = n;
                e[Av] = {
                    enabled: !!r,
                    initialized: !1
                }, r && (Bv.ensureZIndex(e, o), e[Av].initialized = !0)
            },
            updated(e, t) {
                const {
                    value: n = {}
                } = t, {
                    zIndex: o,
                    enabled: r
                } = n, i = e[Av].enabled;
                r && !i && (Bv.ensureZIndex(e, o), e[Av].initialized = !0), e[Av].enabled = !!r
            },
            unmounted(e, t) {
                if (!e[Av].initialized) return;
                const {
                    value: n = {}
                } = t, {
                    zIndex: o
                } = n;
                Bv.unregister(e, o)
            }
        };
        const Dv = "undefined" != typeof window;
        let Lv, jv;
        var Nv, Hv;
        Lv = Dv ? null === (Hv = null === (Nv = document) || void 0 === Nv ? void 0 : Nv.fonts) || void 0 === Hv ? void 0 : Hv.ready : void 0, jv = !1, void 0 !== Lv ? Lv.then((() => {
            jv = !0
        })) : jv = !0;
        const {
            c: Wv
        } = $u(), Vv = "vueuc-style";
        var qv = Tn({
            name: "LazyTeleport",
            props: {
                to: {
                    type: [String, Object],
                    default: void 0
                },
                disabled: Boolean,
                show: {
                    type: Boolean,
                    required: !0
                }
            },
            setup(e) {
                return {
                    showTeleport: Nh(Dt(e, "show")),
                    mergedTo: zi((() => {
                        const {
                            to: t
                        } = e;
                        return null != t ? t : "body"
                    }))
                }
            },
            render() {
                return this.showTeleport ? this.disabled ? $v("lazy-teleport", this.$slots) : Ti(tr, {
                    disabled: this.disabled,
                    to: this.mergedTo
                }, $v("lazy-teleport", this.$slots)) : null
            }
        });
        const Uv = {
                top: "bottom",
                bottom: "top",
                left: "right",
                right: "left"
            },
            Kv = {
                start: "end",
                center: "center",
                end: "start"
            },
            Gv = {
                top: "height",
                bottom: "height",
                left: "width",
                right: "width"
            },
            Xv = {
                "bottom-start": "top left",
                bottom: "top center",
                "bottom-end": "top right",
                "top-start": "bottom left",
                top: "bottom center",
                "top-end": "bottom right",
                "right-start": "top left",
                right: "center left",
                "right-end": "bottom left",
                "left-start": "top right",
                left: "center right",
                "left-end": "bottom right"
            },
            Yv = {
                "bottom-start": "bottom left",
                bottom: "bottom center",
                "bottom-end": "bottom right",
                "top-start": "top left",
                top: "top center",
                "top-end": "top right",
                "right-start": "top right",
                right: "center right",
                "right-end": "bottom right",
                "left-start": "top left",
                left: "center left",
                "left-end": "bottom left"
            },
            Zv = {
                "bottom-start": "right",
                "bottom-end": "left",
                "top-start": "right",
                "top-end": "left",
                "right-start": "bottom",
                "right-end": "top",
                "left-start": "bottom",
                "left-end": "top"
            },
            Jv = {
                top: !0,
                bottom: !1,
                left: !0,
                right: !1
            },
            Qv = {
                top: "end",
                bottom: "start",
                left: "end",
                right: "start"
            };
        const eg = Wv([Wv(".v-binder-follower-container", {
            position: "absolute",
            left: "0",
            right: "0",
            top: "0",
            height: "0",
            pointerEvents: "none",
            zIndex: "auto"
        }), Wv(".v-binder-follower-content", {
            position: "absolute",
            zIndex: "auto"
        }, [Wv("> *", {
            pointerEvents: "all"
        })])]);
        var tg = Tn({
            name: "Follower",
            inheritAttrs: !1,
            props: {
                show: Boolean,
                enabled: {
                    type: Boolean,
                    default: void 0
                },
                placement: {
                    type: String,
                    default: "bottom"
                },
                syncTrigger: {
                    type: Array,
                    default: ["resize", "scroll"]
                },
                to: [String, Object],
                flip: {
                    type: Boolean,
                    default: !0
                },
                internalShift: Boolean,
                x: Number,
                y: Number,
                width: String,
                minWidth: String,
                containerClass: String,
                teleportDisabled: Boolean,
                zindexable: {
                    type: Boolean,
                    default: !0
                },
                zIndex: Number,
                overlap: Boolean
            },
            setup(e) {
                const t = _o("VBinder"),
                    n = Il((() => void 0 !== e.enabled ? e.enabled : e.show)),
                    o = Ft(null),
                    r = Ft(null),
                    i = () => {
                        const {
                            syncTrigger: n
                        } = e;
                        n.includes("scroll") && t.addScrollListener(s), n.includes("resize") && t.addResizeListener(s)
                    },
                    l = () => {
                        t.removeScrollListener(s), t.removeResizeListener(s)
                    };
                Nn((() => {
                    n.value && (s(), i())
                }));
                const a = ru();
                eg.mount({
                        id: "vueuc/binder",
                        head: !0,
                        anchorMetaName: Vv,
                        ssr: a
                    }), Vn((() => {
                        l()
                    })),
                    function(e) {
                        if (jv) return;
                        let t = !1;
                        Nn((() => {
                            jv || null == Lv || Lv.then((() => {
                                t || e()
                            }))
                        })), Vn((() => {
                            t = !0
                        }))
                    }((() => {
                        n.value && s()
                    }));
                const s = () => {
                    if (!n.value) return;
                    const i = o.value;
                    if (null === i) return;
                    const l = t.targetRef,
                        {
                            x: a,
                            y: s,
                            overlap: c
                        } = e,
                        u = void 0 !== a && void 0 !== s ? function(e, t) {
                            const n = Pv();
                            return {
                                top: t,
                                left: e,
                                height: 0,
                                width: 0,
                                right: n.width - e,
                                bottom: n.height - t
                            }
                        }(a, s) : Fv(l);
                    i.style.setProperty("--v-target-width", `${Math.round(u.width)}px`), i.style.setProperty("--v-target-height", `${Math.round(u.height)}px`);
                    const {
                        width: d,
                        minWidth: f,
                        placement: p,
                        internalShift: h,
                        flip: v
                    } = e;
                    i.setAttribute("v-placement", p), c ? i.setAttribute("v-overlap", "") : i.removeAttribute("v-overlap");
                    const {
                        style: g
                    } = i;
                    g.width = "target" === d ? `${u.width}px` : void 0 !== d ? d : "", g.minWidth = "target" === f ? `${u.width}px` : void 0 !== f ? f : "";
                    const b = Fv(i),
                        m = Fv(r.value),
                        {
                            left: y,
                            top: x,
                            placement: w
                        } = function(e, t, n, o, r, i) {
                            if (!r || i) return {
                                placement: e,
                                top: 0,
                                left: 0
                            };
                            const [l, a] = e.split("-");
                            let s = null != a ? a : "center",
                                c = {
                                    top: 0,
                                    left: 0
                                };
                            const u = (e, r, i) => {
                                    let l = 0,
                                        a = 0;
                                    const s = n[e] - t[r] - t[e];
                                    return s > 0 && o && (i ? a = Jv[r] ? s : -s : l = Jv[r] ? s : -s), {
                                        left: l,
                                        top: a
                                    }
                                },
                                d = "left" === l || "right" === l;
                            if ("center" !== s) {
                                const o = Zv[e],
                                    r = Uv[o],
                                    i = Gv[o];
                                if (n[i] > t[i]) {
                                    if (t[o] + t[i] < n[i]) {
                                        const e = (n[i] - t[i]) / 2;
                                        t[o] < e || t[r] < e ? t[o] < t[r] ? (s = Kv[a], c = u(i, r, d)) : c = u(i, o, d) : s = "center"
                                    }
                                } else n[i] < t[i] && t[r] < 0 && t[o] > t[r] && (s = Kv[a])
                            } else {
                                const e = "bottom" === l || "top" === l ? "left" : "top",
                                    o = Uv[e],
                                    r = Gv[e],
                                    i = (n[r] - t[r]) / 2;
                                (t[e] < i || t[o] < i) && (t[e] > t[o] ? (s = Qv[e], c = u(r, e, d)) : (s = Qv[o], c = u(r, o, d)))
                            }
                            let f = l;
                            return t[l] < n[Gv[l]] && t[l] < t[Uv[l]] && (f = Uv[l]), {
                                placement: "center" !== s ? `${f}-${s}` : f,
                                left: c.left,
                                top: c.top
                            }
                        }(p, u, b, h, v, c),
                        C = function(e, t) {
                            return t ? Yv[e] : Xv[e]
                        }(w, c),
                        {
                            left: S,
                            top: k,
                            transform: $
                        } = function(e, t, n, o, r, i) {
                            if (i) switch (e) {
                                case "bottom-start":
                                case "left-end":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height)}px`, left: `${Math.round(n.left-t.left)}px`, transform: "translateY(-100%)"
                                    };
                                case "bottom-end":
                                case "right-end":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height)}px`, left: `${Math.round(n.left-t.left+n.width)}px`, transform: "translateX(-100%) translateY(-100%)"
                                    };
                                case "top-start":
                                case "left-start":
                                    return {
                                        top: `${Math.round(n.top-t.top)}px`, left: `${Math.round(n.left-t.left)}px`, transform: ""
                                    };
                                case "top-end":
                                case "right-start":
                                    return {
                                        top: `${Math.round(n.top-t.top)}px`, left: `${Math.round(n.left-t.left+n.width)}px`, transform: "translateX(-100%)"
                                    };
                                case "top":
                                    return {
                                        top: `${Math.round(n.top-t.top)}px`, left: `${Math.round(n.left-t.left+n.width/2)}px`, transform: "translateX(-50%)"
                                    };
                                case "right":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height/2)}px`, left: `${Math.round(n.left-t.left+n.width)}px`, transform: "translateX(-100%) translateY(-50%)"
                                    };
                                case "left":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height/2)}px`, left: `${Math.round(n.left-t.left)}px`, transform: "translateY(-50%)"
                                    };
                                default:
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height)}px`, left: `${Math.round(n.left-t.left+n.width/2)}px`, transform: "translateX(-50%) translateY(-100%)"
                                    }
                            }
                            switch (e) {
                                case "bottom-start":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height+o)}px`, left: `${Math.round(n.left-t.left+r)}px`, transform: ""
                                    };
                                case "bottom-end":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height+o)}px`, left: `${Math.round(n.left-t.left+n.width+r)}px`, transform: "translateX(-100%)"
                                    };
                                case "top-start":
                                    return {
                                        top: `${Math.round(n.top-t.top+o)}px`, left: `${Math.round(n.left-t.left+r)}px`, transform: "translateY(-100%)"
                                    };
                                case "top-end":
                                    return {
                                        top: `${Math.round(n.top-t.top+o)}px`, left: `${Math.round(n.left-t.left+n.width+r)}px`, transform: "translateX(-100%) translateY(-100%)"
                                    };
                                case "right-start":
                                    return {
                                        top: `${Math.round(n.top-t.top+o)}px`, left: `${Math.round(n.left-t.left+n.width+r)}px`, transform: ""
                                    };
                                case "right-end":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height+o)}px`, left: `${Math.round(n.left-t.left+n.width+r)}px`, transform: "translateY(-100%)"
                                    };
                                case "left-start":
                                    return {
                                        top: `${Math.round(n.top-t.top+o)}px`, left: `${Math.round(n.left-t.left+r)}px`, transform: "translateX(-100%)"
                                    };
                                case "left-end":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height+o)}px`, left: `${Math.round(n.left-t.left+r)}px`, transform: "translateX(-100%) translateY(-100%)"
                                    };
                                case "top":
                                    return {
                                        top: `${Math.round(n.top-t.top+o)}px`, left: `${Math.round(n.left-t.left+n.width/2+r)}px`, transform: "translateY(-100%) translateX(-50%)"
                                    };
                                case "right":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height/2+o)}px`, left: `${Math.round(n.left-t.left+n.width+r)}px`, transform: "translateY(-50%)"
                                    };
                                case "left":
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height/2+o)}px`, left: `${Math.round(n.left-t.left+r)}px`, transform: "translateY(-50%) translateX(-100%)"
                                    };
                                default:
                                    return {
                                        top: `${Math.round(n.top-t.top+n.height+o)}px`, left: `${Math.round(n.left-t.left+n.width/2+r)}px`, transform: "translateX(-50%)"
                                    }
                            }
                        }(w, m, u, x, y, c);
                    i.setAttribute("v-placement", w), i.style.setProperty("--v-offset-left", `${Math.round(y)}px`), i.style.setProperty("--v-offset-top", `${Math.round(x)}px`), i.style.transform = `translateX(${S}) translateY(${k}) ${$}`, i.style.setProperty("--v-transform-origin", C), i.style.transformOrigin = C
                };
                vr(n, (e => {
                    e ? (i(), c()) : l()
                }));
                const c = () => {
                    Jt().then(s).catch((e => {}))
                };
                ["placement", "x", "y", "internalShift", "flip", "width", "overlap", "minWidth"].forEach((t => {
                    vr(Dt(e, t), s)
                })), ["teleportDisabled"].forEach((t => {
                    vr(Dt(e, t), c)
                })), vr(Dt(e, "syncTrigger"), (e => {
                    e.includes("resize") ? t.addResizeListener(s) : t.removeResizeListener(s), e.includes("scroll") ? t.addScrollListener(s) : t.removeScrollListener(s)
                }));
                const u = Xu(),
                    d = Il((() => {
                        const {
                            to: t
                        } = e;
                        if (void 0 !== t) return t;
                        u.value
                    }));
                return {
                    VBinder: t,
                    mergedEnabled: n,
                    offsetContainerRef: r,
                    followerRef: o,
                    mergedTo: d,
                    syncPosition: s
                }
            },
            render() {
                return Ti(qv, {
                    show: this.show,
                    to: this.mergedTo,
                    disabled: this.teleportDisabled
                }, {
                    default: () => {
                        var e, t;
                        const n = Ti("div", {
                            class: ["v-binder-follower-container", this.containerClass],
                            ref: "offsetContainerRef"
                        }, [Ti("div", {
                            class: "v-binder-follower-content",
                            ref: "followerRef"
                        }, null === (t = (e = this.$slots).default) || void 0 === t ? void 0 : t.call(e))]);
                        return this.zindexable ? fn(n, [
                            [Iv, {
                                enabled: this.mergedEnabled,
                                zIndex: this.zIndex
                            }]
                        ]) : n
                    }
                })
            }
        });

        function ng(e, t) {
            return zi((() => {
                for (const n of t)
                    if (void 0 !== e[n]) return e[n];
                return e[t[t.length - 1]]
            }))
        }
        const og = "@@coContext",
            rg = {
                mounted(e, {
                    value: t,
                    modifiers: n
                }) {
                    e[og] = {
                        handler: void 0
                    }, "function" == typeof t && (e[og].handler = t, sp("clickoutside", e, t, {
                        capture: n.capture
                    }))
                },
                updated(e, {
                    value: t,
                    modifiers: n
                }) {
                    const o = e[og];
                    "function" == typeof t ? o.handler ? o.handler !== t && (cp("clickoutside", e, o.handler, {
                        capture: n.capture
                    }), o.handler = t, sp("clickoutside", e, t, {
                        capture: n.capture
                    })) : (e[og].handler = t, sp("clickoutside", e, t, {
                        capture: n.capture
                    })) : o.handler && (cp("clickoutside", e, o.handler, {
                        capture: n.capture
                    }), o.handler = void 0)
                },
                unmounted(e, {
                    modifiers: t
                }) {
                    const {
                        handler: n
                    } = e[og];
                    n && cp("clickoutside", e, n, {
                        capture: t.capture
                    }), e[og].handler = void 0
                }
            };
        var ig = rg;
        const lg = "n-internal-select-menu",
            ag = "n-internal-select-menu-body",
            sg = "n-modal-body",
            cg = "n-drawer-body",
            ug = "n-popover-body",
            dg = "__disabled__";

        function fg(e) {
            const t = _o(sg, null),
                n = _o(cg, null),
                o = _o(ug, null),
                r = _o(ag, null),
                i = Ft();
            if ("undefined" != typeof document) {
                i.value = document.fullscreenElement;
                const e = () => {
                    i.value = document.fullscreenElement
                };
                Nn((() => {
                    sp("fullscreenchange", document, e)
                })), Vn((() => {
                    cp("fullscreenchange", document, e)
                }))
            }
            return Il((() => {
                var l;
                const {
                    to: a
                } = e;
                return void 0 !== a ? !1 === a ? dg : !0 === a ? i.value || "body" : a : (null == t ? void 0 : t.value) ? null !== (l = t.value.$el) && void 0 !== l ? l : t.value : (null == n ? void 0 : n.value) ? n.value : (null == o ? void 0 : o.value) ? o.value : (null == r ? void 0 : r.value) ? r.value : null != a ? a : i.value || "body"
            }))
        }
        fg.tdkey = dg, fg.propTo = {
            type: [String, Object, Boolean],
            default: void 0
        };
        const pg = new WeakSet;
        const hg = "v-hidden",
            vg = Wv("[v-hidden]", {
                display: "none!important"
            });
        var gg = Tn({
            name: "Overflow",
            props: {
                getCounter: Function,
                getTail: Function,
                updateCounter: Function,
                onUpdateCount: Function,
                onUpdateOverflow: Function
            },
            setup(e, {
                slots: t
            }) {
                const n = Ft(null),
                    o = Ft(null);

                function r(r) {
                    const {
                        value: i
                    } = n, {
                        getCounter: l,
                        getTail: a
                    } = e;
                    let s;
                    if (s = void 0 !== l ? l() : o.value, !i || !s) return;
                    s.hasAttribute(hg) && s.removeAttribute(hg);
                    const {
                        children: c
                    } = i;
                    if (r.showAllItemsBeforeCalculate)
                        for (const e of c) e.hasAttribute(hg) && e.removeAttribute(hg);
                    const u = i.offsetWidth,
                        d = [],
                        f = t.tail ? null == a ? void 0 : a() : null;
                    let p = f ? f.offsetWidth : 0,
                        h = !1;
                    const v = i.children.length - (t.tail ? 1 : 0);
                    for (let t = 0; t < v - 1; ++t) {
                        if (t < 0) continue;
                        const n = c[t];
                        if (h) {
                            n.hasAttribute(hg) || n.setAttribute(hg, "");
                            continue
                        }
                        n.hasAttribute(hg) && n.removeAttribute(hg);
                        const o = n.offsetWidth;
                        if (p += o, d[t] = o, p > u) {
                            const {
                                updateCounter: n
                            } = e;
                            for (let o = t; o >= 0; --o) {
                                const r = v - 1 - o;
                                void 0 !== n ? n(r) : s.textContent = `${r}`;
                                const i = s.offsetWidth;
                                if (p -= d[o], p + i <= u || 0 === o) {
                                    h = !0, t = o - 1, f && (-1 === t ? (f.style.maxWidth = u - i + "px", f.style.boxSizing = "border-box") : f.style.maxWidth = "");
                                    const {
                                        onUpdateCount: n
                                    } = e;
                                    n && n(r);
                                    break
                                }
                            }
                        }
                    }
                    const {
                        onUpdateOverflow: g
                    } = e;
                    h ? void 0 !== g && g(!0) : (void 0 !== g && g(!1), s.setAttribute(hg, ""))
                }
                const i = ru();
                return vg.mount({
                    id: "vueuc/overflow",
                    head: !0,
                    anchorMetaName: Vv,
                    ssr: i
                }), Nn((() => r({
                    showAllItemsBeforeCalculate: !1
                }))), {
                    selfRef: n,
                    counterRef: o,
                    sync: r
                }
            },
            render() {
                const {
                    $slots: e
                } = this;
                return Jt((() => this.sync({
                    showAllItemsBeforeCalculate: !1
                }))), Ti("div", {
                    class: "v-overflow",
                    ref: "selfRef"
                }, [to(e, "default"), e.counter ? e.counter() : Ti("span", {
                    style: {
                        display: "inline-block"
                    },
                    ref: "counterRef"
                }), e.tail ? e.tail() : null])
            }
        });

        function bg(e, t = !0, n = []) {
            return e.forEach((e => {
                if (null !== e)
                    if ("object" == typeof e)
                        if (Array.isArray(e)) bg(e, t, n);
                        else if (e.type === Mr) {
                    if (null === e.children) return;
                    Array.isArray(e.children) && bg(e.children, t, n)
                } else {
                    if (e.type === Er && t) return;
                    n.push(e)
                } else "string" != typeof e && "number" != typeof e || n.push(Qr(String(e)))
            })), n
        }

        function mg(e, t = "default", n = void 0) {
            const o = e[t];
            if (!o) return null;
            const r = bg(o(n));
            return 1 === r.length ? r[0] : null
        }

        function yg(e, t = [], n) {
            const o = {};
            return t.forEach((t => {
                o[t] = e[t]
            })), Object.assign(o, n)
        }

        function xg(e) {
            return e instanceof HTMLElement
        }

        function wg(e) {
            for (let t = 0; t < e.childNodes.length; t++) {
                const n = e.childNodes[t];
                if (xg(n) && (Sg(n) || wg(n))) return !0
            }
            return !1
        }

        function Cg(e) {
            for (let t = e.childNodes.length - 1; t >= 0; t--) {
                const n = e.childNodes[t];
                if (xg(n) && (Sg(n) || Cg(n))) return !0
            }
            return !1
        }

        function Sg(e) {
            if (! function(e) {
                    if (e.tabIndex > 0 || 0 === e.tabIndex && null !== e.getAttribute("tabIndex")) return !0;
                    if (e.getAttribute("disabled")) return !1;
                    switch (e.nodeName) {
                        case "A":
                            return !!e.href && "ignore" !== e.rel;
                        case "INPUT":
                            return "hidden" !== e.type && "file" !== e.type;
                        case "BUTTON":
                        case "SELECT":
                        case "TEXTAREA":
                            return !0;
                        default:
                            return !1
                    }
                }(e)) return !1;
            try {
                e.focus({
                    preventScroll: !0
                })
            } catch (e) {}
            return document.activeElement === e
        }

        function kg(e) {
            return "string" == typeof e ? document.querySelector(e) : e()
        }
        let $g = [];
        const _g = Tn({
                name: "FocusTrap",
                props: {
                    disabled: Boolean,
                    active: Boolean,
                    autoFocus: {
                        type: Boolean,
                        default: !0
                    },
                    onEsc: Function,
                    initialFocusTo: String,
                    finalFocusTo: String,
                    returnFocusOnDeactivated: {
                        type: Boolean,
                        default: !0
                    }
                },
                setup(e) {
                    const t = Ih(),
                        n = Ft(null),
                        o = Ft(null);
                    let r = !1,
                        i = !1;
                    const l = "undefined" == typeof document ? null : document.activeElement;

                    function a() {
                        return $g[$g.length - 1] === t
                    }

                    function s(t) {
                        var n;
                        "Escape" === t.code && a() && (null === (n = e.onEsc) || void 0 === n || n.call(e, t))
                    }

                    function c(e) {
                        if (!i && a()) {
                            const t = u();
                            if (null === t) return;
                            if (t.contains(hp(e))) return;
                            f("first")
                        }
                    }

                    function u() {
                        const e = n.value;
                        if (null === e) return null;
                        let t = e;
                        for (; !(t = t.nextSibling, null === t || t instanceof Element && "DIV" === t.tagName););
                        return t
                    }

                    function d() {
                        var n;
                        if (e.disabled) return;
                        if (document.removeEventListener("focus", c, !0), $g = $g.filter((e => e !== t)), a()) return;
                        const {
                            finalFocusTo: o
                        } = e;
                        void 0 !== o ? null === (n = kg(o)) || void 0 === n || n.focus({
                            preventScroll: !0
                        }) : e.returnFocusOnDeactivated && l instanceof HTMLElement && (i = !0, l.focus({
                            preventScroll: !0
                        }), i = !1)
                    }

                    function f(t) {
                        if (a() && e.active) {
                            const e = n.value,
                                r = o.value;
                            if (null !== e && null !== r) {
                                const n = u();
                                if (null == n || n === r) return i = !0, e.focus({
                                    preventScroll: !0
                                }), void(i = !1);
                                i = !0;
                                const o = "first" === t ? wg(n) : Cg(n);
                                i = !1, o || (i = !0, e.focus({
                                    preventScroll: !0
                                }), i = !1)
                            }
                        }
                    }
                    return Nn((() => {
                        vr((() => e.active), (n => {
                            n ? (! function() {
                                var n;
                                if (e.disabled) return;
                                if ($g.push(t), e.autoFocus) {
                                    const {
                                        initialFocusTo: t
                                    } = e;
                                    void 0 === t ? f("first") : null === (n = kg(t)) || void 0 === n || n.focus({
                                        preventScroll: !0
                                    })
                                }
                                r = !0, document.addEventListener("focus", c, !0)
                            }(), sp("keydown", document, s)) : (cp("keydown", document, s), r && d())
                        }), {
                            immediate: !0
                        })
                    })), Vn((() => {
                        cp("keydown", document, s), r && d()
                    })), {
                        focusableStartRef: n,
                        focusableEndRef: o,
                        focusableStyle: "position: absolute; height: 0; width: 0;",
                        handleStartFocus: function(e) {
                            if (i) return;
                            const t = u();
                            null !== t && (null !== e.relatedTarget && t.contains(e.relatedTarget) ? f("last") : f("first"))
                        },
                        handleEndFocus: function(e) {
                            i || (null !== e.relatedTarget && e.relatedTarget === n.value ? f("last") : f("first"))
                        }
                    }
                },
                render() {
                    const {
                        default: e
                    } = this.$slots;
                    if (void 0 === e) return null;
                    if (this.disabled) return e();
                    const {
                        active: t,
                        focusableStyle: n
                    } = this;
                    return Ti(Mr, null, [Ti("div", {
                        "aria-hidden": "true",
                        tabindex: t ? "0" : "-1",
                        ref: "focusableStartRef",
                        style: n,
                        onFocus: this.handleStartFocus
                    }), e(), Ti("div", {
                        "aria-hidden": "true",
                        style: n,
                        ref: "focusableEndRef",
                        tabindex: t ? "0" : "-1",
                        onFocus: this.handleEndFocus
                    })])
                }
            }),
            zg = "@@mmoContext",
            Tg = {
                mounted(e, {
                    value: t
                }) {
                    e[zg] = {
                        handler: void 0
                    }, "function" == typeof t && (e[zg].handler = t, sp("mousemoveoutside", e, t))
                },
                updated(e, {
                    value: t
                }) {
                    const n = e[zg];
                    "function" == typeof t ? n.handler ? n.handler !== t && (cp("mousemoveoutside", e, n.handler), n.handler = t, sp("mousemoveoutside", e, t)) : (e[zg].handler = t, sp("mousemoveoutside", e, t)) : n.handler && (cp("mousemoveoutside", e, n.handler), n.handler = void 0)
                },
                unmounted(e) {
                    const {
                        handler: t
                    } = e[zg];
                    t && cp("mousemoveoutside", e, t), e[zg].handler = void 0
                }
            };
        var Pg = Tg;
        let Fg;
        const Mg = /^(\d|\.)+$/,
            Rg = /(\d|\.)+/;

        function Eg(e, {
            c: t = 1,
            offset: n = 0,
            attachPx: o = !0
        } = {}) {
            if ("number" == typeof e) {
                const o = (e + n) * t;
                return 0 === o ? "0" : `${o}px`
            }
            if ("string" == typeof e) {
                if (Mg.test(e)) {
                    const r = (Number(e) + n) * t;
                    return o ? 0 === r ? "0" : `${r}px` : `${r}`
                } {
                    const o = Rg.exec(e);
                    return o ? e.replace(Rg, String((Number(o[0]) + n) * t)) : e
                }
            }
            return e
        }
        var Og = {
            space: "6px",
            spaceArrow: "10px",
            arrowOffset: "10px",
            arrowOffsetVertical: "10px",
            arrowHeight: "6px",
            padding: "8px 14px"
        };
        const Bg = {
            name: "Popover",
            common: of,
            self: function(e) {
                const {
                    boxShadow2: t,
                    popoverColor: n,
                    textColor2: o,
                    borderRadius: r,
                    fontSize: i,
                    dividerColor: l
                } = e;
                return Object.assign(Object.assign({}, Og), {
                    fontSize: i,
                    borderRadius: r,
                    color: n,
                    dividerColor: l,
                    textColor: o,
                    boxShadow: t
                })
            }
        };
        var Ag = Bg;
        var Ig = function(e) {
            return this.__data__.set(e, "__lodash_hash_undefined__"), this
        };
        var Dg = function(e) {
            return this.__data__.has(e)
        };

        function Lg(e) {
            var t = -1,
                n = null == e ? 0 : e.length;
            for (this.__data__ = new Ua; ++t < n;) this.add(e[t])
        }
        Lg.prototype.add = Lg.prototype.push = Ig, Lg.prototype.has = Dg;
        var jg = Lg;
        var Ng = function(e, t) {
            for (var n = -1, o = null == e ? 0 : e.length; ++n < o;)
                if (t(e[n], n, e)) return !0;
            return !1
        };
        var Hg = function(e, t) {
            return e.has(t)
        };
        var Wg = function(e, t, n, o, r, i) {
            var l = 1 & n,
                a = e.length,
                s = t.length;
            if (a != s && !(l && s > a)) return !1;
            var c = i.get(e),
                u = i.get(t);
            if (c && u) return c == t && u == e;
            var d = -1,
                f = !0,
                p = 2 & n ? new jg : void 0;
            for (i.set(e, t), i.set(t, e); ++d < a;) {
                var h = e[d],
                    v = t[d];
                if (o) var g = l ? o(v, h, d, t, e, i) : o(h, v, d, e, t, i);
                if (void 0 !== g) {
                    if (g) continue;
                    f = !1;
                    break
                }
                if (p) {
                    if (!Ng(t, (function(e, t) {
                            if (!Hg(p, t) && (h === e || r(h, e, n, o, i))) return p.push(t)
                        }))) {
                        f = !1;
                        break
                    }
                } else if (h !== v && !r(h, v, n, o, i)) {
                    f = !1;
                    break
                }
            }
            return i.delete(e), i.delete(t), f
        };
        var Vg = function(e) {
            var t = -1,
                n = Array(e.size);
            return e.forEach((function(e, o) {
                n[++t] = [o, e]
            })), n
        };
        var qg = function(e) {
                var t = -1,
                    n = Array(e.size);
                return e.forEach((function(e) {
                    n[++t] = e
                })), n
            },
            Ug = ta ? ta.prototype : void 0,
            Kg = Ug ? Ug.valueOf : void 0;
        var Gg = function(e, t, n, o, r, i, l) {
            switch (n) {
                case "[object DataView]":
                    if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
                    e = e.buffer, t = t.buffer;
                case "[object ArrayBuffer]":
                    return !(e.byteLength != t.byteLength || !i(new ls(e), new ls(t)));
                case "[object Boolean]":
                case "[object Date]":
                case "[object Number]":
                    return Ll(+e, +t);
                case "[object Error]":
                    return e.name == t.name && e.message == t.message;
                case "[object RegExp]":
                case "[object String]":
                    return e == t + "";
                case "[object Map]":
                    var a = Vg;
                case "[object Set]":
                    var s = 1 & o;
                    if (a || (a = qg), e.size != t.size && !s) return !1;
                    var c = l.get(e);
                    if (c) return c == t;
                    o |= 2, l.set(e, t);
                    var u = Wg(a(e), a(t), o, r, i, l);
                    return l.delete(e), u;
                case "[object Symbol]":
                    if (Kg) return Kg.call(e) == Kg.call(t)
            }
            return !1
        };
        var Xg = function(e, t) {
            for (var n = -1, o = t.length, r = e.length; ++n < o;) e[r + n] = t[n];
            return e
        };
        var Yg = function(e, t, n) {
            var o = t(e);
            return ks(e) ? o : Xg(o, n(e))
        };
        var Zg = function(e, t) {
            for (var n = -1, o = null == e ? 0 : e.length, r = 0, i = []; ++n < o;) {
                var l = e[n];
                t(l, n, e) && (i[r++] = l)
            }
            return i
        };
        var Jg = function() {
                return []
            },
            Qg = Object.prototype.propertyIsEnumerable,
            eb = Object.getOwnPropertySymbols,
            tb = eb ? function(e) {
                return null == e ? [] : (e = Object(e), Zg(eb(e), (function(t) {
                    return Qg.call(e, t)
                })))
            } : Jg,
            nb = fs(Object.keys, Object),
            ob = Object.prototype.hasOwnProperty;
        var rb = function(e) {
            if (!vs(e)) return nb(e);
            var t = [];
            for (var n in Object(e)) ob.call(e, n) && "constructor" != n && t.push(n);
            return t
        };
        var ib = function(e) {
            return _s(e) ? nc(e) : rb(e)
        };
        var lb = function(e) {
                return Yg(e, ib, tb)
            },
            ab = Object.prototype.hasOwnProperty;
        var sb = function(e, t, n, o, r, i) {
                var l = 1 & n,
                    a = lb(e),
                    s = a.length;
                if (s != lb(t).length && !l) return !1;
                for (var c = s; c--;) {
                    var u = a[c];
                    if (!(l ? u in t : ab.call(t, u))) return !1
                }
                var d = i.get(e),
                    f = i.get(t);
                if (d && f) return d == t && f == e;
                var p = !0;
                i.set(e, t), i.set(t, e);
                for (var h = l; ++c < s;) {
                    var v = e[u = a[c]],
                        g = t[u];
                    if (o) var b = l ? o(g, v, u, t, e, i) : o(v, g, u, e, t, i);
                    if (!(void 0 === b ? v === g || r(v, g, n, o, i) : b)) {
                        p = !1;
                        break
                    }
                    h || (h = "constructor" == u)
                }
                if (p && !h) {
                    var m = e.constructor,
                        y = t.constructor;
                    m == y || !("constructor" in e) || !("constructor" in t) || "function" == typeof m && m instanceof m && "function" == typeof y && y instanceof y || (p = !1)
                }
                return i.delete(e), i.delete(t), p
            },
            cb = _a(ea, "DataView"),
            ub = _a(ea, "Promise"),
            db = _a(ea, "Set"),
            fb = _a(ea, "WeakMap"),
            pb = "[object Map]",
            hb = "[object Promise]",
            vb = "[object Set]",
            gb = "[object WeakMap]",
            bb = "[object DataView]",
            mb = ba(cb),
            yb = ba(za),
            xb = ba(ub),
            wb = ba(db),
            Cb = ba(fb),
            Sb = ua;
        (cb && Sb(new cb(new ArrayBuffer(1))) != bb || za && Sb(new za) != pb || ub && Sb(ub.resolve()) != hb || db && Sb(new db) != vb || fb && Sb(new fb) != gb) && (Sb = function(e) {
            var t = ua(e),
                n = "[object Object]" == t ? e.constructor : void 0,
                o = n ? ba(n) : "";
            if (o) switch (o) {
                case mb:
                    return bb;
                case yb:
                    return pb;
                case xb:
                    return hb;
                case wb:
                    return vb;
                case Cb:
                    return gb
            }
            return t
        });
        var kb = Sb,
            $b = "[object Arguments]",
            _b = "[object Array]",
            zb = "[object Object]",
            Tb = Object.prototype.hasOwnProperty;
        var Pb = function(e, t, n, o, r, i) {
            var l = ks(e),
                a = ks(t),
                s = l ? _b : kb(e),
                c = a ? _b : kb(t),
                u = (s = s == $b ? zb : s) == zb,
                d = (c = c == $b ? zb : c) == zb,
                f = s == c;
            if (f && Rs(e)) {
                if (!Rs(t)) return !1;
                l = !0, u = !1
            }
            if (f && !u) return i || (i = new Xa), l || Ks(e) ? Wg(e, t, n, o, r, i) : Gg(e, t, s, n, o, r, i);
            if (!(1 & n)) {
                var p = u && Tb.call(e, "__wrapped__"),
                    h = d && Tb.call(t, "__wrapped__");
                if (p || h) {
                    var v = p ? e.value() : e,
                        g = h ? t.value() : t;
                    return i || (i = new Xa), r(v, g, n, o, i)
                }
            }
            return !!f && (i || (i = new Xa), sb(e, t, n, o, r, i))
        };
        var Fb = function e(t, n, o, r, i) {
            return t === n || (null == t || null == n || !bs(t) && !bs(n) ? t != t && n != n : Pb(t, n, o, r, e, i))
        };
        var Mb = function(e, t, n, o) {
            var r = n.length,
                i = r,
                l = !o;
            if (null == e) return !i;
            for (e = Object(e); r--;) {
                var a = n[r];
                if (l && a[2] ? a[1] !== e[a[0]] : !(a[0] in e)) return !1
            }
            for (; ++r < i;) {
                var s = (a = n[r])[0],
                    c = e[s],
                    u = a[1];
                if (l && a[2]) {
                    if (void 0 === c && !(s in e)) return !1
                } else {
                    var d = new Xa;
                    if (o) var f = o(c, u, s, e, t, d);
                    if (!(void 0 === f ? Fb(u, c, 3, o, d) : f)) return !1
                }
            }
            return !0
        };
        var Rb = function(e) {
            return e == e && !da(e)
        };
        var Eb = function(e) {
            for (var t = ib(e), n = t.length; n--;) {
                var o = t[n],
                    r = e[o];
                t[n] = [o, r, Rb(r)]
            }
            return t
        };
        var Ob = function(e, t) {
            return function(n) {
                return null != n && (n[e] === t && (void 0 !== t || e in Object(n)))
            }
        };
        var Bb = function(e) {
                var t = Eb(e);
                return 1 == t.length && t[0][2] ? Ob(t[0][0], t[0][1]) : function(n) {
                    return n === e || Mb(n, e, t)
                }
            },
            Ab = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
            Ib = /^\w*$/;
        var Db = function(e, t) {
            if (ks(e)) return !1;
            var n = typeof e;
            return !("number" != n && "symbol" != n && "boolean" != n && null != e && !Vp(e)) || (Ib.test(e) || !Ab.test(e) || null != t && e in Object(t))
        };

        function Lb(e, t) {
            if ("function" != typeof e || null != t && "function" != typeof t) throw new TypeError("Expected a function");
            var n = function() {
                var o = arguments,
                    r = t ? t.apply(this, o) : o[0],
                    i = n.cache;
                if (i.has(r)) return i.get(r);
                var l = e.apply(this, o);
                return n.cache = i.set(r, l) || i, l
            };
            return n.cache = new(Lb.Cache || Ua), n
        }
        Lb.Cache = Ua;
        var jb = Lb;
        var Nb = function(e) {
                var t = jb(e, (function(e) {
                        return 500 === n.size && n.clear(), e
                    })),
                    n = t.cache;
                return t
            },
            Hb = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            Wb = /\\(\\)?/g,
            Vb = Nb((function(e) {
                var t = [];
                return 46 === e.charCodeAt(0) && t.push(""), e.replace(Hb, (function(e, n, o, r) {
                    t.push(o ? r.replace(Wb, "$1") : n || e)
                })), t
            })),
            qb = Vb;
        var Ub = function(e, t) {
            return ks(e) ? e : Db(e, t) ? [e] : qb(Gp(e))
        };
        var Kb = function(e) {
            if ("string" == typeof e || Vp(e)) return e;
            var t = e + "";
            return "0" == t && 1 / e == -1 / 0 ? "-0" : t
        };
        var Gb = function(e, t) {
            for (var n = 0, o = (t = Ub(t, e)).length; null != e && n < o;) e = e[Kb(t[n++])];
            return n && n == o ? e : void 0
        };
        var Xb = function(e, t, n) {
            var o = null == e ? void 0 : Gb(e, t);
            return void 0 === o ? n : o
        };
        var Yb = function(e, t) {
            return null != e && t in Object(e)
        };
        var Zb = function(e, t, n) {
            for (var o = -1, r = (t = Ub(t, e)).length, i = !1; ++o < r;) {
                var l = Kb(t[o]);
                if (!(i = null != e && n(e, l))) break;
                e = e[l]
            }
            return i || ++o != r ? i : !!(r = null == e ? 0 : e.length) && $s(r) && ec(l, r) && (ks(e) || Ss(e))
        };
        var Jb = function(e, t) {
            return null != e && Zb(e, t, Yb)
        };
        var Qb = function(e, t) {
            return Db(e) && Rb(t) ? Ob(Kb(e), t) : function(n) {
                var o = Xb(n, e);
                return void 0 === o && o === t ? Jb(n, e) : Fb(t, o, 3)
            }
        };
        var em = function(e) {
            return function(t) {
                return null == t ? void 0 : t[e]
            }
        };
        var tm = function(e) {
            return function(t) {
                return Gb(t, e)
            }
        };
        var nm = function(e) {
            return Db(e) ? em(Kb(e)) : tm(e)
        };
        var om = function(e) {
            return "function" == typeof e ? e : null == e ? uc : "object" == typeof e ? ks(e) ? Qb(e[0], e[1]) : Bb(e) : nm(e)
        };
        var rm = function(e, t) {
                return function(n, o) {
                    if (null == n) return n;
                    if (!_s(n)) return e(n, o);
                    for (var r = n.length, i = t ? r : -1, l = Object(n);
                        (t ? i-- : ++i < r) && !1 !== o(l[i], i, l););
                    return n
                }
            },
            im = rm((function(e, t) {
                return e && es(e, t, ib)
            }));
        var lm = function(e, t) {
            var n = -1,
                o = _s(e) ? Array(e.length) : [];
            return im(e, (function(e, r, i) {
                o[++n] = t(e, r, i)
            })), o
        };
        var am = function(e, t) {
            return (ks(e) ? Wp : lm)(e, om(t, 3))
        };
        const sm = {
                top: "bottom",
                bottom: "top",
                left: "right",
                right: "left"
            },
            cm = "var(--n-arrow-height) * 1.414";
        var um = Fu([Ru("popover", "\n transition:\n box-shadow .3s var(--n-bezier),\n background-color .3s var(--n-bezier),\n color .3s var(--n-bezier);\n position: relative;\n font-size: var(--n-font-size);\n color: var(--n-text-color);\n box-shadow: var(--n-box-shadow);\n word-break: break-word;\n ", [Fu(">", [Ru("scrollbar", "\n height: inherit;\n max-height: inherit;\n ")]), Bu("raw", "\n background-color: var(--n-color);\n border-radius: var(--n-border-radius);\n ", [Bu("scrollable", [Bu("show-header-or-footer", "padding: var(--n-padding);")])]), Eu("header", "\n padding: var(--n-padding);\n border-bottom: 1px solid var(--n-divider-color);\n transition: border-color .3s var(--n-bezier);\n "), Eu("footer", "\n padding: var(--n-padding);\n border-top: 1px solid var(--n-divider-color);\n transition: border-color .3s var(--n-bezier);\n "), Ou("scrollable, show-header-or-footer", [Eu("content", "\n padding: var(--n-padding);\n ")])]), Ru("popover-shared", "\n transform-origin: inherit;\n ", [Ru("popover-arrow-wrapper", "\n position: absolute;\n overflow: hidden;\n pointer-events: none;\n ", [Ru("popover-arrow", `\n transition: background-color .3s var(--n-bezier);\n position: absolute;\n display: block;\n width: calc(${cm});\n height: calc(${cm});\n box-shadow: 0 0 8px 0 rgba(0, 0, 0, .12);\n transform: rotate(45deg);\n background-color: var(--n-color);\n pointer-events: all;\n `)]), Fu("&.popover-transition-enter-from, &.popover-transition-leave-to", "\n opacity: 0;\n transform: scale(.85);\n "), Fu("&.popover-transition-enter-to, &.popover-transition-leave-from", "\n transform: scale(1);\n opacity: 1;\n "), Fu("&.popover-transition-enter-active", "\n transition:\n box-shadow .3s var(--n-bezier),\n background-color .3s var(--n-bezier),\n color .3s var(--n-bezier),\n opacity .15s var(--n-bezier-ease-out),\n transform .15s var(--n-bezier-ease-out);\n "), Fu("&.popover-transition-leave-active", "\n transition:\n box-shadow .3s var(--n-bezier),\n background-color .3s var(--n-bezier),\n color .3s var(--n-bezier),\n opacity .15s var(--n-bezier-ease-in),\n transform .15s var(--n-bezier-ease-in);\n ")]), fm("top-start", `\n top: calc(${cm} / -2);\n left: calc(${dm("top-start")} - var(--v-offset-left));\n `), fm("top", `\n top: calc(${cm} / -2);\n transform: translateX(calc(${cm} / -2)) rotate(45deg);\n left: 50%;\n `), fm("top-end", `\n top: calc(${cm} / -2);\n right: calc(${dm("top-end")} + var(--v-offset-left));\n `), fm("bottom-start", `\n bottom: calc(${cm} / -2);\n left: calc(${dm("bottom-start")} - var(--v-offset-left));\n `), fm("bottom", `\n bottom: calc(${cm} / -2);\n transform: translateX(calc(${cm} / -2)) rotate(45deg);\n left: 50%;\n `), fm("bottom-end", `\n bottom: calc(${cm} / -2);\n right: calc(${dm("bottom-end")} + var(--v-offset-left));\n `), fm("left-start", `\n left: calc(${cm} / -2);\n top: calc(${dm("left-start")} - var(--v-offset-top));\n `), fm("left", `\n left: calc(${cm} / -2);\n transform: translateY(calc(${cm} / -2)) rotate(45deg);\n top: 50%;\n `), fm("left-end", `\n left: calc(${cm} / -2);\n bottom: calc(${dm("left-end")} + var(--v-offset-top));\n `), fm("right-start", `\n right: calc(${cm} / -2);\n top: calc(${dm("right-start")} - var(--v-offset-top));\n `), fm("right", `\n right: calc(${cm} / -2);\n transform: translateY(calc(${cm} / -2)) rotate(45deg);\n top: 50%;\n `), fm("right-end", `\n right: calc(${cm} / -2);\n bottom: calc(${dm("right-end")} + var(--v-offset-top));\n `), ...am({
            top: ["right-start", "left-start"],
            right: ["top-end", "bottom-end"],
            bottom: ["right-end", "left-end"],
            left: ["top-start", "bottom-start"]
        }, ((e, t) => {
            const n = ["right", "left"].includes(t),
                o = n ? "width" : "height";
            return e.map((e => {
                const r = "end" === e.split("-")[1],
                    i = `calc((${`var(--v-target-${o}, 0px)`} - ${cm}) / 2)`,
                    l = dm(e);
                return Fu(`[v-placement="${e}"] >`, [Ru("popover-shared", [Ou("center-arrow", [Ru("popover-arrow", `${t}: calc(max(${i}, ${l}) ${r?"+":"-"} var(--v-offset-${n?"left":"top"}));`)])])])
            }))
        }))]);

        function dm(e) {
            return ["top", "bottom"].includes(e.split("-")[0]) ? "var(--n-arrow-offset)" : "var(--n-arrow-offset-vertical)"
        }

        function fm(e, t) {
            const n = e.split("-")[0],
                o = ["top", "bottom"].includes(n) ? "height: var(--n-space-arrow);" : "width: var(--n-space-arrow);";
            return Fu(`[v-placement="${e}"] >`, [Ru("popover-shared", `\n margin-${sm[n]}: var(--n-space);\n `, [Ou("show-arrow", `\n margin-${sm[n]}: var(--n-space-arrow);\n `), Ou("overlap", "\n margin: 0;\n "), Au("popover-arrow-wrapper", `\n right: 0;\n left: 0;\n top: 0;\n bottom: 0;\n ${n}: 100%;\n ${sm[n]}: auto;\n ${o}\n `, [Ru("popover-arrow", t)])])])
        }
        const pm = Object.assign(Object.assign({}, Vu.props), {
            to: fg.propTo,
            show: Boolean,
            trigger: String,
            showArrow: Boolean,
            delay: Number,
            duration: Number,
            raw: Boolean,
            arrowPointToCenter: Boolean,
            arrowClass: String,
            arrowStyle: [String, Object],
            arrowWrapperClass: String,
            arrowWrapperStyle: [String, Object],
            displayDirective: String,
            x: Number,
            y: Number,
            flip: Boolean,
            overlap: Boolean,
            placement: String,
            width: [Number, String],
            keepAliveOnHover: Boolean,
            scrollable: Boolean,
            contentClass: String,
            contentStyle: [Object, String],
            headerClass: String,
            headerStyle: [Object, String],
            footerClass: String,
            footerStyle: [Object, String],
            internalDeactivateImmediately: Boolean,
            animated: Boolean,
            onClickoutside: Function,
            internalTrapFocus: Boolean,
            internalOnAfterLeave: Function,
            minWidth: Number,
            maxWidth: Number
        });
        var hm = Tn({
            name: "PopoverBody",
            inheritAttrs: !1,
            props: pm,
            setup(e, {
                slots: t,
                attrs: n
            }) {
                const {
                    namespaceRef: o,
                    mergedClsPrefixRef: r,
                    inlineThemeDisabled: i
                } = zc(e), l = Vu("Popover", "-popover", um, Ag, e, r), a = Ft(null), s = _o("NPopover"), c = Ft(null), u = Ft(e.show), d = Ft(!1);
                pr((() => {
                    const {
                        show: t
                    } = e;
                    !t || (void 0 === Fg && (Fg = navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom")), Fg) || e.internalDeactivateImmediately || (d.value = !0)
                }));
                const f = zi((() => {
                        const {
                            trigger: t,
                            onClickoutside: n
                        } = e, o = [], {
                            positionManuallyRef: {
                                value: r
                            }
                        } = s;
                        return r || ("click" !== t || n || o.push([ig, y, void 0, {
                            capture: !0
                        }]), "hover" === t && o.push([Pg, m])), n && o.push([ig, y, void 0, {
                            capture: !0
                        }]), ("show" === e.displayDirective || e.animated && d.value) && o.push([el, e.show]), o
                    })),
                    p = zi((() => {
                        const {
                            common: {
                                cubicBezierEaseInOut: e,
                                cubicBezierEaseIn: t,
                                cubicBezierEaseOut: n
                            },
                            self: {
                                space: o,
                                spaceArrow: r,
                                padding: i,
                                fontSize: a,
                                textColor: s,
                                dividerColor: c,
                                color: u,
                                boxShadow: d,
                                borderRadius: f,
                                arrowHeight: p,
                                arrowOffset: h,
                                arrowOffsetVertical: v
                            }
                        } = l.value;
                        return {
                            "--n-box-shadow": d,
                            "--n-bezier": e,
                            "--n-bezier-ease-in": t,
                            "--n-bezier-ease-out": n,
                            "--n-font-size": a,
                            "--n-text-color": s,
                            "--n-color": u,
                            "--n-divider-color": c,
                            "--n-border-radius": f,
                            "--n-arrow-height": p,
                            "--n-arrow-offset": h,
                            "--n-arrow-offset-vertical": v,
                            "--n-padding": i,
                            "--n-space": o,
                            "--n-space-arrow": r
                        }
                    })),
                    h = zi((() => {
                        const t = "trigger" === e.width ? void 0 : Eg(e.width),
                            n = [];
                        t && n.push({
                            width: t
                        });
                        const {
                            maxWidth: o,
                            minWidth: r
                        } = e;
                        return o && n.push({
                            maxWidth: Eg(o)
                        }), r && n.push({
                            maxWidth: Eg(r)
                        }), i || n.push(p.value), n
                    })),
                    v = i ? Ku("popover", void 0, p, e) : void 0;

                function g(t) {
                    "hover" === e.trigger && e.keepAliveOnHover && e.show && s.handleMouseEnter(t)
                }

                function b(t) {
                    "hover" === e.trigger && e.keepAliveOnHover && s.handleMouseLeave(t)
                }

                function m(t) {
                    "hover" !== e.trigger || x().contains(hp(t)) || s.handleMouseMoveOutside(t)
                }

                function y(t) {
                    ("click" === e.trigger && !x().contains(hp(t)) || e.onClickoutside) && s.handleClickOutside(t)
                }

                function x() {
                    return s.getTriggerElement()
                }
                return s.setBodyInstance({
                    syncPosition: function() {
                        var e;
                        null === (e = a.value) || void 0 === e || e.syncPosition()
                    }
                }), Vn((() => {
                    s.setBodyInstance(null)
                })), vr(Dt(e, "show"), (t => {
                    e.animated || (u.value = !!t)
                })), $o(ug, c), $o(cg, null), $o(sg, null), {
                    displayed: d,
                    namespace: o,
                    isMounted: s.isMountedRef,
                    zIndex: s.zIndexRef,
                    followerRef: a,
                    adjustedTo: fg(e),
                    followerEnabled: u,
                    renderContentNode: function() {
                        if (null == v || v.onRender(), !("show" === e.displayDirective || e.show || e.animated && d.value)) return null;
                        let o;
                        const i = s.internalRenderBodyRef.value,
                            {
                                value: l
                            } = r;
                        if (i) o = i([`${l}-popover-shared`, null == v ? void 0 : v.themeClass.value, e.overlap && `${l}-popover-shared--overlap`, e.showArrow && `${l}-popover-shared--show-arrow`, e.arrowPointToCenter && `${l}-popover-shared--center-arrow`], c, h.value, g, b);
                        else {
                            const {
                                value: r
                            } = s.extraClassRef, {
                                internalTrapFocus: i
                            } = e, a = !fd(t.header) || !fd(t.footer), u = () => {
                                var n, o;
                                const r = a ? Ti(Mr, null, dd(t.header, (t => t ? Ti("div", {
                                    class: [`${l}-popover__header`, e.headerClass],
                                    style: e.headerStyle
                                }, t) : null)), dd(t.default, (n => n ? Ti("div", {
                                    class: [`${l}-popover__content`, e.contentClass],
                                    style: e.contentStyle
                                }, t) : null)), dd(t.footer, (t => t ? Ti("div", {
                                    class: [`${l}-popover__footer`, e.footerClass],
                                    style: e.footerStyle
                                }, t) : null))) : e.scrollable ? null === (n = t.default) || void 0 === n ? void 0 : n.call(t) : Ti("div", {
                                    class: [`${l}-popover__content`, e.contentClass],
                                    style: e.contentStyle
                                }, t);
                                return [e.scrollable ? Ti(Sp, {
                                    contentClass: a ? void 0 : `${l}-popover__content ${null!==(o=e.contentClass)&&void 0!==o?o:""}`,
                                    contentStyle: a ? void 0 : e.contentStyle
                                }, {
                                    default: () => r
                                }) : r, e.showArrow ? function({
                                    arrowClass: e,
                                    arrowStyle: t,
                                    arrowWrapperClass: n,
                                    arrowWrapperStyle: o,
                                    clsPrefix: r
                                }) {
                                    return Ti("div", {
                                        key: "__popover-arrow__",
                                        style: o,
                                        class: [`${r}-popover-arrow-wrapper`, n]
                                    }, Ti("div", {
                                        class: [`${r}-popover-arrow`, e],
                                        style: t
                                    }))
                                }({
                                    arrowClass: e.arrowClass,
                                    arrowStyle: e.arrowStyle,
                                    arrowWrapperClass: e.arrowWrapperClass,
                                    arrowWrapperStyle: e.arrowWrapperStyle,
                                    clsPrefix: l
                                }) : null]
                            };
                            o = Ti("div", ri({
                                class: [`${l}-popover`, `${l}-popover-shared`, null == v ? void 0 : v.themeClass.value, r.map((e => `${l}-${e}`)), {
                                    [`${l}-popover--scrollable`]: e.scrollable,
                                    [`${l}-popover--show-header-or-footer`]: a,
                                    [`${l}-popover--raw`]: e.raw,
                                    [`${l}-popover-shared--overlap`]: e.overlap,
                                    [`${l}-popover-shared--show-arrow`]: e.showArrow,
                                    [`${l}-popover-shared--center-arrow`]: e.arrowPointToCenter
                                }],
                                ref: c,
                                style: h.value,
                                onKeydown: s.handleKeydown,
                                onMouseenter: g,
                                onMouseleave: b
                            }, n), i ? Ti(_g, {
                                active: e.show,
                                autoFocus: !0
                            }, {
                                default: u
                            }) : u())
                        }
                        return fn(o, f.value)
                    }
                }
            },
            render() {
                return Ti(tg, {
                    ref: "followerRef",
                    zIndex: this.zIndex,
                    show: this.show,
                    enabled: this.followerEnabled,
                    to: this.adjustedTo,
                    x: this.x,
                    y: this.y,
                    flip: this.flip,
                    placement: this.placement,
                    containerClass: this.namespace,
                    overlap: this.overlap,
                    width: "trigger" === this.width ? "target" : void 0,
                    teleportDisabled: this.adjustedTo === fg.tdkey
                }, {
                    default: () => this.animated ? Ti(Ai, {
                        name: "popover-transition",
                        appear: this.isMounted,
                        onEnter: () => {
                            this.followerEnabled = !0
                        },
                        onAfterLeave: () => {
                            var e;
                            null === (e = this.internalOnAfterLeave) || void 0 === e || e.call(this), this.followerEnabled = !1, this.displayed = !1
                        }
                    }, {
                        default: this.renderContentNode
                    }) : this.renderContentNode()
                })
            }
        });
        const vm = Object.keys(pm),
            gm = {
                focus: ["onFocus", "onBlur"],
                click: ["onClick"],
                hover: ["onMouseenter", "onMouseleave"],
                manual: [],
                nested: ["onFocus", "onBlur", "onMouseenter", "onMouseleave", "onClick"]
            };
        const bm = {
            show: {
                type: Boolean,
                default: void 0
            },
            defaultShow: Boolean,
            showArrow: {
                type: Boolean,
                default: !0
            },
            trigger: {
                type: String,
                default: "hover"
            },
            delay: {
                type: Number,
                default: 100
            },
            duration: {
                type: Number,
                default: 100
            },
            raw: Boolean,
            placement: {
                type: String,
                default: "top"
            },
            x: Number,
            y: Number,
            arrowPointToCenter: Boolean,
            disabled: Boolean,
            getDisabled: Function,
            displayDirective: {
                type: String,
                default: "if"
            },
            arrowClass: String,
            arrowStyle: [String, Object],
            arrowWrapperClass: String,
            arrowWrapperStyle: [String, Object],
            flip: {
                type: Boolean,
                default: !0
            },
            animated: {
                type: Boolean,
                default: !0
            },
            width: {
                type: [Number, String],
                default: void 0
            },
            overlap: Boolean,
            keepAliveOnHover: {
                type: Boolean,
                default: !0
            },
            zIndex: Number,
            to: fg.propTo,
            scrollable: Boolean,
            contentClass: String,
            contentStyle: [Object, String],
            headerClass: String,
            headerStyle: [Object, String],
            footerClass: String,
            footerStyle: [Object, String],
            onClickoutside: Function,
            "onUpdate:show": [Function, Array],
            onUpdateShow: [Function, Array],
            internalDeactivateImmediately: Boolean,
            internalSyncTargetWithParent: Boolean,
            internalInheritedEventHandlers: {
                type: Array,
                default: () => []
            },
            internalTrapFocus: Boolean,
            internalExtraClass: {
                type: Array,
                default: () => []
            },
            onShow: [Function, Array],
            onHide: [Function, Array],
            arrow: {
                type: Boolean,
                default: void 0
            },
            minWidth: Number,
            maxWidth: Number
        };
        var mm = Tn({
                name: "Popover",
                inheritAttrs: !1,
                props: Object.assign(Object.assign(Object.assign({}, Vu.props), bm), {
                    internalOnAfterLeave: Function,
                    internalRenderBody: Function
                }),
                __popover__: !0,
                setup(e) {
                    const t = Xu(),
                        n = Ft(null),
                        o = zi((() => e.show)),
                        r = Ft(e.defaultShow),
                        i = df(o, r),
                        l = Il((() => !e.disabled && i.value)),
                        a = () => {
                            if (e.disabled) return !0;
                            const {
                                getDisabled: t
                            } = e;
                            return !!(null == t ? void 0 : t())
                        },
                        s = () => !a() && i.value,
                        c = ng(e, ["arrow", "showArrow"]),
                        u = zi((() => !e.overlap && c.value));
                    let d = null;
                    const f = Ft(null),
                        p = Ft(null),
                        h = Il((() => void 0 !== e.x && void 0 !== e.y));

                    function v(t) {
                        const {
                            "onUpdate:show": n,
                            onUpdateShow: o,
                            onShow: i,
                            onHide: l
                        } = e;
                        r.value = t, n && ld(n, t), o && ld(o, t), t && i && ld(i, !0), t && l && ld(l, !1)
                    }

                    function g() {
                        const {
                            value: e
                        } = f;
                        e && (window.clearTimeout(e), f.value = null)
                    }

                    function b() {
                        const {
                            value: e
                        } = p;
                        e && (window.clearTimeout(e), p.value = null)
                    }

                    function m() {
                        const t = a();
                        if ("hover" === e.trigger && !t) {
                            if (b(), null !== f.value) return;
                            if (s()) return;
                            const t = () => {
                                    v(!0), f.value = null
                                },
                                {
                                    delay: n
                                } = e;
                            0 === n ? t() : f.value = window.setTimeout(t, n)
                        }
                    }

                    function y() {
                        const t = a();
                        if ("hover" === e.trigger && !t) {
                            if (g(), null !== p.value) return;
                            if (!s()) return;
                            const t = () => {
                                    v(!1), p.value = null
                                },
                                {
                                    duration: n
                                } = e;
                            0 === n ? t() : p.value = window.setTimeout(t, n)
                        }
                    }
                    $o("NPopover", {
                        getTriggerElement: function() {
                            var e;
                            return null === (e = n.value) || void 0 === e ? void 0 : e.targetRef
                        },
                        handleKeydown: function(t) {
                            e.internalTrapFocus && "Escape" === t.key && (g(), b(), v(!1))
                        },
                        handleMouseEnter: m,
                        handleMouseLeave: y,
                        handleClickOutside: function(t) {
                            var n;
                            s() && ("click" === e.trigger && (g(), b(), v(!1)), null === (n = e.onClickoutside) || void 0 === n || n.call(e, t))
                        },
                        handleMouseMoveOutside: function() {
                            y()
                        },
                        setBodyInstance: function(e) {
                            d = e
                        },
                        positionManuallyRef: h,
                        isMountedRef: t,
                        zIndexRef: Dt(e, "zIndex"),
                        extraClassRef: Dt(e, "internalExtraClass"),
                        internalRenderBodyRef: Dt(e, "internalRenderBody")
                    }), pr((() => {
                        i.value && a() && v(!1)
                    }));
                    return {
                        binderInstRef: n,
                        positionManually: h,
                        mergedShowConsideringDisabledProp: l,
                        uncontrolledShow: r,
                        mergedShowArrow: u,
                        getMergedShow: s,
                        setShow: function(e) {
                            r.value = e
                        },
                        handleClick: function() {
                            if ("click" === e.trigger && !a()) {
                                g(), b();
                                v(!s())
                            }
                        },
                        handleMouseEnter: m,
                        handleMouseLeave: y,
                        handleFocus: function() {
                            const t = a();
                            if ("focus" === e.trigger && !t) {
                                if (s()) return;
                                v(!0)
                            }
                        },
                        handleBlur: function() {
                            const t = a();
                            if ("focus" === e.trigger && !t) {
                                if (!s()) return;
                                v(!1)
                            }
                        },
                        syncPosition: function() {
                            d && d.syncPosition()
                        }
                    }
                },
                render() {
                    var e;
                    const {
                        positionManually: t,
                        $slots: n
                    } = this;
                    let o, r = !1;
                    if (!t && (o = n.activator ? mg(n, "activator") : mg(n, "trigger"), o)) {
                        o = Jr(o), o = o.type === Rr ? Ti("span", [o]) : o;
                        const n = {
                            onClick: this.handleClick,
                            onMouseenter: this.handleMouseEnter,
                            onMouseleave: this.handleMouseLeave,
                            onFocus: this.handleFocus,
                            onBlur: this.handleBlur
                        };
                        if (null === (e = o.type) || void 0 === e ? void 0 : e.__popover__) r = !0, o.props || (o.props = {
                            internalSyncTargetWithParent: !0,
                            internalInheritedEventHandlers: []
                        }), o.props.internalSyncTargetWithParent = !0, o.props.internalInheritedEventHandlers ? o.props.internalInheritedEventHandlers = [n, ...o.props.internalInheritedEventHandlers] : o.props.internalInheritedEventHandlers = [n];
                        else {
                            const {
                                internalInheritedEventHandlers: e
                            } = this, r = [n, ...e], i = {
                                onBlur: e => {
                                    r.forEach((t => {
                                        t.onBlur(e)
                                    }))
                                },
                                onFocus: e => {
                                    r.forEach((t => {
                                        t.onFocus(e)
                                    }))
                                },
                                onClick: e => {
                                    r.forEach((t => {
                                        t.onClick(e)
                                    }))
                                },
                                onMouseenter: e => {
                                    r.forEach((t => {
                                        t.onMouseenter(e)
                                    }))
                                },
                                onMouseleave: e => {
                                    r.forEach((t => {
                                        t.onMouseleave(e)
                                    }))
                                }
                            };
                            ! function(e, t, n) {
                                gm[t].forEach((t => {
                                    e.props ? e.props = Object.assign({}, e.props) : e.props = {};
                                    const o = e.props[t],
                                        r = n[t];
                                    e.props[t] = o ? (...e) => {
                                        o(...e), r(...e)
                                    } : r
                                }))
                            }(o, e ? "nested" : t ? "manual" : this.trigger, i)
                        }
                    }
                    return Ti(Ev, {
                        ref: "binderInstRef",
                        syncTarget: !r,
                        syncTargetWithParent: this.internalSyncTargetWithParent
                    }, {
                        default: () => {
                            this.mergedShowConsideringDisabledProp;
                            const e = this.getMergedShow();
                            return [this.internalTrapFocus && e ? fn(Ti("div", {
                                style: {
                                    position: "fixed",
                                    inset: 0
                                }
                            }), [
                                [Iv, {
                                    enabled: e,
                                    zIndex: this.zIndex
                                }]
                            ]) : null, t ? null : Ti(Ov, null, {
                                default: () => o
                            }), Ti(hm, yg(this.$props, vm, Object.assign(Object.assign({}, this.$attrs), {
                                showArrow: this.mergedShowArrow,
                                show: e
                            })), {
                                default: () => {
                                    var e, t;
                                    return null === (t = (e = this.$slots).default) || void 0 === t ? void 0 : t.call(e)
                                },
                                header: () => {
                                    var e, t;
                                    return null === (t = (e = this.$slots).header) || void 0 === t ? void 0 : t.call(e)
                                },
                                footer: () => {
                                    var e, t;
                                    return null === (t = (e = this.$slots).footer) || void 0 === t ? void 0 : t.call(e)
                                }
                            })]
                        }
                    })
                }
            }),
            ym = Yp("close", Ti("svg", {
                viewBox: "0 0 12 12",
                version: "1.1",
                xmlns: "http://www.w3.org/2000/svg",
                "aria-hidden": !0
            }, Ti("g", {
                stroke: "none",
                "stroke-width": "1",
                fill: "none",
                "fill-rule": "evenodd"
            }, Ti("g", {
                fill: "currentColor",
                "fill-rule": "nonzero"
            }, Ti("path", {
                d: "M2.08859116,2.2156945 L2.14644661,2.14644661 C2.32001296,1.97288026 2.58943736,1.95359511 2.7843055,2.08859116 L2.85355339,2.14644661 L6,5.293 L9.14644661,2.14644661 C9.34170876,1.95118446 9.65829124,1.95118446 9.85355339,2.14644661 C10.0488155,2.34170876 10.0488155,2.65829124 9.85355339,2.85355339 L6.707,6 L9.85355339,9.14644661 C10.0271197,9.32001296 10.0464049,9.58943736 9.91140884,9.7843055 L9.85355339,9.85355339 C9.67998704,10.0271197 9.41056264,10.0464049 9.2156945,9.91140884 L9.14644661,9.85355339 L6,6.707 L2.85355339,9.85355339 C2.65829124,10.0488155 2.34170876,10.0488155 2.14644661,9.85355339 C1.95118446,9.65829124 1.95118446,9.34170876 2.14644661,9.14644661 L5.293,6 L2.14644661,2.85355339 C1.97288026,2.67998704 1.95359511,2.41056264 2.08859116,2.2156945 L2.14644661,2.14644661 L2.08859116,2.2156945 Z"
            }))))),
            xm = Ru("base-close", "\n display: flex;\n align-items: center;\n justify-content: center;\n cursor: pointer;\n background-color: transparent;\n color: var(--n-close-icon-color);\n border-radius: var(--n-close-border-radius);\n height: var(--n-close-size);\n width: var(--n-close-size);\n font-size: var(--n-close-icon-size);\n outline: none;\n border: none;\n position: relative;\n padding: 0;\n", [Ou("absolute", "\n height: var(--n-close-icon-size);\n width: var(--n-close-icon-size);\n "), Fu("&::before", '\n content: "";\n position: absolute;\n width: var(--n-close-size);\n height: var(--n-close-size);\n left: 50%;\n top: 50%;\n transform: translateY(-50%) translateX(-50%);\n transition: inherit;\n border-radius: inherit;\n '), Bu("disabled", [Fu("&:hover", "\n color: var(--n-close-icon-color-hover);\n "), Fu("&:hover::before", "\n background-color: var(--n-close-color-hover);\n "), Fu("&:focus::before", "\n background-color: var(--n-close-color-hover);\n "), Fu("&:active", "\n color: var(--n-close-icon-color-pressed);\n "), Fu("&:active::before", "\n background-color: var(--n-close-color-pressed);\n ")]), Ou("disabled", "\n cursor: not-allowed;\n color: var(--n-close-icon-color-disabled);\n background-color: transparent;\n "), Ou("round", [Fu("&::before", "\n border-radius: 50%;\n ")])]),
            wm = Tn({
                name: "BaseClose",
                props: {
                    isButtonTag: {
                        type: Boolean,
                        default: !0
                    },
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    disabled: {
                        type: Boolean,
                        default: void 0
                    },
                    focusable: {
                        type: Boolean,
                        default: !0
                    },
                    round: Boolean,
                    onClick: Function,
                    absolute: Boolean
                },
                setup(e) {
                    return Zu("-base-close", xm, Dt(e, "clsPrefix")), () => {
                        const {
                            clsPrefix: t,
                            disabled: n,
                            absolute: o,
                            round: r,
                            isButtonTag: i
                        } = e;
                        return Ti(i ? "button" : "div", {
                            type: i ? "button" : void 0,
                            tabindex: n || !e.focusable ? -1 : 0,
                            "aria-disabled": n,
                            "aria-label": "close",
                            role: i ? void 0 : "button",
                            disabled: n,
                            class: [`${t}-base-close`, o && `${t}-base-close--absolute`, n && `${t}-base-close--disabled`, r && `${t}-base-close--round`],
                            onMousedown: t => {
                                e.focusable || t.preventDefault()
                            },
                            onClick: e.onClick
                        }, Ti(Qp, {
                            clsPrefix: t
                        }, {
                            default: () => Ti(ym, null)
                        }))
                    }
                }
            }),
            Cm = {
                closeIconSizeTiny: "12px",
                closeIconSizeSmall: "12px",
                closeIconSizeMedium: "14px",
                closeIconSizeLarge: "14px",
                closeSizeTiny: "16px",
                closeSizeSmall: "16px",
                closeSizeMedium: "18px",
                closeSizeLarge: "18px",
                padding: "0 7px",
                closeMargin: "0 0 0 4px"
            };
        var Sm = {
                name: "Tag",
                common: of,
                self: function(e) {
                    const {
                        textColor2: t,
                        primaryColorHover: n,
                        primaryColorPressed: o,
                        primaryColor: r,
                        infoColor: i,
                        successColor: l,
                        warningColor: a,
                        errorColor: s,
                        baseColor: c,
                        borderColor: u,
                        opacityDisabled: d,
                        tagColor: f,
                        closeIconColor: p,
                        closeIconColorHover: h,
                        closeIconColorPressed: v,
                        borderRadiusSmall: g,
                        fontSizeMini: b,
                        fontSizeTiny: m,
                        fontSizeSmall: y,
                        fontSizeMedium: x,
                        heightMini: w,
                        heightTiny: C,
                        heightSmall: S,
                        heightMedium: k,
                        closeColorHover: $,
                        closeColorPressed: _,
                        buttonColor2Hover: z,
                        buttonColor2Pressed: T,
                        fontWeightStrong: P
                    } = e;
                    return Object.assign(Object.assign({}, Cm), {
                        closeBorderRadius: g,
                        heightTiny: w,
                        heightSmall: C,
                        heightMedium: S,
                        heightLarge: k,
                        borderRadius: g,
                        opacityDisabled: d,
                        fontSizeTiny: b,
                        fontSizeSmall: m,
                        fontSizeMedium: y,
                        fontSizeLarge: x,
                        fontWeightStrong: P,
                        textColorCheckable: t,
                        textColorHoverCheckable: t,
                        textColorPressedCheckable: t,
                        textColorChecked: c,
                        colorCheckable: "#0000",
                        colorHoverCheckable: z,
                        colorPressedCheckable: T,
                        colorChecked: r,
                        colorCheckedHover: n,
                        colorCheckedPressed: o,
                        border: `1px solid ${u}`,
                        textColor: t,
                        color: f,
                        colorBordered: "rgb(250, 250, 252)",
                        closeIconColor: p,
                        closeIconColorHover: h,
                        closeIconColorPressed: v,
                        closeColorHover: $,
                        closeColorPressed: _,
                        borderPrimary: `1px solid ${Kc(r,{alpha:.3})}`,
                        textColorPrimary: r,
                        colorPrimary: Kc(r, {
                            alpha: .12
                        }),
                        colorBorderedPrimary: Kc(r, {
                            alpha: .1
                        }),
                        closeIconColorPrimary: r,
                        closeIconColorHoverPrimary: r,
                        closeIconColorPressedPrimary: r,
                        closeColorHoverPrimary: Kc(r, {
                            alpha: .12
                        }),
                        closeColorPressedPrimary: Kc(r, {
                            alpha: .18
                        }),
                        borderInfo: `1px solid ${Kc(i,{alpha:.3})}`,
                        textColorInfo: i,
                        colorInfo: Kc(i, {
                            alpha: .12
                        }),
                        colorBorderedInfo: Kc(i, {
                            alpha: .1
                        }),
                        closeIconColorInfo: i,
                        closeIconColorHoverInfo: i,
                        closeIconColorPressedInfo: i,
                        closeColorHoverInfo: Kc(i, {
                            alpha: .12
                        }),
                        closeColorPressedInfo: Kc(i, {
                            alpha: .18
                        }),
                        borderSuccess: `1px solid ${Kc(l,{alpha:.3})}`,
                        textColorSuccess: l,
                        colorSuccess: Kc(l, {
                            alpha: .12
                        }),
                        colorBorderedSuccess: Kc(l, {
                            alpha: .1
                        }),
                        closeIconColorSuccess: l,
                        closeIconColorHoverSuccess: l,
                        closeIconColorPressedSuccess: l,
                        closeColorHoverSuccess: Kc(l, {
                            alpha: .12
                        }),
                        closeColorPressedSuccess: Kc(l, {
                            alpha: .18
                        }),
                        borderWarning: `1px solid ${Kc(a,{alpha:.35})}`,
                        textColorWarning: a,
                        colorWarning: Kc(a, {
                            alpha: .15
                        }),
                        colorBorderedWarning: Kc(a, {
                            alpha: .12
                        }),
                        closeIconColorWarning: a,
                        closeIconColorHoverWarning: a,
                        closeIconColorPressedWarning: a,
                        closeColorHoverWarning: Kc(a, {
                            alpha: .12
                        }),
                        closeColorPressedWarning: Kc(a, {
                            alpha: .18
                        }),
                        borderError: `1px solid ${Kc(s,{alpha:.23})}`,
                        textColorError: s,
                        colorError: Kc(s, {
                            alpha: .1
                        }),
                        colorBorderedError: Kc(s, {
                            alpha: .08
                        }),
                        closeIconColorError: s,
                        closeIconColorHoverError: s,
                        closeIconColorPressedError: s,
                        closeColorHoverError: Kc(s, {
                            alpha: .12
                        }),
                        closeColorPressedError: Kc(s, {
                            alpha: .18
                        })
                    })
                }
            },
            km = {
                color: Object,
                type: {
                    type: String,
                    default: "default"
                },
                round: Boolean,
                size: {
                    type: String,
                    default: "medium"
                },
                closable: Boolean,
                disabled: {
                    type: Boolean,
                    default: void 0
                }
            },
            $m = Ru("tag", "\n --n-close-margin: var(--n-close-margin-top) var(--n-close-margin-right) var(--n-close-margin-bottom) var(--n-close-margin-left);\n white-space: nowrap;\n position: relative;\n box-sizing: border-box;\n cursor: default;\n display: inline-flex;\n align-items: center;\n flex-wrap: nowrap;\n padding: var(--n-padding);\n border-radius: var(--n-border-radius);\n color: var(--n-text-color);\n background-color: var(--n-color);\n transition: \n border-color .3s var(--n-bezier),\n background-color .3s var(--n-bezier),\n color .3s var(--n-bezier),\n box-shadow .3s var(--n-bezier),\n opacity .3s var(--n-bezier);\n line-height: 1;\n height: var(--n-height);\n font-size: var(--n-font-size);\n", [Ou("strong", "\n font-weight: var(--n-font-weight-strong);\n "), Eu("border", "\n pointer-events: none;\n position: absolute;\n left: 0;\n right: 0;\n top: 0;\n bottom: 0;\n border-radius: inherit;\n border: var(--n-border);\n transition: border-color .3s var(--n-bezier);\n "), Eu("icon", "\n display: flex;\n margin: 0 4px 0 0;\n color: var(--n-text-color);\n transition: color .3s var(--n-bezier);\n font-size: var(--n-avatar-size-override);\n "), Eu("avatar", "\n display: flex;\n margin: 0 6px 0 0;\n "), Eu("close", "\n margin: var(--n-close-margin);\n transition:\n background-color .3s var(--n-bezier),\n color .3s var(--n-bezier);\n "), Ou("round", "\n padding: 0 calc(var(--n-height) / 3);\n border-radius: calc(var(--n-height) / 2);\n ", [Eu("icon", "\n margin: 0 4px 0 calc((var(--n-height) - 8px) / -2);\n "), Eu("avatar", "\n margin: 0 6px 0 calc((var(--n-height) - 8px) / -2);\n "), Ou("closable", "\n padding: 0 calc(var(--n-height) / 4) 0 calc(var(--n-height) / 3);\n ")]), Ou("icon, avatar", [Ou("round", "\n padding: 0 calc(var(--n-height) / 3) 0 calc(var(--n-height) / 2);\n ")]), Ou("disabled", "\n cursor: not-allowed !important;\n opacity: var(--n-opacity-disabled);\n "), Ou("checkable", "\n cursor: pointer;\n box-shadow: none;\n color: var(--n-text-color-checkable);\n background-color: var(--n-color-checkable);\n ", [Bu("disabled", [Fu("&:hover", "background-color: var(--n-color-hover-checkable);", [Bu("checked", "color: var(--n-text-color-hover-checkable);")]), Fu("&:active", "background-color: var(--n-color-pressed-checkable);", [Bu("checked", "color: var(--n-text-color-pressed-checkable);")])]), Ou("checked", "\n color: var(--n-text-color-checked);\n background-color: var(--n-color-checked);\n ", [Bu("disabled", [Fu("&:hover", "background-color: var(--n-color-checked-hover);"), Fu("&:active", "background-color: var(--n-color-checked-pressed);")])])])]);
        const _m = Object.assign(Object.assign(Object.assign({}, Vu.props), km), {
            bordered: {
                type: Boolean,
                default: void 0
            },
            checked: Boolean,
            checkable: Boolean,
            strong: Boolean,
            triggerClickOnClose: Boolean,
            onClose: [Array, Function],
            onMouseenter: Function,
            onMouseleave: Function,
            "onUpdate:checked": Function,
            onUpdateChecked: Function,
            internalCloseFocusable: {
                type: Boolean,
                default: !0
            },
            internalCloseIsButtonTag: {
                type: Boolean,
                default: !0
            },
            onCheckedChange: Function
        });
        var zm = Tn({
            name: "Tag",
            props: _m,
            setup(e) {
                const t = Ft(null),
                    {
                        mergedBorderedRef: n,
                        mergedClsPrefixRef: o,
                        inlineThemeDisabled: r,
                        mergedRtlRef: i
                    } = zc(e),
                    l = Vu("Tag", "-tag", $m, Sm, e, o);
                $o("n-tag", {
                    roundRef: Dt(e, "round")
                });
                const a = {
                        setTextContent(e) {
                            const {
                                value: n
                            } = t;
                            n && (n.textContent = e)
                        }
                    },
                    s = lu("Tag", i, o),
                    c = zi((() => {
                        const {
                            type: t,
                            size: o,
                            color: {
                                color: r,
                                textColor: i
                            } = {}
                        } = e, {
                            common: {
                                cubicBezierEaseInOut: a
                            },
                            self: {
                                padding: s,
                                closeMargin: c,
                                borderRadius: u,
                                opacityDisabled: d,
                                textColorCheckable: f,
                                textColorHoverCheckable: p,
                                textColorPressedCheckable: h,
                                textColorChecked: v,
                                colorCheckable: g,
                                colorHoverCheckable: b,
                                colorPressedCheckable: m,
                                colorChecked: y,
                                colorCheckedHover: x,
                                colorCheckedPressed: w,
                                closeBorderRadius: C,
                                fontWeightStrong: S,
                                [Iu("colorBordered", t)]: k,
                                [Iu("closeSize", o)]: $,
                                [Iu("closeIconSize", o)]: _,
                                [Iu("fontSize", o)]: z,
                                [Iu("height", o)]: T,
                                [Iu("color", t)]: P,
                                [Iu("textColor", t)]: F,
                                [Iu("border", t)]: M,
                                [Iu("closeIconColor", t)]: R,
                                [Iu("closeIconColorHover", t)]: E,
                                [Iu("closeIconColorPressed", t)]: O,
                                [Iu("closeColorHover", t)]: B,
                                [Iu("closeColorPressed", t)]: A
                            }
                        } = l.value, I = hf(c);
                        return {
                            "--n-font-weight-strong": S,
                            "--n-avatar-size-override": `calc(${T} - 8px)`,
                            "--n-bezier": a,
                            "--n-border-radius": u,
                            "--n-border": M,
                            "--n-close-icon-size": _,
                            "--n-close-color-pressed": A,
                            "--n-close-color-hover": B,
                            "--n-close-border-radius": C,
                            "--n-close-icon-color": R,
                            "--n-close-icon-color-hover": E,
                            "--n-close-icon-color-pressed": O,
                            "--n-close-icon-color-disabled": R,
                            "--n-close-margin-top": I.top,
                            "--n-close-margin-right": I.right,
                            "--n-close-margin-bottom": I.bottom,
                            "--n-close-margin-left": I.left,
                            "--n-close-size": $,
                            "--n-color": r || (n.value ? k : P),
                            "--n-color-checkable": g,
                            "--n-color-checked": y,
                            "--n-color-checked-hover": x,
                            "--n-color-checked-pressed": w,
                            "--n-color-hover-checkable": b,
                            "--n-color-pressed-checkable": m,
                            "--n-font-size": z,
                            "--n-height": T,
                            "--n-opacity-disabled": d,
                            "--n-padding": s,
                            "--n-text-color": i || F,
                            "--n-text-color-checkable": f,
                            "--n-text-color-checked": v,
                            "--n-text-color-hover-checkable": p,
                            "--n-text-color-pressed-checkable": h
                        }
                    })),
                    u = r ? Ku("tag", zi((() => {
                        let t = "";
                        const {
                            type: o,
                            size: r,
                            color: {
                                color: i,
                                textColor: l
                            } = {}
                        } = e;
                        return t += o[0], t += r[0], i && (t += `a${ad(i)}`), l && (t += `b${ad(l)}`), n.value && (t += "c"), t
                    })), c, e) : void 0;
                return Object.assign(Object.assign({}, a), {
                    rtlEnabled: s,
                    mergedClsPrefix: o,
                    contentRef: t,
                    mergedBordered: n,
                    handleClick: function() {
                        if (!e.disabled && e.checkable) {
                            const {
                                checked: t,
                                onCheckedChange: n,
                                onUpdateChecked: o,
                                "onUpdate:checked": r
                            } = e;
                            o && o(!t), r && r(!t), n && n(!t)
                        }
                    },
                    handleCloseClick: function(t) {
                        if (e.triggerClickOnClose || t.stopPropagation(), !e.disabled) {
                            const {
                                onClose: n
                            } = e;
                            n && ld(n, t)
                        }
                    },
                    cssVars: r ? void 0 : c,
                    themeClass: null == u ? void 0 : u.themeClass,
                    onRender: null == u ? void 0 : u.onRender
                })
            },
            render() {
                var e, t;
                const {
                    mergedClsPrefix: n,
                    rtlEnabled: o,
                    closable: r,
                    color: {
                        borderColor: i
                    } = {},
                    round: l,
                    onRender: a,
                    $slots: s
                } = this;
                null == a || a();
                const c = dd(s.avatar, (e => e && Ti("div", {
                        class: `${n}-tag__avatar`
                    }, e))),
                    u = dd(s.icon, (e => e && Ti("div", {
                        class: `${n}-tag__icon`
                    }, e)));
                return Ti("div", {
                    class: [`${n}-tag`, this.themeClass, {
                        [`${n}-tag--rtl`]: o,
                        [`${n}-tag--strong`]: this.strong,
                        [`${n}-tag--disabled`]: this.disabled,
                        [`${n}-tag--checkable`]: this.checkable,
                        [`${n}-tag--checked`]: this.checkable && this.checked,
                        [`${n}-tag--round`]: l,
                        [`${n}-tag--avatar`]: c,
                        [`${n}-tag--icon`]: u,
                        [`${n}-tag--closable`]: r
                    }],
                    style: this.cssVars,
                    onClick: this.handleClick,
                    onMouseenter: this.onMouseenter,
                    onMouseleave: this.onMouseleave
                }, u || c, Ti("span", {
                    class: `${n}-tag__content`,
                    ref: "contentRef"
                }, null === (t = (e = this.$slots).default) || void 0 === t ? void 0 : t.call(e)), !this.checkable && r ? Ti(wm, {
                    clsPrefix: n,
                    class: `${n}-tag__close`,
                    disabled: this.disabled,
                    onClick: this.handleCloseClick,
                    focusable: this.internalCloseFocusable,
                    round: l,
                    isButtonTag: this.internalCloseIsButtonTag,
                    absolute: !0
                }) : null, !this.checkable && this.mergedBordered ? Ti("div", {
                    class: `${n}-tag__border`,
                    style: {
                        borderColor: i
                    }
                }) : null)
            }
        });

        function Tm(e, ...t) {
            return "function" == typeof e ? e(...t) : "string" == typeof e ? Qr(e) : "number" == typeof e ? Qr(String(e)) : null
        }

        function Pm(e, t) {
            t && (Nn((() => {
                const {
                    value: n
                } = e;
                n && tp.registerHandler(n, t)
            })), Vn((() => {
                const {
                    value: t
                } = e;
                t && tp.unregisterHandler(t)
            })))
        }

        function Fm(e) {
            switch (typeof e) {
                case "string":
                    return e || void 0;
                case "number":
                    return String(e);
                default:
                    return
            }
        }
        var Mm = {
            paddingSingle: "0 26px 0 12px",
            paddingMultiple: "3px 26px 0 12px",
            clearSize: "16px",
            arrowSize: "16px"
        };
        var Rm = {
                name: "InternalSelection",
                common: of,
                peers: {
                    Popover: Ag
                },
                self: function(e) {
                    const {
                        borderRadius: t,
                        textColor2: n,
                        textColorDisabled: o,
                        inputColor: r,
                        inputColorDisabled: i,
                        primaryColor: l,
                        primaryColorHover: a,
                        warningColor: s,
                        warningColorHover: c,
                        errorColor: u,
                        errorColorHover: d,
                        borderColor: f,
                        iconColor: p,
                        iconColorDisabled: h,
                        clearColor: v,
                        clearColorHover: g,
                        clearColorPressed: b,
                        placeholderColor: m,
                        placeholderColorDisabled: y,
                        fontSizeTiny: x,
                        fontSizeSmall: w,
                        fontSizeMedium: C,
                        fontSizeLarge: S,
                        heightTiny: k,
                        heightSmall: $,
                        heightMedium: _,
                        heightLarge: z
                    } = e;
                    return Object.assign(Object.assign({}, Mm), {
                        fontSizeTiny: x,
                        fontSizeSmall: w,
                        fontSizeMedium: C,
                        fontSizeLarge: S,
                        heightTiny: k,
                        heightSmall: $,
                        heightMedium: _,
                        heightLarge: z,
                        borderRadius: t,
                        textColor: n,
                        textColorDisabled: o,
                        placeholderColor: m,
                        placeholderColorDisabled: y,
                        color: r,
                        colorDisabled: i,
                        colorActive: r,
                        border: `1px solid ${f}`,
                        borderHover: `1px solid ${a}`,
                        borderActive: `1px solid ${l}`,
                        borderFocus: `1px solid ${a}`,
                        boxShadowHover: "none",
                        boxShadowActive: `0 0 0 2px ${Kc(l,{alpha:.2})}`,
                        boxShadowFocus: `0 0 0 2px ${Kc(l,{alpha:.2})}`,
                        caretColor: l,
                        arrowColor: p,
                        arrowColorDisabled: h,
                        loadingColor: l,
                        borderWarning: `1px solid ${s}`,
                        borderHoverWarning: `1px solid ${c}`,
                        borderActiveWarning: `1px solid ${s}`,
                        borderFocusWarning: `1px solid ${c}`,
                        boxShadowHoverWarning: "none",
                        boxShadowActiveWarning: `0 0 0 2px ${Kc(s,{alpha:.2})}`,
                        boxShadowFocusWarning: `0 0 0 2px ${Kc(s,{alpha:.2})}`,
                        colorActiveWarning: r,
                        caretColorWarning: s,
                        borderError: `1px solid ${u}`,
                        borderHoverError: `1px solid ${d}`,
                        borderActiveError: `1px solid ${u}`,
                        borderFocusError: `1px solid ${d}`,
                        boxShadowHoverError: "none",
                        boxShadowActiveError: `0 0 0 2px ${Kc(u,{alpha:.2})}`,
                        boxShadowFocusError: `0 0 0 2px ${Kc(u,{alpha:.2})}`,
                        colorActiveError: r,
                        caretColorError: u,
                        clearColor: v,
                        clearColorHover: g,
                        clearColorPressed: b
                    })
                }
            },
            Em = Fu([Ru("base-selection", "\n --n-padding-single: var(--n-padding-single-top) var(--n-padding-single-right) var(--n-padding-single-bottom) var(--n-padding-single-left);\n --n-padding-multiple: var(--n-padding-multiple-top) var(--n-padding-multiple-right) var(--n-padding-multiple-bottom) var(--n-padding-multiple-left);\n position: relative;\n z-index: auto;\n box-shadow: none;\n width: 100%;\n max-width: 100%;\n display: inline-block;\n vertical-align: bottom;\n border-radius: var(--n-border-radius);\n min-height: var(--n-height);\n line-height: 1.5;\n font-size: var(--n-font-size);\n ", [Ru("base-loading", "\n color: var(--n-loading-color);\n "), Ru("base-selection-tags", "min-height: var(--n-height);"), Eu("border, state-border", "\n position: absolute;\n left: 0;\n right: 0;\n top: 0;\n bottom: 0;\n pointer-events: none;\n border: var(--n-border);\n border-radius: inherit;\n transition:\n box-shadow .3s var(--n-bezier),\n border-color .3s var(--n-bezier);\n "), Eu("state-border", "\n z-index: 1;\n border-color: #0000;\n "), Ru("base-suffix", "\n cursor: pointer;\n position: absolute;\n top: 50%;\n transform: translateY(-50%);\n right: 10px;\n ", [Eu("arrow", "\n font-size: var(--n-arrow-size);\n color: var(--n-arrow-color);\n transition: color .3s var(--n-bezier);\n ")]), Ru("base-selection-overlay", "\n display: flex;\n align-items: center;\n white-space: nowrap;\n pointer-events: none;\n position: absolute;\n top: 0;\n right: 0;\n bottom: 0;\n left: 0;\n padding: var(--n-padding-single);\n transition: color .3s var(--n-bezier);\n ", [Eu("wrapper", "\n flex-basis: 0;\n flex-grow: 1;\n overflow: hidden;\n text-overflow: ellipsis;\n ")]), Ru("base-selection-placeholder", "\n color: var(--n-placeholder-color);\n ", [Eu("inner", "\n max-width: 100%;\n overflow: hidden;\n ")]), Ru("base-selection-tags", "\n cursor: pointer;\n outline: none;\n box-sizing: border-box;\n position: relative;\n z-index: auto;\n display: flex;\n padding: var(--n-padding-multiple);\n flex-wrap: wrap;\n align-items: center;\n width: 100%;\n vertical-align: bottom;\n background-color: var(--n-color);\n border-radius: inherit;\n transition:\n color .3s var(--n-bezier),\n box-shadow .3s var(--n-bezier),\n background-color .3s var(--n-bezier);\n "), Ru("base-selection-label", "\n height: var(--n-height);\n display: inline-flex;\n width: 100%;\n vertical-align: bottom;\n cursor: pointer;\n outline: none;\n z-index: auto;\n box-sizing: border-box;\n position: relative;\n transition:\n color .3s var(--n-bezier),\n box-shadow .3s var(--n-bezier),\n background-color .3s var(--n-bezier);\n border-radius: inherit;\n background-color: var(--n-color);\n align-items: center;\n ", [Ru("base-selection-input", "\n font-size: inherit;\n line-height: inherit;\n outline: none;\n cursor: pointer;\n box-sizing: border-box;\n border:none;\n width: 100%;\n padding: var(--n-padding-single);\n background-color: #0000;\n color: var(--n-text-color);\n transition: color .3s var(--n-bezier);\n caret-color: var(--n-caret-color);\n ", [Eu("content", "\n text-overflow: ellipsis;\n overflow: hidden;\n white-space: nowrap; \n ")]), Eu("render-label", "\n color: var(--n-text-color);\n ")]), Bu("disabled", [Fu("&:hover", [Eu("state-border", "\n box-shadow: var(--n-box-shadow-hover);\n border: var(--n-border-hover);\n ")]), Ou("focus", [Eu("state-border", "\n box-shadow: var(--n-box-shadow-focus);\n border: var(--n-border-focus);\n ")]), Ou("active", [Eu("state-border", "\n box-shadow: var(--n-box-shadow-active);\n border: var(--n-border-active);\n "), Ru("base-selection-label", "background-color: var(--n-color-active);"), Ru("base-selection-tags", "background-color: var(--n-color-active);")])]), Ou("disabled", "cursor: not-allowed;", [Eu("arrow", "\n color: var(--n-arrow-color-disabled);\n "), Ru("base-selection-label", "\n cursor: not-allowed;\n background-color: var(--n-color-disabled);\n ", [Ru("base-selection-input", "\n cursor: not-allowed;\n color: var(--n-text-color-disabled);\n "), Eu("render-label", "\n color: var(--n-text-color-disabled);\n ")]), Ru("base-selection-tags", "\n cursor: not-allowed;\n background-color: var(--n-color-disabled);\n "), Ru("base-selection-placeholder", "\n cursor: not-allowed;\n color: var(--n-placeholder-color-disabled);\n ")]), Ru("base-selection-input-tag", "\n height: calc(var(--n-height) - 6px);\n line-height: calc(var(--n-height) - 6px);\n outline: none;\n display: none;\n position: relative;\n margin-bottom: 3px;\n max-width: 100%;\n vertical-align: bottom;\n ", [Eu("input", "\n font-size: inherit;\n font-family: inherit;\n min-width: 1px;\n padding: 0;\n background-color: #0000;\n outline: none;\n border: none;\n max-width: 100%;\n overflow: hidden;\n width: 1em;\n line-height: inherit;\n cursor: pointer;\n color: var(--n-text-color);\n caret-color: var(--n-caret-color);\n "), Eu("mirror", "\n position: absolute;\n left: 0;\n top: 0;\n white-space: pre;\n visibility: hidden;\n user-select: none;\n -webkit-user-select: none;\n opacity: 0;\n ")]), ["warning", "error"].map((e => Ou(`${e}-status`, [Eu("state-border", `border: var(--n-border-${e});`), Bu("disabled", [Fu("&:hover", [Eu("state-border", `\n box-shadow: var(--n-box-shadow-hover-${e});\n border: var(--n-border-hover-${e});\n `)]), Ou("active", [Eu("state-border", `\n box-shadow: var(--n-box-shadow-active-${e});\n border: var(--n-border-active-${e});\n `), Ru("base-selection-label", `background-color: var(--n-color-active-${e});`), Ru("base-selection-tags", `background-color: var(--n-color-active-${e});`)]), Ou("focus", [Eu("state-border", `\n box-shadow: var(--n-box-shadow-focus-${e});\n border: var(--n-border-focus-${e});\n `)])])])))]), Ru("base-selection-popover", "\n margin-bottom: -3px;\n display: flex;\n flex-wrap: wrap;\n margin-right: -8px;\n "), Ru("base-selection-tag-wrapper", "\n max-width: 100%;\n display: inline-flex;\n padding: 0 7px 3px 0;\n ", [Fu("&:last-child", "padding-right: 0;"), Ru("tag", "\n font-size: 14px;\n max-width: 100%;\n ", [Eu("content", "\n line-height: 1.25;\n text-overflow: ellipsis;\n overflow: hidden;\n ")])])]),
            Om = Tn({
                name: "InternalSelection",
                props: Object.assign(Object.assign({}, Vu.props), {
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    bordered: {
                        type: Boolean,
                        default: void 0
                    },
                    active: Boolean,
                    pattern: {
                        type: String,
                        default: ""
                    },
                    placeholder: String,
                    selectedOption: {
                        type: Object,
                        default: null
                    },
                    selectedOptions: {
                        type: Array,
                        default: null
                    },
                    labelField: {
                        type: String,
                        default: "label"
                    },
                    valueField: {
                        type: String,
                        default: "value"
                    },
                    multiple: Boolean,
                    filterable: Boolean,
                    clearable: Boolean,
                    disabled: Boolean,
                    size: {
                        type: String,
                        default: "medium"
                    },
                    loading: Boolean,
                    autofocus: Boolean,
                    showArrow: {
                        type: Boolean,
                        default: !0
                    },
                    inputProps: Object,
                    focused: Boolean,
                    renderTag: Function,
                    onKeydown: Function,
                    onClick: Function,
                    onBlur: Function,
                    onFocus: Function,
                    onDeleteOption: Function,
                    maxTagCount: [String, Number],
                    ellipsisTagPopoverProps: Object,
                    onClear: Function,
                    onPatternInput: Function,
                    onPatternFocus: Function,
                    onPatternBlur: Function,
                    renderLabel: Function,
                    status: String,
                    inlineThemeDisabled: Boolean,
                    ignoreComposition: {
                        type: Boolean,
                        default: !0
                    },
                    onResize: Function
                }),
                setup(e) {
                    const {
                        mergedClsPrefixRef: t,
                        mergedRtlRef: n
                    } = zc(e), o = lu("InternalSelection", n, t), r = Ft(null), i = Ft(null), l = Ft(null), a = Ft(null), s = Ft(null), c = Ft(null), u = Ft(null), d = Ft(null), f = Ft(null), p = Ft(null), h = Ft(!1), v = Ft(!1), g = Ft(!1), b = Vu("InternalSelection", "-internal-selection", Em, Rm, e, Dt(e, "clsPrefix")), m = zi((() => e.clearable && !e.disabled && (g.value || e.active))), y = zi((() => e.selectedOption ? e.renderTag ? e.renderTag({
                        option: e.selectedOption,
                        handleClose: () => {}
                    }) : e.renderLabel ? e.renderLabel(e.selectedOption, !0) : Tm(e.selectedOption[e.labelField], e.selectedOption, !0) : e.placeholder)), x = zi((() => {
                        const t = e.selectedOption;
                        if (t) return t[e.labelField]
                    })), w = zi((() => e.multiple ? !(!Array.isArray(e.selectedOptions) || !e.selectedOptions.length) : null !== e.selectedOption));

                    function C() {
                        var t;
                        const {
                            value: n
                        } = r;
                        if (n) {
                            const {
                                value: o
                            } = i;
                            o && (o.style.width = `${n.offsetWidth}px`, "responsive" !== e.maxTagCount && (null === (t = f.value) || void 0 === t || t.sync({
                                showAllItemsBeforeCalculate: !1
                            })))
                        }
                    }

                    function S(t) {
                        const {
                            onPatternInput: n
                        } = e;
                        n && n(t)
                    }

                    function k(t) {
                        ! function(t) {
                            const {
                                onDeleteOption: n
                            } = e;
                            n && n(t)
                        }(t)
                    }
                    vr(Dt(e, "active"), (e => {
                        e || function() {
                            const {
                                value: e
                            } = p;
                            e && (e.style.display = "none")
                        }()
                    })), vr(Dt(e, "pattern"), (() => {
                        e.multiple && Jt(C)
                    }));
                    const $ = Ft(!1);
                    let _ = null;
                    let z = null;

                    function T() {
                        null !== z && window.clearTimeout(z)
                    }
                    vr(w, (e => {
                        e || (h.value = !1)
                    })), Nn((() => {
                        pr((() => {
                            const t = c.value;
                            t && (e.disabled ? t.removeAttribute("tabindex") : t.tabIndex = v.value ? -1 : 0)
                        }))
                    })), Pm(l, e.onResize);
                    const {
                        inlineThemeDisabled: P
                    } = e, F = zi((() => {
                        const {
                            size: t
                        } = e, {
                            common: {
                                cubicBezierEaseInOut: n
                            },
                            self: {
                                borderRadius: o,
                                color: r,
                                placeholderColor: i,
                                textColor: l,
                                paddingSingle: a,
                                paddingMultiple: s,
                                caretColor: c,
                                colorDisabled: u,
                                textColorDisabled: d,
                                placeholderColorDisabled: f,
                                colorActive: p,
                                boxShadowFocus: h,
                                boxShadowActive: v,
                                boxShadowHover: g,
                                border: m,
                                borderFocus: y,
                                borderHover: x,
                                borderActive: w,
                                arrowColor: C,
                                arrowColorDisabled: S,
                                loadingColor: k,
                                colorActiveWarning: $,
                                boxShadowFocusWarning: _,
                                boxShadowActiveWarning: z,
                                boxShadowHoverWarning: T,
                                borderWarning: P,
                                borderFocusWarning: F,
                                borderHoverWarning: M,
                                borderActiveWarning: R,
                                colorActiveError: E,
                                boxShadowFocusError: O,
                                boxShadowActiveError: B,
                                boxShadowHoverError: A,
                                borderError: I,
                                borderFocusError: D,
                                borderHoverError: L,
                                borderActiveError: j,
                                clearColor: N,
                                clearColorHover: H,
                                clearColorPressed: W,
                                clearSize: V,
                                arrowSize: q,
                                [Iu("height", t)]: U,
                                [Iu("fontSize", t)]: K
                            }
                        } = b.value, G = hf(a), X = hf(s);
                        return {
                            "--n-bezier": n,
                            "--n-border": m,
                            "--n-border-active": w,
                            "--n-border-focus": y,
                            "--n-border-hover": x,
                            "--n-border-radius": o,
                            "--n-box-shadow-active": v,
                            "--n-box-shadow-focus": h,
                            "--n-box-shadow-hover": g,
                            "--n-caret-color": c,
                            "--n-color": r,
                            "--n-color-active": p,
                            "--n-color-disabled": u,
                            "--n-font-size": K,
                            "--n-height": U,
                            "--n-padding-single-top": G.top,
                            "--n-padding-multiple-top": X.top,
                            "--n-padding-single-right": G.right,
                            "--n-padding-multiple-right": X.right,
                            "--n-padding-single-left": G.left,
                            "--n-padding-multiple-left": X.left,
                            "--n-padding-single-bottom": G.bottom,
                            "--n-padding-multiple-bottom": X.bottom,
                            "--n-placeholder-color": i,
                            "--n-placeholder-color-disabled": f,
                            "--n-text-color": l,
                            "--n-text-color-disabled": d,
                            "--n-arrow-color": C,
                            "--n-arrow-color-disabled": S,
                            "--n-loading-color": k,
                            "--n-color-active-warning": $,
                            "--n-box-shadow-focus-warning": _,
                            "--n-box-shadow-active-warning": z,
                            "--n-box-shadow-hover-warning": T,
                            "--n-border-warning": P,
                            "--n-border-focus-warning": F,
                            "--n-border-hover-warning": M,
                            "--n-border-active-warning": R,
                            "--n-color-active-error": E,
                            "--n-box-shadow-focus-error": O,
                            "--n-box-shadow-active-error": B,
                            "--n-box-shadow-hover-error": A,
                            "--n-border-error": I,
                            "--n-border-focus-error": D,
                            "--n-border-hover-error": L,
                            "--n-border-active-error": j,
                            "--n-clear-size": V,
                            "--n-clear-color": N,
                            "--n-clear-color-hover": H,
                            "--n-clear-color-pressed": W,
                            "--n-arrow-size": q
                        }
                    })), M = P ? Ku("internal-selection", zi((() => e.size[0])), F, e) : void 0;
                    return {
                        mergedTheme: b,
                        mergedClearable: m,
                        mergedClsPrefix: t,
                        rtlEnabled: o,
                        patternInputFocused: v,
                        filterablePlaceholder: y,
                        label: x,
                        selected: w,
                        showTagsPanel: h,
                        isComposing: $,
                        counterRef: u,
                        counterWrapperRef: d,
                        patternInputMirrorRef: r,
                        patternInputRef: i,
                        selfRef: l,
                        multipleElRef: a,
                        singleElRef: s,
                        patternInputWrapperRef: c,
                        overflowRef: f,
                        inputTagElRef: p,
                        handleMouseDown: function(t) {
                            e.active && e.filterable && t.target !== i.value && t.preventDefault()
                        },
                        handleFocusin: function(t) {
                            var n;
                            t.relatedTarget && (null === (n = l.value) || void 0 === n ? void 0 : n.contains(t.relatedTarget)) || function(t) {
                                const {
                                    onFocus: n
                                } = e;
                                n && n(t)
                            }(t)
                        },
                        handleClear: function(t) {
                            ! function(t) {
                                const {
                                    onClear: n
                                } = e;
                                n && n(t)
                            }(t)
                        },
                        handleMouseEnter: function() {
                            g.value = !0
                        },
                        handleMouseLeave: function() {
                            g.value = !1
                        },
                        handleDeleteOption: k,
                        handlePatternKeyDown: function(t) {
                            if ("Backspace" === t.key && !$.value && !e.pattern.length) {
                                const {
                                    selectedOptions: t
                                } = e;
                                (null == t ? void 0 : t.length) && k(t[t.length - 1])
                            }
                        },
                        handlePatternInputInput: function(t) {
                            const {
                                value: n
                            } = r;
                            if (n) {
                                const e = t.target.value;
                                n.textContent = e, C()
                            }
                            e.ignoreComposition && $.value ? _ = t : S(t)
                        },
                        handlePatternInputBlur: function(t) {
                            var n;
                            v.value = !1, null === (n = e.onPatternBlur) || void 0 === n || n.call(e, t)
                        },
                        handlePatternInputFocus: function(t) {
                            var n;
                            v.value = !0, null === (n = e.onPatternFocus) || void 0 === n || n.call(e, t)
                        },
                        handleMouseEnterCounter: function() {
                            e.active || (T(), z = window.setTimeout((() => {
                                w.value && (h.value = !0)
                            }), 100))
                        },
                        handleMouseLeaveCounter: function() {
                            T()
                        },
                        handleFocusout: function(t) {
                            var n;
                            (null === (n = l.value) || void 0 === n ? void 0 : n.contains(t.relatedTarget)) || function(t) {
                                const {
                                    onBlur: n
                                } = e;
                                n && n(t)
                            }(t)
                        },
                        handleCompositionEnd: function() {
                            $.value = !1, e.ignoreComposition && S(_), _ = null
                        },
                        handleCompositionStart: function() {
                            $.value = !0
                        },
                        onPopoverUpdateShow: function(e) {
                            e || (T(), h.value = !1)
                        },
                        focus: function() {
                            var t, n, o;
                            e.filterable ? (v.value = !1, null === (t = c.value) || void 0 === t || t.focus()) : e.multiple ? null === (n = a.value) || void 0 === n || n.focus() : null === (o = s.value) || void 0 === o || o.focus()
                        },
                        focusInput: function() {
                            const {
                                value: e
                            } = i;
                            e && (! function() {
                                const {
                                    value: e
                                } = p;
                                e && (e.style.display = "inline-block")
                            }(), e.focus())
                        },
                        blur: function() {
                            var t, n;
                            if (e.filterable) v.value = !1, null === (t = c.value) || void 0 === t || t.blur(), null === (n = i.value) || void 0 === n || n.blur();
                            else if (e.multiple) {
                                const {
                                    value: e
                                } = a;
                                null == e || e.blur()
                            } else {
                                const {
                                    value: e
                                } = s;
                                null == e || e.blur()
                            }
                        },
                        blurInput: function() {
                            const {
                                value: e
                            } = i;
                            e && e.blur()
                        },
                        updateCounter: function(e) {
                            const {
                                value: t
                            } = u;
                            t && t.setTextContent(`+${e}`)
                        },
                        getCounter: function() {
                            const {
                                value: e
                            } = d;
                            return e
                        },
                        getTail: function() {
                            return i.value
                        },
                        renderLabel: e.renderLabel,
                        cssVars: P ? void 0 : F,
                        themeClass: null == M ? void 0 : M.themeClass,
                        onRender: null == M ? void 0 : M.onRender
                    }
                },
                render() {
                    const {
                        status: e,
                        multiple: t,
                        size: n,
                        disabled: o,
                        filterable: r,
                        maxTagCount: i,
                        bordered: l,
                        clsPrefix: a,
                        ellipsisTagPopoverProps: s,
                        onRender: c,
                        renderTag: u,
                        renderLabel: d
                    } = this;
                    null == c || c();
                    const f = "responsive" === i,
                        p = "number" == typeof i,
                        h = f || p,
                        v = Ti(gp, null, {
                            default: () => Ti(oh, {
                                clsPrefix: a,
                                loading: this.loading,
                                showArrow: this.showArrow,
                                showClear: this.mergedClearable && this.selected,
                                onClear: this.handleClear
                            }, {
                                default: () => {
                                    var e, t;
                                    return null === (t = (e = this.$slots).arrow) || void 0 === t ? void 0 : t.call(e)
                                }
                            })
                        });
                    let g;
                    if (t) {
                        const {
                            labelField: e
                        } = this, t = t => Ti("div", {
                            class: `${a}-base-selection-tag-wrapper`,
                            key: t.value
                        }, u ? u({
                            option: t,
                            handleClose: () => {
                                this.handleDeleteOption(t)
                            }
                        }) : Ti(zm, {
                            size: n,
                            closable: !t.disabled,
                            disabled: o,
                            onClose: () => {
                                this.handleDeleteOption(t)
                            },
                            internalCloseIsButtonTag: !1,
                            internalCloseFocusable: !1
                        }, {
                            default: () => d ? d(t, !0) : Tm(t[e], t, !0)
                        })), l = () => (p ? this.selectedOptions.slice(0, i) : this.selectedOptions).map(t), c = r ? Ti("div", {
                            class: `${a}-base-selection-input-tag`,
                            ref: "inputTagElRef",
                            key: "__input-tag__"
                        }, Ti("input", Object.assign({}, this.inputProps, {
                            ref: "patternInputRef",
                            tabindex: -1,
                            disabled: o,
                            value: this.pattern,
                            autofocus: this.autofocus,
                            class: `${a}-base-selection-input-tag__input`,
                            onBlur: this.handlePatternInputBlur,
                            onFocus: this.handlePatternInputFocus,
                            onKeydown: this.handlePatternKeyDown,
                            onInput: this.handlePatternInputInput,
                            onCompositionstart: this.handleCompositionStart,
                            onCompositionend: this.handleCompositionEnd
                        })), Ti("span", {
                            ref: "patternInputMirrorRef",
                            class: `${a}-base-selection-input-tag__mirror`
                        }, this.pattern)) : null, b = f ? () => Ti("div", {
                            class: `${a}-base-selection-tag-wrapper`,
                            ref: "counterWrapperRef"
                        }, Ti(zm, {
                            size: n,
                            ref: "counterRef",
                            onMouseenter: this.handleMouseEnterCounter,
                            onMouseleave: this.handleMouseLeaveCounter,
                            disabled: o
                        })) : void 0;
                        let m;
                        if (p) {
                            const e = this.selectedOptions.length - i;
                            e > 0 && (m = Ti("div", {
                                class: `${a}-base-selection-tag-wrapper`,
                                key: "__counter__"
                            }, Ti(zm, {
                                size: n,
                                ref: "counterRef",
                                onMouseenter: this.handleMouseEnterCounter,
                                disabled: o
                            }, {
                                default: () => `+${e}`
                            })))
                        }
                        const y = f ? r ? Ti(gg, {
                                ref: "overflowRef",
                                updateCounter: this.updateCounter,
                                getCounter: this.getCounter,
                                getTail: this.getTail,
                                style: {
                                    width: "100%",
                                    display: "flex",
                                    overflow: "hidden"
                                }
                            }, {
                                default: l,
                                counter: b,
                                tail: () => c
                            }) : Ti(gg, {
                                ref: "overflowRef",
                                updateCounter: this.updateCounter,
                                getCounter: this.getCounter,
                                style: {
                                    width: "100%",
                                    display: "flex",
                                    overflow: "hidden"
                                }
                            }, {
                                default: l,
                                counter: b
                            }) : p && m ? l().concat(m) : l(),
                            x = h ? () => Ti("div", {
                                class: `${a}-base-selection-popover`
                            }, f ? l() : this.selectedOptions.map(t)) : void 0,
                            w = h ? Object.assign({
                                show: this.showTagsPanel,
                                trigger: "hover",
                                overlap: !0,
                                placement: "top",
                                width: "trigger",
                                onUpdateShow: this.onPopoverUpdateShow,
                                theme: this.mergedTheme.peers.Popover,
                                themeOverrides: this.mergedTheme.peerOverrides.Popover
                            }, s) : null,
                            C = !this.selected && (!this.active || !this.pattern && !this.isComposing) ? Ti("div", {
                                class: `${a}-base-selection-placeholder ${a}-base-selection-overlay`
                            }, Ti("div", {
                                class: `${a}-base-selection-placeholder__inner`
                            }, this.placeholder)) : null,
                            S = r ? Ti("div", {
                                ref: "patternInputWrapperRef",
                                class: `${a}-base-selection-tags`
                            }, y, f ? null : c, v) : Ti("div", {
                                ref: "multipleElRef",
                                class: `${a}-base-selection-tags`,
                                tabindex: o ? void 0 : 0
                            }, y, v);
                        g = Ti(Mr, null, h ? Ti(mm, Object.assign({}, w, {
                            scrollable: !0,
                            style: "max-height: calc(var(--v-target-height) * 6.6);"
                        }), {
                            trigger: () => S,
                            default: x
                        }) : S, C)
                    } else if (r) {
                        const e = this.pattern || this.isComposing,
                            t = this.active ? !e : !this.selected,
                            n = !this.active && this.selected;
                        g = Ti("div", {
                            ref: "patternInputWrapperRef",
                            class: `${a}-base-selection-label`,
                            title: this.patternInputFocused ? void 0 : Fm(this.label)
                        }, Ti("input", Object.assign({}, this.inputProps, {
                            ref: "patternInputRef",
                            class: `${a}-base-selection-input`,
                            value: this.active ? this.pattern : "",
                            placeholder: "",
                            readonly: o,
                            disabled: o,
                            tabindex: -1,
                            autofocus: this.autofocus,
                            onFocus: this.handlePatternInputFocus,
                            onBlur: this.handlePatternInputBlur,
                            onInput: this.handlePatternInputInput,
                            onCompositionstart: this.handleCompositionStart,
                            onCompositionend: this.handleCompositionEnd
                        })), n ? Ti("div", {
                            class: `${a}-base-selection-label__render-label ${a}-base-selection-overlay`,
                            key: "input"
                        }, Ti("div", {
                            class: `${a}-base-selection-overlay__wrapper`
                        }, u ? u({
                            option: this.selectedOption,
                            handleClose: () => {}
                        }) : d ? d(this.selectedOption, !0) : Tm(this.label, this.selectedOption, !0))) : null, t ? Ti("div", {
                            class: `${a}-base-selection-placeholder ${a}-base-selection-overlay`,
                            key: "placeholder"
                        }, Ti("div", {
                            class: `${a}-base-selection-overlay__wrapper`
                        }, this.filterablePlaceholder)) : null, v)
                    } else g = Ti("div", {
                        ref: "singleElRef",
                        class: `${a}-base-selection-label`,
                        tabindex: this.disabled ? void 0 : 0
                    }, void 0 !== this.label ? Ti("div", {
                        class: `${a}-base-selection-input`,
                        title: Fm(this.label),
                        key: "input"
                    }, Ti("div", {
                        class: `${a}-base-selection-input__content`
                    }, u ? u({
                        option: this.selectedOption,
                        handleClose: () => {}
                    }) : d ? d(this.selectedOption, !0) : Tm(this.label, this.selectedOption, !0))) : Ti("div", {
                        class: `${a}-base-selection-placeholder ${a}-base-selection-overlay`,
                        key: "placeholder"
                    }, Ti("div", {
                        class: `${a}-base-selection-placeholder__inner`
                    }, this.placeholder)), v);
                    return Ti("div", {
                        ref: "selfRef",
                        class: [`${a}-base-selection`, this.rtlEnabled && `${a}-base-selection--rtl`, this.themeClass, e && `${a}-base-selection--${e}-status`, {
                            [`${a}-base-selection--active`]: this.active,
                            [`${a}-base-selection--selected`]: this.selected || this.active && this.pattern,
                            [`${a}-base-selection--disabled`]: this.disabled,
                            [`${a}-base-selection--multiple`]: this.multiple,
                            [`${a}-base-selection--focus`]: this.focused
                        }],
                        style: this.cssVars,
                        onClick: this.onClick,
                        onMouseenter: this.handleMouseEnter,
                        onMouseleave: this.handleMouseLeave,
                        onKeydown: this.onKeydown,
                        onFocusin: this.handleFocusin,
                        onFocusout: this.handleFocusout,
                        onMousedown: this.handleMouseDown
                    }, g, l ? Ti("div", {
                        class: `${a}-base-selection__border`
                    }) : null, l ? Ti("div", {
                        class: `${a}-base-selection__state-border`
                    }) : null)
                }
            });

        function Bm(e) {
            return e & -e
        }
        class Am {
            constructor(e, t) {
                this.l = e, this.min = t;
                const n = new Array(e + 1);
                for (let t = 0; t < e + 1; ++t) n[t] = 0;
                this.ft = n
            }
            add(e, t) {
                if (0 === t) return;
                const {
                    l: n,
                    ft: o
                } = this;
                for (e += 1; e <= n;) o[e] += t, e += Bm(e)
            }
            get(e) {
                return this.sum(e + 1) - this.sum(e)
            }
            sum(e) {
                if (void 0 === e && (e = this.l), e <= 0) return 0;
                const {
                    ft: t,
                    min: n,
                    l: o
                } = this;
                if (e > o) throw new Error("[FinweckTree.sum]: `i` is larger than length.");
                let r = e * n;
                for (; e > 0;) r += t[e], e -= Bm(e);
                return r
            }
            getBound(e) {
                let t = 0,
                    n = this.l;
                for (; n > t;) {
                    const o = Math.floor((t + n) / 2),
                        r = this.sum(o);
                    if (r > e) n = o;
                    else {
                        if (!(r < e)) return o;
                        if (t === o) return this.sum(t + 1) <= e ? t + 1 : o;
                        t = o
                    }
                }
                return t
            }
        }
        let Im, Dm;

        function Lm() {
            return "undefined" == typeof document ? 1 : (void 0 === Dm && (Dm = "chrome" in window ? window.devicePixelRatio : 1), Dm)
        }
        const jm = Wv(".v-vl", {
            maxHeight: "inherit",
            height: "100%",
            overflow: "auto",
            minWidth: "1px"
        }, [Wv("&:not(.v-vl--show-scrollbar)", {
            scrollbarWidth: "none"
        }, [Wv("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb", {
            width: 0,
            height: 0,
            display: "none"
        })])]);
        var Nm = Tn({
                name: "VirtualList",
                inheritAttrs: !1,
                props: {
                    showScrollbar: {
                        type: Boolean,
                        default: !0
                    },
                    items: {
                        type: Array,
                        default: () => []
                    },
                    itemSize: {
                        type: Number,
                        required: !0
                    },
                    itemResizable: Boolean,
                    itemsStyle: [String, Object],
                    visibleItemsTag: {
                        type: [String, Object],
                        default: "div"
                    },
                    visibleItemsProps: Object,
                    ignoreItemResize: Boolean,
                    onScroll: Function,
                    onWheel: Function,
                    onResize: Function,
                    defaultScrollKey: [Number, String],
                    defaultScrollIndex: Number,
                    keyField: {
                        type: String,
                        default: "key"
                    },
                    paddingTop: {
                        type: [Number, String],
                        default: 0
                    },
                    paddingBottom: {
                        type: [Number, String],
                        default: 0
                    }
                },
                setup(e) {
                    const t = ru();
                    jm.mount({
                        id: "vueuc/virtual-list",
                        head: !0,
                        anchorMetaName: Vv,
                        ssr: t
                    }), Nn((() => {
                        const {
                            defaultScrollIndex: t,
                            defaultScrollKey: n
                        } = e;
                        null != t ? h({
                            index: t
                        }) : null != n && h({
                            key: n
                        })
                    }));
                    let n = !1,
                        o = !1;
                    Rn((() => {
                        n = !1, o ? h({
                            top: d.value,
                            left: u
                        }) : o = !0
                    })), En((() => {
                        n = !0, o || (o = !0)
                    }));
                    const r = zi((() => {
                            const t = new Map,
                                {
                                    keyField: n
                                } = e;
                            return e.items.forEach(((e, o) => {
                                t.set(e[n], o)
                            })), t
                        })),
                        i = Ft(null),
                        l = Ft(void 0),
                        a = new Map,
                        s = zi((() => {
                            const {
                                items: t,
                                itemSize: n,
                                keyField: o
                            } = e, r = new Am(t.length, n);
                            return t.forEach(((e, t) => {
                                const n = e[o],
                                    i = a.get(n);
                                void 0 !== i && r.add(t, i)
                            })), r
                        })),
                        c = Ft(0);
                    let u = 0;
                    const d = Ft(0),
                        f = Il((() => Math.max(s.value.getBound(d.value - ff(e.paddingTop)) - 1, 0))),
                        p = zi((() => {
                            const {
                                value: t
                            } = l;
                            if (void 0 === t) return [];
                            const {
                                items: n,
                                itemSize: o
                            } = e, r = f.value, i = Math.min(r + Math.ceil(t / o + 1), n.length - 1), a = [];
                            for (let e = r; e <= i; ++e) a.push(n[e]);
                            return a
                        })),
                        h = (e, t) => {
                            if ("number" == typeof e) return void m(e, t, "auto");
                            const {
                                left: n,
                                top: o,
                                index: i,
                                key: l,
                                position: a,
                                behavior: s,
                                debounce: c = !0
                            } = e;
                            if (void 0 !== n || void 0 !== o) m(n, o, s);
                            else if (void 0 !== i) b(i, s, c);
                            else if (void 0 !== l) {
                                const e = r.value.get(l);
                                void 0 !== e && b(e, s, c)
                            } else "bottom" === a ? m(0, Number.MAX_SAFE_INTEGER, s) : "top" === a && m(0, 0, s)
                        };
                    let v, g = null;

                    function b(t, n, o) {
                        const {
                            value: r
                        } = s, l = r.sum(t) + ff(e.paddingTop);
                        if (o) {
                            v = t, null !== g && window.clearTimeout(g), g = window.setTimeout((() => {
                                v = void 0, g = null
                            }), 16);
                            const {
                                scrollTop: e,
                                offsetHeight: o
                            } = i.value;
                            if (l > e) {
                                const a = r.get(t);
                                l + a <= e + o || i.value.scrollTo({
                                    left: 0,
                                    top: l + a - o,
                                    behavior: n
                                })
                            } else i.value.scrollTo({
                                left: 0,
                                top: l,
                                behavior: n
                            })
                        } else i.value.scrollTo({
                            left: 0,
                            top: l,
                            behavior: n
                        })
                    }

                    function m(e, t, n) {
                        i.value.scrollTo({
                            left: e,
                            top: t,
                            behavior: n
                        })
                    }
                    const y = !("undefined" != typeof document && (void 0 === Im && (Im = "matchMedia" in window && window.matchMedia("(pointer:coarse)").matches), Im));
                    let x = !1;

                    function w() {
                        const {
                            value: e
                        } = i;
                        null != e && (d.value = e.scrollTop, u = e.scrollLeft)
                    }

                    function C(e) {
                        let t = e;
                        for (; null !== t;) {
                            if ("none" === t.style.display) return !0;
                            t = t.parentElement
                        }
                        return !1
                    }
                    return {
                        listHeight: l,
                        listStyle: {
                            overflow: "auto"
                        },
                        keyToIndex: r,
                        itemsStyle: zi((() => {
                            const {
                                itemResizable: t
                            } = e, n = pf(s.value.sum());
                            return c.value, [e.itemsStyle, {
                                boxSizing: "content-box",
                                height: t ? "" : n,
                                minHeight: t ? n : "",
                                paddingTop: pf(e.paddingTop),
                                paddingBottom: pf(e.paddingBottom)
                            }]
                        })),
                        visibleItemsStyle: zi((() => (c.value, {
                            transform: `translateY(${pf(s.value.sum(f.value))})`
                        }))),
                        viewportItems: p,
                        listElRef: i,
                        itemsElRef: Ft(null),
                        scrollTo: h,
                        handleListResize: function(t) {
                            if (n) return;
                            if (C(t.target)) return;
                            if (t.contentRect.height === l.value) return;
                            l.value = t.contentRect.height;
                            const {
                                onResize: o
                            } = e;
                            void 0 !== o && o(t)
                        },
                        handleListScroll: function(t) {
                            var n;
                            null === (n = e.onScroll) || void 0 === n || n.call(e, t), y && x || w()
                        },
                        handleListWheel: function(t) {
                            var n;
                            if (null === (n = e.onWheel) || void 0 === n || n.call(e, t), y) {
                                const e = i.value;
                                if (null != e) {
                                    if (0 === t.deltaX) {
                                        if (0 === e.scrollTop && t.deltaY <= 0) return;
                                        if (e.scrollTop + e.offsetHeight >= e.scrollHeight && t.deltaY >= 0) return
                                    }
                                    t.preventDefault(), e.scrollTop += t.deltaY / Lm(), e.scrollLeft += t.deltaX / Lm(), w(), x = !0, kv((() => {
                                        x = !1
                                    }))
                                }
                            }
                        },
                        handleItemResize: function(t, o) {
                            var l, u, d;
                            if (n) return;
                            if (e.ignoreItemResize) return;
                            if (C(o.target)) return;
                            const {
                                value: f
                            } = s, p = r.value.get(t), h = f.get(p), g = null !== (d = null === (u = null === (l = o.borderBoxSize) || void 0 === l ? void 0 : l[0]) || void 0 === u ? void 0 : u.blockSize) && void 0 !== d ? d : o.contentRect.height;
                            if (g === h) return;
                            0 === g - e.itemSize ? a.delete(t) : a.set(t, g - e.itemSize);
                            const b = g - h;
                            if (0 === b) return;
                            f.add(p, b);
                            const m = i.value;
                            if (null != m) {
                                if (void 0 === v) {
                                    const e = f.sum(p);
                                    m.scrollTop > e && m.scrollBy(0, b)
                                } else if (p < v) m.scrollBy(0, b);
                                else if (p === v) {
                                    g + f.sum(p) > m.scrollTop + m.offsetHeight && m.scrollBy(0, b)
                                }
                                w()
                            }
                            c.value++
                        }
                    }
                },
                render() {
                    const {
                        itemResizable: e,
                        keyField: t,
                        keyToIndex: n,
                        visibleItemsTag: o
                    } = this;
                    return Ti(np, {
                        onResize: this.handleListResize
                    }, {
                        default: () => {
                            var r, i;
                            return Ti("div", ri(this.$attrs, {
                                class: ["v-vl", this.showScrollbar && "v-vl--show-scrollbar"],
                                onScroll: this.handleListScroll,
                                onWheel: this.handleListWheel,
                                ref: "listElRef"
                            }), [0 !== this.items.length ? Ti("div", {
                                ref: "itemsElRef",
                                class: "v-vl-items",
                                style: this.itemsStyle
                            }, [Ti(o, Object.assign({
                                class: "v-vl-visible-items",
                                style: this.visibleItemsStyle
                            }, this.visibleItemsProps), {
                                default: () => this.viewportItems.map((o => {
                                    const r = o[t],
                                        i = n.get(r),
                                        l = this.$slots.default({
                                            item: o,
                                            index: i
                                        })[0];
                                    return e ? Ti(np, {
                                        key: r,
                                        onResize: e => this.handleItemResize(r, e)
                                    }, {
                                        default: () => l
                                    }) : (l.key = r, l)
                                }))
                            })]) : null === (i = (r = this.$slots).empty) || void 0 === i ? void 0 : i.call(r)])
                        }
                    })
                }
            }),
            Hm = Tn({
                name: "Empty",
                render() {
                    return Ti("svg", {
                        viewBox: "0 0 28 28",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, Ti("path", {
                        d: "M26 7.5C26 11.0899 23.0899 14 19.5 14C15.9101 14 13 11.0899 13 7.5C13 3.91015 15.9101 1 19.5 1C23.0899 1 26 3.91015 26 7.5ZM16.8536 4.14645C16.6583 3.95118 16.3417 3.95118 16.1464 4.14645C15.9512 4.34171 15.9512 4.65829 16.1464 4.85355L18.7929 7.5L16.1464 10.1464C15.9512 10.3417 15.9512 10.6583 16.1464 10.8536C16.3417 11.0488 16.6583 11.0488 16.8536 10.8536L19.5 8.20711L22.1464 10.8536C22.3417 11.0488 22.6583 11.0488 22.8536 10.8536C23.0488 10.6583 23.0488 10.3417 22.8536 10.1464L20.2071 7.5L22.8536 4.85355C23.0488 4.65829 23.0488 4.34171 22.8536 4.14645C22.6583 3.95118 22.3417 3.95118 22.1464 4.14645L19.5 6.79289L16.8536 4.14645Z",
                        fill: "currentColor"
                    }), Ti("path", {
                        d: "M25 22.75V12.5991C24.5572 13.0765 24.053 13.4961 23.5 13.8454V16H17.5L17.3982 16.0068C17.0322 16.0565 16.75 16.3703 16.75 16.75C16.75 18.2688 15.5188 19.5 14 19.5C12.4812 19.5 11.25 18.2688 11.25 16.75L11.2432 16.6482C11.1935 16.2822 10.8797 16 10.5 16H4.5V7.25C4.5 6.2835 5.2835 5.5 6.25 5.5H12.2696C12.4146 4.97463 12.6153 4.47237 12.865 4H6.25C4.45507 4 3 5.45507 3 7.25V22.75C3 24.5449 4.45507 26 6.25 26H21.75C23.5449 26 25 24.5449 25 22.75ZM4.5 22.75V17.5H9.81597L9.85751 17.7041C10.2905 19.5919 11.9808 21 14 21L14.215 20.9947C16.2095 20.8953 17.842 19.4209 18.184 17.5H23.5V22.75C23.5 23.7165 22.7165 24.5 21.75 24.5H6.25C5.2835 24.5 4.5 23.7165 4.5 22.75Z",
                        fill: "currentColor"
                    }))
                }
            }),
            Wm = {
                iconSizeSmall: "34px",
                iconSizeMedium: "40px",
                iconSizeLarge: "46px",
                iconSizeHuge: "52px"
            };
        var Vm = {
                name: "Empty",
                common: of,
                self: function(e) {
                    const {
                        textColorDisabled: t,
                        iconColor: n,
                        textColor2: o,
                        fontSizeSmall: r,
                        fontSizeMedium: i,
                        fontSizeLarge: l,
                        fontSizeHuge: a
                    } = e;
                    return Object.assign(Object.assign({}, Wm), {
                        fontSizeSmall: r,
                        fontSizeMedium: i,
                        fontSizeLarge: l,
                        fontSizeHuge: a,
                        textColor: t,
                        iconColor: n,
                        extraTextColor: o
                    })
                }
            },
            qm = Ru("empty", "\n display: flex;\n flex-direction: column;\n align-items: center;\n font-size: var(--n-font-size);\n", [Eu("icon", "\n width: var(--n-icon-size);\n height: var(--n-icon-size);\n font-size: var(--n-icon-size);\n line-height: var(--n-icon-size);\n color: var(--n-icon-color);\n transition:\n color .3s var(--n-bezier);\n ", [Fu("+", [Eu("description", "\n margin-top: 8px;\n ")])]), Eu("description", "\n transition: color .3s var(--n-bezier);\n color: var(--n-text-color);\n "), Eu("extra", "\n text-align: center;\n transition: color .3s var(--n-bezier);\n margin-top: 12px;\n color: var(--n-extra-text-color);\n ")]);
        var Um = Tn({
                name: "Empty",
                props: Object.assign(Object.assign({}, Vu.props), {
                    description: String,
                    showDescription: {
                        type: Boolean,
                        default: !0
                    },
                    showIcon: {
                        type: Boolean,
                        default: !0
                    },
                    size: {
                        type: String,
                        default: "medium"
                    },
                    renderIcon: Function
                }),
                setup(e) {
                    const {
                        mergedClsPrefixRef: t,
                        inlineThemeDisabled: n
                    } = zc(e), o = Vu("Empty", "-empty", qm, Vm, e, t), {
                        localeRef: r
                    } = bh("Empty"), i = _o($c, null), l = zi((() => {
                        var t, n, o;
                        return null !== (t = e.description) && void 0 !== t ? t : null === (o = null === (n = null == i ? void 0 : i.mergedComponentPropsRef.value) || void 0 === n ? void 0 : n.Empty) || void 0 === o ? void 0 : o.description
                    })), a = zi((() => {
                        var e, t;
                        return (null === (t = null === (e = null == i ? void 0 : i.mergedComponentPropsRef.value) || void 0 === e ? void 0 : e.Empty) || void 0 === t ? void 0 : t.renderIcon) || (() => Ti(Hm, null))
                    })), s = zi((() => {
                        const {
                            size: t
                        } = e, {
                            common: {
                                cubicBezierEaseInOut: n
                            },
                            self: {
                                [Iu("iconSize", t)]: r,
                                [Iu("fontSize", t)]: i,
                                textColor: l,
                                iconColor: a,
                                extraTextColor: s
                            }
                        } = o.value;
                        return {
                            "--n-icon-size": r,
                            "--n-font-size": i,
                            "--n-bezier": n,
                            "--n-text-color": l,
                            "--n-icon-color": a,
                            "--n-extra-text-color": s
                        }
                    })), c = n ? Ku("empty", zi((() => {
                        let t = "";
                        const {
                            size: n
                        } = e;
                        return t += n[0], t
                    })), s, e) : void 0;
                    return {
                        mergedClsPrefix: t,
                        mergedRenderIcon: a,
                        localizedDescription: zi((() => l.value || r.value.description)),
                        cssVars: n ? void 0 : s,
                        themeClass: null == c ? void 0 : c.themeClass,
                        onRender: null == c ? void 0 : c.onRender
                    }
                },
                render() {
                    const {
                        $slots: e,
                        mergedClsPrefix: t,
                        onRender: n
                    } = this;
                    return null == n || n(), Ti("div", {
                        class: [`${t}-empty`, this.themeClass],
                        style: this.cssVars
                    }, this.showIcon ? Ti("div", {
                        class: `${t}-empty__icon`
                    }, e.icon ? e.icon() : Ti(Qp, {
                        clsPrefix: t
                    }, {
                        default: this.mergedRenderIcon
                    })) : null, this.showDescription ? Ti("div", {
                        class: `${t}-empty__description`
                    }, e.default ? e.default() : this.localizedDescription) : null, e.extra ? Ti("div", {
                        class: `${t}-empty__extra`
                    }, e.extra()) : null)
                }
            }),
            Km = Tn({
                props: {
                    onFocus: Function,
                    onBlur: Function
                },
                setup(e) {
                    return () => Ti("div", {
                        style: "width: 0; height: 0",
                        tabindex: 0,
                        onFocus: e.onFocus,
                        onBlur: e.onBlur
                    })
                }
            }),
            Gm = {
                height: "calc(var(--n-option-height) * 7.6)",
                paddingSmall: "4px 0",
                paddingMedium: "4px 0",
                paddingLarge: "4px 0",
                paddingHuge: "4px 0",
                optionPaddingSmall: "0 12px",
                optionPaddingMedium: "0 12px",
                optionPaddingLarge: "0 12px",
                optionPaddingHuge: "0 12px",
                loadingSize: "18px"
            };
        var Xm = {
            name: "InternalSelectMenu",
            common: of,
            peers: {
                Scrollbar: mp,
                Empty: Vm
            },
            self: function(e) {
                const {
                    borderRadius: t,
                    popoverColor: n,
                    textColor3: o,
                    dividerColor: r,
                    textColor2: i,
                    primaryColorPressed: l,
                    textColorDisabled: a,
                    primaryColor: s,
                    opacityDisabled: c,
                    hoverColor: u,
                    fontSizeSmall: d,
                    fontSizeMedium: f,
                    fontSizeLarge: p,
                    fontSizeHuge: h,
                    heightSmall: v,
                    heightMedium: g,
                    heightLarge: b,
                    heightHuge: m
                } = e;
                return Object.assign(Object.assign({}, Gm), {
                    optionFontSizeSmall: d,
                    optionFontSizeMedium: f,
                    optionFontSizeLarge: p,
                    optionFontSizeHuge: h,
                    optionHeightSmall: v,
                    optionHeightMedium: g,
                    optionHeightLarge: b,
                    optionHeightHuge: m,
                    borderRadius: t,
                    color: n,
                    groupHeaderTextColor: o,
                    actionDividerColor: r,
                    optionTextColor: i,
                    optionTextColorPressed: l,
                    optionTextColorDisabled: a,
                    optionTextColorActive: s,
                    optionOpacityDisabled: c,
                    optionCheckColor: s,
                    optionColorPending: u,
                    optionColorActive: "rgba(0, 0, 0, 0)",
                    optionColorActivePending: u,
                    actionTextColor: i,
                    loadingColor: s
                })
            }
        };

        function Ym(e) {
            const t = e.filter((e => void 0 !== e));
            if (0 !== t.length) return 1 === t.length ? t[0] : t => {
                e.forEach((e => {
                    e && e(t)
                }))
            }
        }
        var Zm = Tn({
            name: "Checkmark",
            render() {
                return Ti("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 16 16"
                }, Ti("g", {
                    fill: "none"
                }, Ti("path", {
                    d: "M14.046 3.486a.75.75 0 0 1-.032 1.06l-7.93 7.474a.85.85 0 0 1-1.188-.022l-2.68-2.72a.75.75 0 1 1 1.068-1.053l2.234 2.267l7.468-7.038a.75.75 0 0 1 1.06.032z",
                    fill: "currentColor"
                })))
            }
        });
        var Jm = Tn({
                name: "NBaseSelectOption",
                props: {
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    tmNode: {
                        type: Object,
                        required: !0
                    }
                },
                setup(e) {
                    const {
                        valueRef: t,
                        pendingTmNodeRef: n,
                        multipleRef: o,
                        valueSetRef: r,
                        renderLabelRef: i,
                        renderOptionRef: l,
                        labelFieldRef: a,
                        valueFieldRef: s,
                        showCheckmarkRef: c,
                        nodePropsRef: u,
                        handleOptionClick: d,
                        handleOptionMouseEnter: f
                    } = _o(lg), p = Il((() => {
                        const {
                            value: t
                        } = n;
                        return !!t && e.tmNode.key === t.key
                    }));
                    return {
                        multiple: o,
                        isGrouped: Il((() => {
                            const {
                                tmNode: t
                            } = e, {
                                parent: n
                            } = t;
                            return n && "group" === n.rawNode.type
                        })),
                        showCheckmark: c,
                        nodeProps: u,
                        isPending: p,
                        isSelected: Il((() => {
                            const {
                                value: n
                            } = t, {
                                value: i
                            } = o;
                            if (null === n) return !1;
                            const l = e.tmNode.rawNode[s.value];
                            if (i) {
                                const {
                                    value: e
                                } = r;
                                return e.has(l)
                            }
                            return n === l
                        })),
                        labelField: a,
                        renderLabel: i,
                        renderOption: l,
                        handleMouseMove: function(t) {
                            const {
                                tmNode: n
                            } = e, {
                                value: o
                            } = p;
                            n.disabled || o || f(t, n)
                        },
                        handleMouseEnter: function(t) {
                            const {
                                tmNode: n
                            } = e;
                            n.disabled || f(t, n)
                        },
                        handleClick: function(t) {
                            const {
                                tmNode: n
                            } = e;
                            n.disabled || d(t, n)
                        }
                    }
                },
                render() {
                    const {
                        clsPrefix: e,
                        tmNode: {
                            rawNode: t
                        },
                        isSelected: n,
                        isPending: o,
                        isGrouped: r,
                        showCheckmark: i,
                        nodeProps: l,
                        renderOption: a,
                        renderLabel: s,
                        handleClick: c,
                        handleMouseEnter: u,
                        handleMouseMove: d
                    } = this, f = function(e, t) {
                        return Ti(Ai, {
                            name: "fade-in-scale-up-transition"
                        }, {
                            default: () => e ? Ti(Qp, {
                                clsPrefix: t,
                                class: `${t}-base-select-option__check`
                            }, {
                                default: () => Ti(Zm)
                            }) : null
                        })
                    }(n, e), p = s ? [s(t, n), i && f] : [Tm(t[this.labelField], t, n), i && f], h = null == l ? void 0 : l(t), v = Ti("div", Object.assign({}, h, {
                        class: [`${e}-base-select-option`, t.class, null == h ? void 0 : h.class, {
                            [`${e}-base-select-option--disabled`]: t.disabled,
                            [`${e}-base-select-option--selected`]: n,
                            [`${e}-base-select-option--grouped`]: r,
                            [`${e}-base-select-option--pending`]: o,
                            [`${e}-base-select-option--show-checkmark`]: i
                        }],
                        style: [(null == h ? void 0 : h.style) || "", t.style || ""],
                        onClick: Ym([c, null == h ? void 0 : h.onClick]),
                        onMouseenter: Ym([u, null == h ? void 0 : h.onMouseenter]),
                        onMousemove: Ym([d, null == h ? void 0 : h.onMousemove])
                    }), Ti("div", {
                        class: `${e}-base-select-option__content`
                    }, p));
                    return t.render ? t.render({
                        node: v,
                        option: t,
                        selected: n
                    }) : a ? a({
                        node: v,
                        option: t,
                        selected: n
                    }) : v
                }
            }),
            Qm = Tn({
                name: "NBaseSelectGroupHeader",
                props: {
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    tmNode: {
                        type: Object,
                        required: !0
                    }
                },
                setup() {
                    const {
                        renderLabelRef: e,
                        renderOptionRef: t,
                        labelFieldRef: n,
                        nodePropsRef: o
                    } = _o(lg);
                    return {
                        labelField: n,
                        nodeProps: o,
                        renderLabel: e,
                        renderOption: t
                    }
                },
                render() {
                    const {
                        clsPrefix: e,
                        renderLabel: t,
                        renderOption: n,
                        nodeProps: o,
                        tmNode: {
                            rawNode: r
                        }
                    } = this, i = null == o ? void 0 : o(r), l = t ? t(r, !1) : Tm(r[this.labelField], r, !1), a = Ti("div", Object.assign({}, i, {
                        class: [`${e}-base-select-group-header`, null == i ? void 0 : i.class]
                    }), l);
                    return r.render ? r.render({
                        node: a,
                        option: r
                    }) : n ? n({
                        node: a,
                        option: r,
                        selected: !1
                    }) : a
                }
            });
        const {
            cubicBezierEaseIn: ey,
            cubicBezierEaseOut: ty
        } = Du;

        function ny({
            transformOrigin: e = "inherit",
            duration: t = ".2s",
            enterScale: n = ".9",
            originalTransform: o = "",
            originalTransition: r = ""
        } = {}) {
            return [Fu("&.fade-in-scale-up-transition-leave-active", {
                transformOrigin: e,
                transition: `opacity ${t} ${ey}, transform ${t} ${ey} ${r&&`,${r}`}`
            }), Fu("&.fade-in-scale-up-transition-enter-active", {
                transformOrigin: e,
                transition: `opacity ${t} ${ty}, transform ${t} ${ty} ${r&&`,${r}`}`
            }), Fu("&.fade-in-scale-up-transition-enter-from, &.fade-in-scale-up-transition-leave-to", {
                opacity: 0,
                transform: `${o} scale(${n})`
            }), Fu("&.fade-in-scale-up-transition-leave-from, &.fade-in-scale-up-transition-enter-to", {
                opacity: 1,
                transform: `${o} scale(1)`
            })]
        }
        var oy = Ru("base-select-menu", "\n line-height: 1.5;\n outline: none;\n z-index: 0;\n position: relative;\n border-radius: var(--n-border-radius);\n transition:\n background-color .3s var(--n-bezier),\n box-shadow .3s var(--n-bezier);\n background-color: var(--n-color);\n", [Ru("scrollbar", "\n max-height: var(--n-height);\n "), Ru("virtual-list", "\n max-height: var(--n-height);\n "), Ru("base-select-option", "\n min-height: var(--n-option-height);\n font-size: var(--n-option-font-size);\n display: flex;\n align-items: center;\n ", [Eu("content", "\n z-index: 1;\n white-space: nowrap;\n text-overflow: ellipsis;\n overflow: hidden;\n ")]), Ru("base-select-group-header", "\n min-height: var(--n-option-height);\n font-size: .93em;\n display: flex;\n align-items: center;\n "), Ru("base-select-menu-option-wrapper", "\n position: relative;\n width: 100%;\n "), Eu("loading, empty", "\n display: flex;\n padding: 12px 32px;\n flex: 1;\n justify-content: center;\n "), Eu("loading", "\n color: var(--n-loading-color);\n font-size: var(--n-loading-size);\n "), Eu("header", "\n padding: 8px var(--n-option-padding-left);\n font-size: var(--n-option-font-size);\n transition: \n color .3s var(--n-bezier),\n border-color .3s var(--n-bezier);\n border-bottom: 1px solid var(--n-action-divider-color);\n color: var(--n-action-text-color);\n "), Eu("action", "\n padding: 8px var(--n-option-padding-left);\n font-size: var(--n-option-font-size);\n transition: \n color .3s var(--n-bezier),\n border-color .3s var(--n-bezier);\n border-top: 1px solid var(--n-action-divider-color);\n color: var(--n-action-text-color);\n "), Ru("base-select-group-header", "\n position: relative;\n cursor: default;\n padding: var(--n-option-padding);\n color: var(--n-group-header-text-color);\n "), Ru("base-select-option", "\n cursor: pointer;\n position: relative;\n padding: var(--n-option-padding);\n transition:\n color .3s var(--n-bezier),\n opacity .3s var(--n-bezier);\n box-sizing: border-box;\n color: var(--n-option-text-color);\n opacity: 1;\n ", [Ou("show-checkmark", "\n padding-right: calc(var(--n-option-padding-right) + 20px);\n "), Fu("&::before", '\n content: "";\n position: absolute;\n left: 4px;\n right: 4px;\n top: 0;\n bottom: 0;\n border-radius: var(--n-border-radius);\n transition: background-color .3s var(--n-bezier);\n '), Fu("&:active", "\n color: var(--n-option-text-color-pressed);\n "), Ou("grouped", "\n padding-left: calc(var(--n-option-padding-left) * 1.5);\n "), Ou("pending", [Fu("&::before", "\n background-color: var(--n-option-color-pending);\n ")]), Ou("selected", "\n color: var(--n-option-text-color-active);\n ", [Fu("&::before", "\n background-color: var(--n-option-color-active);\n "), Ou("pending", [Fu("&::before", "\n background-color: var(--n-option-color-active-pending);\n ")])]), Ou("disabled", "\n cursor: not-allowed;\n ", [Bu("selected", "\n color: var(--n-option-text-color-disabled);\n "), Ou("selected", "\n opacity: var(--n-option-opacity-disabled);\n ")]), Eu("check", "\n font-size: 16px;\n position: absolute;\n right: calc(var(--n-option-padding-right) - 4px);\n top: calc(50% - 7px);\n color: var(--n-option-check-color);\n transition: color .3s var(--n-bezier);\n ", [ny({
                enterScale: "0.5"
            })])])]),
            ry = Tn({
                name: "InternalSelectMenu",
                props: Object.assign(Object.assign({}, Vu.props), {
                    clsPrefix: {
                        type: String,
                        required: !0
                    },
                    scrollable: {
                        type: Boolean,
                        default: !0
                    },
                    treeMate: {
                        type: Object,
                        required: !0
                    },
                    multiple: Boolean,
                    size: {
                        type: String,
                        default: "medium"
                    },
                    value: {
                        type: [String, Number, Array],
                        default: null
                    },
                    autoPending: Boolean,
                    virtualScroll: {
                        type: Boolean,
                        default: !0
                    },
                    show: {
                        type: Boolean,
                        default: !0
                    },
                    labelField: {
                        type: String,
                        default: "label"
                    },
                    valueField: {
                        type: String,
                        default: "value"
                    },
                    loading: Boolean,
                    focusable: Boolean,
                    renderLabel: Function,
                    renderOption: Function,
                    nodeProps: Function,
                    showCheckmark: {
                        type: Boolean,
                        default: !0
                    },
                    onMousedown: Function,
                    onScroll: Function,
                    onFocus: Function,
                    onBlur: Function,
                    onKeyup: Function,
                    onKeydown: Function,
                    onTabOut: Function,
                    onMouseenter: Function,
                    onMouseleave: Function,
                    onResize: Function,
                    resetMenuOnOptionsChange: {
                        type: Boolean,
                        default: !0
                    },
                    inlineThemeDisabled: Boolean,
                    onToggle: Function
                }),
                setup(e) {
                    const {
                        mergedClsPrefixRef: t,
                        mergedRtlRef: n
                    } = zc(e), o = lu("InternalSelectMenu", n, t), r = Vu("InternalSelectMenu", "-internal-select-menu", oy, Xm, e, Dt(e, "clsPrefix")), i = Ft(null), l = Ft(null), a = Ft(null), s = zi((() => e.treeMate.getFlattenedNodes())), c = zi((() => function(e) {
                        const t = new Map;
                        return e.forEach(((e, n) => {
                            t.set(e.key, n)
                        })), e => {
                            var n;
                            return null !== (n = t.get(e)) && void 0 !== n ? n : null
                        }
                    }(s.value))), u = Ft(null);

                    function d() {
                        const {
                            value: t
                        } = u;
                        t && !e.treeMate.getNode(t.key) && (u.value = null)
                    }
                    let f;
                    vr((() => e.show), (t => {
                        t ? f = vr((() => e.treeMate), (() => {
                            e.resetMenuOnOptionsChange ? (e.autoPending ? function() {
                                const {
                                    treeMate: t
                                } = e;
                                let n = null;
                                const {
                                    value: o
                                } = e;
                                null === o ? n = t.getFirstAvailableNode() : (n = e.multiple ? t.getNode((o || [])[(o || []).length - 1]) : t.getNode(o), n && !n.disabled || (n = t.getFirstAvailableNode())), m(n || null)
                            }() : d(), Jt(y)) : d()
                        }), {
                            immediate: !0
                        }) : null == f || f()
                    }), {
                        immediate: !0
                    }), Vn((() => {
                        null == f || f()
                    }));
                    const p = zi((() => ff(r.value.self[Iu("optionHeight", e.size)]))),
                        h = zi((() => hf(r.value.self[Iu("padding", e.size)]))),
                        v = zi((() => e.multiple && Array.isArray(e.value) ? new Set(e.value) : new Set)),
                        g = zi((() => {
                            const e = s.value;
                            return e && 0 === e.length
                        }));

                    function b(t) {
                        const {
                            onScroll: n
                        } = e;
                        n && n(t)
                    }

                    function m(e, t = !1) {
                        u.value = e, t && y()
                    }

                    function y() {
                        var t, n;
                        const o = u.value;
                        if (!o) return;
                        const r = c.value(o.key);
                        null !== r && (e.virtualScroll ? null === (t = l.value) || void 0 === t || t.scrollTo({
                            index: r
                        }) : null === (n = a.value) || void 0 === n || n.scrollTo({
                            index: r,
                            elSize: p.value
                        }))
                    }
                    $o(lg, {
                        handleOptionMouseEnter: function(e, t) {
                            t.disabled || m(t, !1)
                        },
                        handleOptionClick: function(t, n) {
                            n.disabled || function(t) {
                                const {
                                    onToggle: n
                                } = e;
                                n && n(t)
                            }(n)
                        },
                        valueSetRef: v,
                        pendingTmNodeRef: u,
                        nodePropsRef: Dt(e, "nodeProps"),
                        showCheckmarkRef: Dt(e, "showCheckmark"),
                        multipleRef: Dt(e, "multiple"),
                        valueRef: Dt(e, "value"),
                        renderLabelRef: Dt(e, "renderLabel"),
                        renderOptionRef: Dt(e, "renderOption"),
                        labelFieldRef: Dt(e, "labelField"),
                        valueFieldRef: Dt(e, "valueField")
                    }), $o(ag, i), Nn((() => {
                        const {
                            value: e
                        } = a;
                        e && e.sync()
                    }));
                    const x = zi((() => {
                            const {
                                size: t
                            } = e, {
                                common: {
                                    cubicBezierEaseInOut: n
                                },
                                self: {
                                    height: o,
                                    borderRadius: i,
                                    color: l,
                                    groupHeaderTextColor: a,
                                    actionDividerColor: s,
                                    optionTextColorPressed: c,
                                    optionTextColor: u,
                                    optionTextColorDisabled: d,
                                    optionTextColorActive: f,
                                    optionOpacityDisabled: p,
                                    optionCheckColor: h,
                                    actionTextColor: v,
                                    optionColorPending: g,
                                    optionColorActive: b,
                                    loadingColor: m,
                                    loadingSize: y,
                                    optionColorActivePending: x,
                                    [Iu("optionFontSize", t)]: w,
                                    [Iu("optionHeight", t)]: C,
                                    [Iu("optionPadding", t)]: S
                                }
                            } = r.value;
                            return {
                                "--n-height": o,
                                "--n-action-divider-color": s,
                                "--n-action-text-color": v,
                                "--n-bezier": n,
                                "--n-border-radius": i,
                                "--n-color": l,
                                "--n-option-font-size": w,
                                "--n-group-header-text-color": a,
                                "--n-option-check-color": h,
                                "--n-option-color-pending": g,
                                "--n-option-color-active": b,
                                "--n-option-color-active-pending": x,
                                "--n-option-height": C,
                                "--n-option-opacity-disabled": p,
                                "--n-option-text-color": u,
                                "--n-option-text-color-active": f,
                                "--n-option-text-color-disabled": d,
                                "--n-option-text-color-pressed": c,
                                "--n-option-padding": S,
                                "--n-option-padding-left": hf(S, "left"),
                                "--n-option-padding-right": hf(S, "right"),
                                "--n-loading-color": m,
                                "--n-loading-size": y
                            }
                        })),
                        {
                            inlineThemeDisabled: w
                        } = e,
                        C = w ? Ku("internal-select-menu", zi((() => e.size[0])), x, e) : void 0,
                        S = {
                            selfRef: i,
                            next: function() {
                                const {
                                    value: e
                                } = u;
                                e && m(e.getNext({
                                    loop: !0
                                }), !0)
                            },
                            prev: function() {
                                const {
                                    value: e
                                } = u;
                                e && m(e.getPrev({
                                    loop: !0
                                }), !0)
                            },
                            getPendingTmNode: function() {
                                const {
                                    value: e
                                } = u;
                                return e || null
                            }
                        };
                    return Pm(i, e.onResize), Object.assign({
                        mergedTheme: r,
                        mergedClsPrefix: t,
                        rtlEnabled: o,
                        virtualListRef: l,
                        scrollbarRef: a,
                        itemSize: p,
                        padding: h,
                        flattenedNodes: s,
                        empty: g,
                        virtualListContainer() {
                            const {
                                value: e
                            } = l;
                            return null == e ? void 0 : e.listElRef
                        },
                        virtualListContent() {
                            const {
                                value: e
                            } = l;
                            return null == e ? void 0 : e.itemsElRef
                        },
                        doScroll: b,
                        handleFocusin: function(t) {
                            var n, o;
                            (null === (n = i.value) || void 0 === n ? void 0 : n.contains(t.target)) && (null === (o = e.onFocus) || void 0 === o || o.call(e, t))
                        },
                        handleFocusout: function(t) {
                            var n, o;
                            (null === (n = i.value) || void 0 === n ? void 0 : n.contains(t.relatedTarget)) || null === (o = e.onBlur) || void 0 === o || o.call(e, t)
                        },
                        handleKeyUp: function(t) {
                            var n;
                            Dh(t, "action") || null === (n = e.onKeyup) || void 0 === n || n.call(e, t)
                        },
                        handleKeyDown: function(t) {
                            var n;
                            Dh(t, "action") || null === (n = e.onKeydown) || void 0 === n || n.call(e, t)
                        },
                        handleMouseDown: function(t) {
                            var n;
                            null === (n = e.onMousedown) || void 0 === n || n.call(e, t), e.focusable || t.preventDefault()
                        },
                        handleVirtualListResize: function() {
                            var e;
                            null === (e = a.value) || void 0 === e || e.sync()
                        },
                        handleVirtualListScroll: function(e) {
                            var t;
                            null === (t = a.value) || void 0 === t || t.sync(), b(e)
                        },
                        cssVars: w ? void 0 : x,
                        themeClass: null == C ? void 0 : C.themeClass,
                        onRender: null == C ? void 0 : C.onRender
                    }, S)
                },
                render() {
                    const {
                        $slots: e,
                        virtualScroll: t,
                        clsPrefix: n,
                        mergedTheme: o,
                        themeClass: r,
                        onRender: i
                    } = this;
                    return null == i || i(), Ti("div", {
                        ref: "selfRef",
                        tabindex: this.focusable ? 0 : -1,
                        class: [`${n}-base-select-menu`, this.rtlEnabled && `${n}-base-select-menu--rtl`, r, this.multiple && `${n}-base-select-menu--multiple`],
                        style: this.cssVars,
                        onFocusin: this.handleFocusin,
                        onFocusout: this.handleFocusout,
                        onKeyup: this.handleKeyUp,
                        onKeydown: this.handleKeyDown,
                        onMousedown: this.handleMouseDown,
                        onMouseenter: this.onMouseenter,
                        onMouseleave: this.onMouseleave
                    }, dd(e.header, (e => e && Ti("div", {
                        class: `${n}-base-select-menu__header`,
                        "data-header": !0,
                        key: "header"
                    }, e))), this.loading ? Ti("div", {
                        class: `${n}-base-select-menu__loading`
                    }, Ti(od, {
                        clsPrefix: n,
                        strokeWidth: 20
                    })) : this.empty ? Ti("div", {
                        class: `${n}-base-select-menu__empty`,
                        "data-empty": !0
                    }, cd(e.empty, (() => [Ti(Um, {
                        theme: o.peers.Empty,
                        themeOverrides: o.peerOverrides.Empty
                    })]))) : Ti(Cp, {
                        ref: "scrollbarRef",
                        theme: o.peers.Scrollbar,
                        themeOverrides: o.peerOverrides.Scrollbar,
                        scrollable: this.scrollable,
                        container: t ? this.virtualListContainer : void 0,
                        content: t ? this.virtualListContent : void 0,
                        onScroll: t ? void 0 : this.doScroll
                    }, {
                        default: () => t ? Ti(Nm, {
                            ref: "virtualListRef",
                            class: `${n}-virtual-list`,
                            items: this.flattenedNodes,
                            itemSize: this.itemSize,
                            showScrollbar: !1,
                            paddingTop: this.padding.top,
                            paddingBottom: this.padding.bottom,
                            onResize: this.handleVirtualListResize,
                            onScroll: this.handleVirtualListScroll,
                            itemResizable: !0
                        }, {
                            default: ({
                                item: e
                            }) => e.isGroup ? Ti(Qm, {
                                key: e.key,
                                clsPrefix: n,
                                tmNode: e
                            }) : e.ignored ? null : Ti(Jm, {
                                clsPrefix: n,
                                key: e.key,
                                tmNode: e
                            })
                        }) : Ti("div", {
                            class: `${n}-base-select-menu-option-wrapper`,
                            style: {
                                paddingTop: this.padding.top,
                                paddingBottom: this.padding.bottom
                            }
                        }, this.flattenedNodes.map((e => e.isGroup ? Ti(Qm, {
                            key: e.key,
                            clsPrefix: n,
                            tmNode: e
                        }) : Ti(Jm, {
                            clsPrefix: n,
                            key: e.key,
                            tmNode: e
                        }))))
                    }), dd(e.action, (e => e && [Ti("div", {
                        class: `${n}-base-select-menu__action`,
                        "data-action": !0,
                        key: "action"
                    }, e), Ti(Km, {
                        onFocus: this.onTabOut,
                        key: "focus-detector"
                    })])))
                }
            });
        var iy = {
            name: "Select",
            common: of,
            peers: {
                InternalSelection: Rm,
                InternalSelectMenu: Xm
            },
            self: function(e) {
                const {
                    boxShadow2: t
                } = e;
                return {
                    menuBoxShadow: t
                }
            }
        };

        function ly(e) {
            return "group" === e.type
        }

        function ay(e) {
            return "ignored" === e.type
        }

        function sy(e, t) {
            try {
                return !!(1 + t.toString().toLowerCase().indexOf(e.trim().toLowerCase()))
            } catch (e) {
                return !1
            }
        }
        var cy = Fu([Ru("select", "\n z-index: auto;\n outline: none;\n width: 100%;\n position: relative;\n "), Ru("select-menu", "\n margin: 4px 0;\n box-shadow: var(--n-menu-box-shadow);\n ", [ny({
            originalTransition: "background-color .3s var(--n-bezier), box-shadow .3s var(--n-bezier)"
        })])]);
        var uy = Tn({
                name: "Select",
                props: Object.assign(Object.assign({}, Vu.props), {
                    to: fg.propTo,
                    bordered: {
                        type: Boolean,
                        default: void 0
                    },
                    clearable: Boolean,
                    clearFilterAfterSelect: {
                        type: Boolean,
                        default: !0
                    },
                    options: {
                        type: Array,
                        default: () => []
                    },
                    defaultValue: {
                        type: [String, Number, Array],
                        default: null
                    },
                    keyboard: {
                        type: Boolean,
                        default: !0
                    },
                    value: [String, Number, Array],
                    placeholder: String,
                    menuProps: Object,
                    multiple: Boolean,
                    size: String,
                    filterable: Boolean,
                    disabled: {
                        type: Boolean,
                        default: void 0
                    },
                    remote: Boolean,
                    loading: Boolean,
                    filter: Function,
                    placement: {
                        type: String,
                        default: "bottom-start"
                    },
                    widthMode: {
                        type: String,
                        default: "trigger"
                    },
                    tag: Boolean,
                    onCreate: Function,
                    fallbackOption: {
                        type: [Function, Boolean],
                        default: void 0
                    },
                    show: {
                        type: Boolean,
                        default: void 0
                    },
                    showArrow: {
                        type: Boolean,
                        default: !0
                    },
                    maxTagCount: [Number, String],
                    ellipsisTagPopoverProps: Object,
                    consistentMenuWidth: {
                        type: Boolean,
                        default: !0
                    },
                    virtualScroll: {
                        type: Boolean,
                        default: !0
                    },
                    labelField: {
                        type: String,
                        default: "label"
                    },
                    valueField: {
                        type: String,
                        default: "value"
                    },
                    childrenField: {
                        type: String,
                        default: "children"
                    },
                    renderLabel: Function,
                    renderOption: Function,
                    renderTag: Function,
                    "onUpdate:value": [Function, Array],
                    inputProps: Object,
                    nodeProps: Function,
                    ignoreComposition: {
                        type: Boolean,
                        default: !0
                    },
                    showOnFocus: Boolean,
                    onUpdateValue: [Function, Array],
                    onBlur: [Function, Array],
                    onClear: [Function, Array],
                    onFocus: [Function, Array],
                    onScroll: [Function, Array],
                    onSearch: [Function, Array],
                    onUpdateShow: [Function, Array],
                    "onUpdate:show": [Function, Array],
                    displayDirective: {
                        type: String,
                        default: "show"
                    },
                    resetMenuOnOptionsChange: {
                        type: Boolean,
                        default: !0
                    },
                    status: String,
                    showCheckmark: {
                        type: Boolean,
                        default: !0
                    },
                    onChange: [Function, Array],
                    items: Array
                }),
                setup(e) {
                    const {
                        mergedClsPrefixRef: t,
                        mergedBorderedRef: n,
                        namespaceRef: o,
                        inlineThemeDisabled: r
                    } = zc(e), i = Vu("Select", "-select", cy, iy, e, t), l = Ft(e.defaultValue), a = df(Dt(e, "value"), l), s = Ft(!1), c = Ft(""), u = ng(e, ["items", "options"]), d = Ft([]), f = Ft([]), p = zi((() => f.value.concat(d.value).concat(u.value))), h = zi((() => {
                        const {
                            filter: t
                        } = e;
                        if (t) return t;
                        const {
                            labelField: n,
                            valueField: o
                        } = e;
                        return (e, t) => {
                            if (!t) return !1;
                            const r = t[n];
                            if ("string" == typeof r) return sy(e, r);
                            const i = t[o];
                            return "string" == typeof i ? sy(e, i) : "number" == typeof i && sy(e, String(i))
                        }
                    })), v = zi((() => {
                        if (e.remote) return u.value;
                        {
                            const {
                                value: t
                            } = p, {
                                value: n
                            } = c;
                            return n.length && e.filterable ? function(e, t, n, o) {
                                return t ? function e(r) {
                                    if (!Array.isArray(r)) return [];
                                    const i = [];
                                    for (const l of r)
                                        if (ly(l)) {
                                            const t = e(l[o]);
                                            t.length && i.push(Object.assign({}, l, {
                                                [o]: t
                                            }))
                                        } else {
                                            if (ay(l)) continue;
                                            t(n, l) && i.push(l)
                                        } return i
                                }(e) : e
                            }(t, h.value, n, e.childrenField) : t
                        }
                    })), g = zi((() => {
                        const {
                            valueField: t,
                            childrenField: n
                        } = e, o = function(e, t) {
                            return {
                                getIsGroup: ly,
                                getIgnored: ay,
                                getKey(t) {
                                    return ly(t) ? t.name || t.key || "key-required" : t[e]
                                },
                                getChildren(e) {
                                    return e[t]
                                }
                            }
                        }(t, n);
                        return xv(v.value, o)
                    })), b = zi((() => function(e, t, n) {
                        const o = new Map;
                        return e.forEach((e => {
                            ly(e) ? e[n].forEach((e => {
                                o.set(e[t], e)
                            })) : o.set(e[t], e)
                        })), o
                    }(p.value, e.valueField, e.childrenField))), m = Ft(!1), y = df(Dt(e, "show"), m), x = Ft(null), w = Ft(null), C = Ft(null), {
                        localeRef: S
                    } = bh("Select"), k = zi((() => {
                        var t;
                        return null !== (t = e.placeholder) && void 0 !== t ? t : S.value.placeholder
                    })), $ = [], _ = Ft(new Map), z = zi((() => {
                        const {
                            fallbackOption: t
                        } = e;
                        if (void 0 === t) {
                            const {
                                labelField: t,
                                valueField: n
                            } = e;
                            return e => ({
                                [t]: String(e),
                                [n]: e
                            })
                        }
                        return !1 !== t && (e => Object.assign(t(e), {
                            value: e
                        }))
                    }));

                    function T(t) {
                        const n = e.remote,
                            {
                                value: o
                            } = _,
                            {
                                value: r
                            } = b,
                            {
                                value: i
                            } = z,
                            l = [];
                        return t.forEach((e => {
                            if (r.has(e)) l.push(r.get(e));
                            else if (n && o.has(e)) l.push(o.get(e));
                            else if (i) {
                                const t = i(e);
                                t && l.push(t)
                            }
                        })), l
                    }
                    const P = zi((() => {
                            if (e.multiple) {
                                const {
                                    value: e
                                } = a;
                                return Array.isArray(e) ? T(e) : []
                            }
                            return null
                        })),
                        F = zi((() => {
                            const {
                                value: t
                            } = a;
                            return e.multiple || Array.isArray(t) || null === t ? null : T([t])[0] || null
                        })),
                        M = Uu(e),
                        {
                            mergedSizeRef: R,
                            mergedDisabledRef: E,
                            mergedStatusRef: O
                        } = M;

                    function B(t, n) {
                        const {
                            onChange: o,
                            "onUpdate:value": r,
                            onUpdateValue: i
                        } = e, {
                            nTriggerFormChange: a,
                            nTriggerFormInput: s
                        } = M;
                        o && ld(o, t, n), i && ld(i, t, n), r && ld(r, t, n), l.value = t, a(), s()
                    }

                    function A(t) {
                        const {
                            onBlur: n
                        } = e, {
                            nTriggerFormBlur: o
                        } = M;
                        n && ld(n, t), o()
                    }

                    function I() {
                        var t;
                        const {
                            remote: n,
                            multiple: o
                        } = e;
                        if (n) {
                            const {
                                value: n
                            } = _;
                            if (o) {
                                const {
                                    valueField: o
                                } = e;
                                null === (t = P.value) || void 0 === t || t.forEach((e => {
                                    n.set(e[o], e)
                                }))
                            } else {
                                const t = F.value;
                                t && n.set(t[e.valueField], t)
                            }
                        }
                    }

                    function D(t) {
                        const {
                            onUpdateShow: n,
                            "onUpdate:show": o
                        } = e;
                        n && ld(n, t), o && ld(o, t), m.value = t
                    }

                    function L() {
                        E.value || (D(!0), m.value = !0, e.filterable && G())
                    }

                    function j() {
                        D(!1)
                    }

                    function N() {
                        c.value = "", f.value = $
                    }
                    const H = Ft(!1);

                    function W(e) {
                        V(e.rawNode)
                    }

                    function V(t) {
                        if (E.value) return;
                        const {
                            tag: n,
                            remote: o,
                            clearFilterAfterSelect: r,
                            valueField: i
                        } = e;
                        if (n && !o) {
                            const {
                                value: e
                            } = f, t = e[0] || null;
                            if (t) {
                                const e = d.value;
                                e.length ? e.push(t) : d.value = [t], f.value = $
                            }
                        }
                        if (o && _.value.set(t[i], t), e.multiple) {
                            const l = function(t) {
                                    if (!Array.isArray(t)) return [];
                                    if (z.value) return Array.from(t);
                                    {
                                        const {
                                            remote: n
                                        } = e, {
                                            value: o
                                        } = b;
                                        if (n) {
                                            const {
                                                value: e
                                            } = _;
                                            return t.filter((t => o.has(t) || e.has(t)))
                                        }
                                        return t.filter((e => o.has(e)))
                                    }
                                }(a.value),
                                s = l.findIndex((e => e === t[i]));
                            if (~s) {
                                if (l.splice(s, 1), n && !o) {
                                    const e = q(t[i]);
                                    ~e && (d.value.splice(e, 1), r && (c.value = ""))
                                }
                            } else l.push(t[i]), r && (c.value = "");
                            B(l, T(l))
                        } else {
                            if (n && !o) {
                                const e = q(t[i]);
                                d.value = ~e ? [d.value[e]] : $
                            }
                            K(), j(), B(t[i], t)
                        }
                    }

                    function q(t) {
                        return d.value.findIndex((n => n[e.valueField] === t))
                    }

                    function U(t) {
                        var n, o, r, i, l, s;
                        if (e.keyboard) switch (t.key) {
                            case " ":
                                if (e.filterable) break;
                                t.preventDefault();
                            case "Enter":
                                if (!(null === (n = x.value) || void 0 === n ? void 0 : n.isComposing))
                                    if (y.value) {
                                        const t = null === (o = C.value) || void 0 === o ? void 0 : o.getPendingTmNode();
                                        t ? W(t) : e.filterable || (j(), K())
                                    } else if (L(), e.tag && H.value) {
                                    const t = f.value[0];
                                    if (t) {
                                        const n = t[e.valueField],
                                            {
                                                value: o
                                            } = a;
                                        e.multiple && Array.isArray(o) && o.includes(n) || V(t)
                                    }
                                }
                                t.preventDefault();
                                break;
                            case "ArrowUp":
                                if (t.preventDefault(), e.loading) return;
                                y.value && (null === (r = C.value) || void 0 === r || r.prev());
                                break;
                            case "ArrowDown":
                                if (t.preventDefault(), e.loading) return;
                                y.value ? null === (i = C.value) || void 0 === i || i.next() : L();
                                break;
                            case "Escape":
                                y.value && (s = t, pg.add(s), j()), null === (l = x.value) || void 0 === l || l.focus()
                        } else t.preventDefault()
                    }

                    function K() {
                        var e;
                        null === (e = x.value) || void 0 === e || e.focus()
                    }

                    function G() {
                        var e;
                        null === (e = x.value) || void 0 === e || e.focusInput()
                    }
                    I(), vr(Dt(e, "options"), I);
                    const X = {
                            focus: () => {
                                var e;
                                null === (e = x.value) || void 0 === e || e.focus()
                            },
                            focusInput: () => {
                                var e;
                                null === (e = x.value) || void 0 === e || e.focusInput()
                            },
                            blur: () => {
                                var e;
                                null === (e = x.value) || void 0 === e || e.blur()
                            },
                            blurInput: () => {
                                var e;
                                null === (e = x.value) || void 0 === e || e.blurInput()
                            }
                        },
                        Y = zi((() => {
                            const {
                                self: {
                                    menuBoxShadow: e
                                }
                            } = i.value;
                            return {
                                "--n-menu-box-shadow": e
                            }
                        })),
                        Z = r ? Ku("select", void 0, Y, e) : void 0;
                    return Object.assign(Object.assign({}, X), {
                        mergedStatus: O,
                        mergedClsPrefix: t,
                        mergedBordered: n,
                        namespace: o,
                        treeMate: g,
                        isMounted: Xu(),
                        triggerRef: x,
                        menuRef: C,
                        pattern: c,
                        uncontrolledShow: m,
                        mergedShow: y,
                        adjustedTo: fg(e),
                        uncontrolledValue: l,
                        mergedValue: a,
                        followerRef: w,
                        localizedPlaceholder: k,
                        selectedOption: F,
                        selectedOptions: P,
                        mergedSize: R,
                        mergedDisabled: E,
                        focused: s,
                        activeWithoutMenuOpen: H,
                        inlineThemeDisabled: r,
                        onTriggerInputFocus: function() {
                            e.filterable && (H.value = !0)
                        },
                        onTriggerInputBlur: function() {
                            e.filterable && (H.value = !1, y.value || N())
                        },
                        handleTriggerOrMenuResize: function() {
                            var e;
                            y.value && (null === (e = w.value) || void 0 === e || e.syncPosition())
                        },
                        handleMenuFocus: function() {
                            s.value = !0
                        },
                        handleMenuBlur: function(e) {
                            var t;
                            (null === (t = x.value) || void 0 === t ? void 0 : t.$el.contains(e.relatedTarget)) || (s.value = !1, A(e), j())
                        },
                        handleMenuTabOut: function() {
                            var e;
                            null === (e = x.value) || void 0 === e || e.focus(), j()
                        },
                        handleTriggerClick: function() {
                            E.value || (y.value ? e.filterable ? G() : j() : L())
                        },
                        handleToggle: W,
                        handleDeleteOption: V,
                        handlePatternInput: function(t) {
                            y.value || L();
                            const {
                                value: n
                            } = t.target;
                            c.value = n;
                            const {
                                tag: o,
                                remote: r
                            } = e;
                            if (function(t) {
                                    const {
                                        onSearch: n
                                    } = e;
                                    n && ld(n, t)
                                }(n), o && !r) {
                                if (!n) return void(f.value = $);
                                const {
                                    onCreate: t
                                } = e, o = t ? t(n) : {
                                    [e.labelField]: n,
                                    [e.valueField]: n
                                }, {
                                    valueField: r,
                                    labelField: i
                                } = e;
                                u.value.some((e => e[r] === o[r] || e[i] === o[i])) || d.value.some((e => e[r] === o[r] || e[i] === o[i])) ? f.value = $ : f.value = [o]
                            }
                        },
                        handleClear: function(t) {
                            t.stopPropagation();
                            const {
                                multiple: n
                            } = e;
                            !n && e.filterable && j(),
                                function() {
                                    const {
                                        onClear: t
                                    } = e;
                                    t && ld(t)
                                }(), n ? B([], []) : B(null, null)
                        },
                        handleTriggerBlur: function(e) {
                            var t, n;
                            (null === (n = null === (t = C.value) || void 0 === t ? void 0 : t.selfRef) || void 0 === n ? void 0 : n.contains(e.relatedTarget)) || (s.value = !1, A(e), j())
                        },
                        handleTriggerFocus: function(t) {
                            ! function(t) {
                                const {
                                    onFocus: n,
                                    showOnFocus: o
                                } = e, {
                                    nTriggerFormFocus: r
                                } = M;
                                n && ld(n, t), r(), o && L()
                            }(t), s.value = !0
                        },
                        handleKeydown: U,
                        handleMenuAfterLeave: N,
                        handleMenuClickOutside: function(e) {
                            var t;
                            y.value && ((null === (t = x.value) || void 0 === t ? void 0 : t.$el.contains(hp(e))) || j())
                        },
                        handleMenuScroll: function(t) {
                            ! function(t) {
                                const {
                                    onScroll: n
                                } = e;
                                n && ld(n, t)
                            }(t)
                        },
                        handleMenuKeydown: U,
                        handleMenuMousedown: function(e) {
                            Dh(e, "action") || Dh(e, "empty") || Dh(e, "header") || e.preventDefault()
                        },
                        mergedTheme: i,
                        cssVars: r ? void 0 : Y,
                        themeClass: null == Z ? void 0 : Z.themeClass,
                        onRender: null == Z ? void 0 : Z.onRender
                    })
                },
                render() {
                    return Ti("div", {
                        class: `${this.mergedClsPrefix}-select`
                    }, Ti(Ev, null, {
                        default: () => [Ti(Ov, null, {
                            default: () => Ti(Om, {
                                ref: "triggerRef",
                                inlineThemeDisabled: this.inlineThemeDisabled,
                                status: this.mergedStatus,
                                inputProps: this.inputProps,
                                clsPrefix: this.mergedClsPrefix,
                                showArrow: this.showArrow,
                                maxTagCount: this.maxTagCount,
                                ellipsisTagPopoverProps: this.ellipsisTagPopoverProps,
                                bordered: this.mergedBordered,
                                active: this.activeWithoutMenuOpen || this.mergedShow,
                                pattern: this.pattern,
                                placeholder: this.localizedPlaceholder,
                                selectedOption: this.selectedOption,
                                selectedOptions: this.selectedOptions,
                                multiple: this.multiple,
                                renderTag: this.renderTag,
                                renderLabel: this.renderLabel,
                                filterable: this.filterable,
                                clearable: this.clearable,
                                disabled: this.mergedDisabled,
                                size: this.mergedSize,
                                theme: this.mergedTheme.peers.InternalSelection,
                                labelField: this.labelField,
                                valueField: this.valueField,
                                themeOverrides: this.mergedTheme.peerOverrides.InternalSelection,
                                loading: this.loading,
                                focused: this.focused,
                                onClick: this.handleTriggerClick,
                                onDeleteOption: this.handleDeleteOption,
                                onPatternInput: this.handlePatternInput,
                                onClear: this.handleClear,
                                onBlur: this.handleTriggerBlur,
                                onFocus: this.handleTriggerFocus,
                                onKeydown: this.handleKeydown,
                                onPatternBlur: this.onTriggerInputBlur,
                                onPatternFocus: this.onTriggerInputFocus,
                                onResize: this.handleTriggerOrMenuResize,
                                ignoreComposition: this.ignoreComposition
                            }, {
                                arrow: () => {
                                    var e, t;
                                    return [null === (t = (e = this.$slots).arrow) || void 0 === t ? void 0 : t.call(e)]
                                }
                            })
                        }), Ti(tg, {
                            ref: "followerRef",
                            show: this.mergedShow,
                            to: this.adjustedTo,
                            teleportDisabled: this.adjustedTo === fg.tdkey,
                            containerClass: this.namespace,
                            width: this.consistentMenuWidth ? "target" : void 0,
                            minWidth: "target",
                            placement: this.placement
                        }, {
                            default: () => Ti(Ai, {
                                name: "fade-in-scale-up-transition",
                                appear: this.isMounted,
                                onAfterLeave: this.handleMenuAfterLeave
                            }, {
                                default: () => {
                                    var e, t, n;
                                    return this.mergedShow || "show" === this.displayDirective ? (null === (e = this.onRender) || void 0 === e || e.call(this), fn(Ti(ry, Object.assign({}, this.menuProps, {
                                        ref: "menuRef",
                                        onResize: this.handleTriggerOrMenuResize,
                                        inlineThemeDisabled: this.inlineThemeDisabled,
                                        virtualScroll: this.consistentMenuWidth && this.virtualScroll,
                                        class: [`${this.mergedClsPrefix}-select-menu`, this.themeClass, null === (t = this.menuProps) || void 0 === t ? void 0 : t.class],
                                        clsPrefix: this.mergedClsPrefix,
                                        focusable: !0,
                                        labelField: this.labelField,
                                        valueField: this.valueField,
                                        autoPending: !0,
                                        nodeProps: this.nodeProps,
                                        theme: this.mergedTheme.peers.InternalSelectMenu,
                                        themeOverrides: this.mergedTheme.peerOverrides.InternalSelectMenu,
                                        treeMate: this.treeMate,
                                        multiple: this.multiple,
                                        size: "medium",
                                        renderOption: this.renderOption,
                                        renderLabel: this.renderLabel,
                                        value: this.mergedValue,
                                        style: [null === (n = this.menuProps) || void 0 === n ? void 0 : n.style, this.cssVars],
                                        onToggle: this.handleToggle,
                                        onScroll: this.handleMenuScroll,
                                        onFocus: this.handleMenuFocus,
                                        onBlur: this.handleMenuBlur,
                                        onKeydown: this.handleMenuKeydown,
                                        onTabOut: this.handleMenuTabOut,
                                        onMousedown: this.handleMenuMousedown,
                                        show: this.mergedShow,
                                        showCheckmark: this.showCheckmark,
                                        resetMenuOnOptionsChange: this.resetMenuOnOptionsChange
                                    }), {
                                        empty: () => {
                                            var e, t;
                                            return [null === (t = (e = this.$slots).empty) || void 0 === t ? void 0 : t.call(e)]
                                        },
                                        header: () => {
                                            var e, t;
                                            return [null === (t = (e = this.$slots).header) || void 0 === t ? void 0 : t.call(e)]
                                        },
                                        action: () => {
                                            var e, t;
                                            return [null === (t = (e = this.$slots).action) || void 0 === t ? void 0 : t.call(e)]
                                        }
                                    }), "show" === this.displayDirective ? [
                                        [el, this.mergedShow],
                                        [ig, this.handleMenuClickOutside, void 0, {
                                            capture: !0
                                        }]
                                    ] : [
                                        [ig, this.handleMenuClickOutside, void 0, {
                                            capture: !0
                                        }]
                                    ])) : null
                                }
                            })
                        })]
                    }))
                }
            }),
            dy = {
                buttonHeightSmall: "14px",
                buttonHeightMedium: "18px",
                buttonHeightLarge: "22px",
                buttonWidthSmall: "14px",
                buttonWidthMedium: "18px",
                buttonWidthLarge: "22px",
                buttonWidthPressedSmall: "20px",
                buttonWidthPressedMedium: "24px",
                buttonWidthPressedLarge: "28px",
                railHeightSmall: "18px",
                railHeightMedium: "22px",
                railHeightLarge: "26px",
                railWidthSmall: "32px",
                railWidthMedium: "40px",
                railWidthLarge: "48px"
            };
        var fy = {
                name: "Switch",
                common: of,
                self: function(e) {
                    const {
                        primaryColor: t,
                        opacityDisabled: n,
                        borderRadius: o,
                        textColor3: r
                    } = e;
                    return Object.assign(Object.assign({}, dy), {
                        iconColor: r,
                        textColor: "white",
                        loadingColor: t,
                        opacityDisabled: n,
                        railColor: "rgba(0, 0, 0, .14)",
                        railColorActive: t,
                        buttonBoxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.3), inset 0 0 1px 0 rgba(0, 0, 0, 0.05)",
                        buttonColor: "#FFF",
                        railBorderRadiusSmall: o,
                        railBorderRadiusMedium: o,
                        railBorderRadiusLarge: o,
                        buttonBorderRadiusSmall: o,
                        buttonBorderRadiusMedium: o,
                        buttonBorderRadiusLarge: o,
                        boxShadowFocus: `0 0 0 2px ${Kc(t,{alpha:.2})}`
                    })
                }
            },
            py = Ru("switch", "\n height: var(--n-height);\n min-width: var(--n-width);\n vertical-align: middle;\n user-select: none;\n -webkit-user-select: none;\n display: inline-flex;\n outline: none;\n justify-content: center;\n align-items: center;\n", [Eu("children-placeholder", "\n height: var(--n-rail-height);\n display: flex;\n flex-direction: column;\n overflow: hidden;\n pointer-events: none;\n visibility: hidden;\n "), Eu("rail-placeholder", "\n display: flex;\n flex-wrap: none;\n "), Eu("button-placeholder", "\n width: calc(1.75 * var(--n-rail-height));\n height: var(--n-rail-height);\n "), Ru("base-loading", "\n position: absolute;\n top: 50%;\n left: 50%;\n transform: translateX(-50%) translateY(-50%);\n font-size: calc(var(--n-button-width) - 4px);\n color: var(--n-loading-color);\n transition: color .3s var(--n-bezier);\n ", [Qu({
                left: "50%",
                top: "50%",
                originalTransform: "translateX(-50%) translateY(-50%)"
            })]), Eu("checked, unchecked", "\n transition: color .3s var(--n-bezier);\n color: var(--n-text-color);\n box-sizing: border-box;\n position: absolute;\n white-space: nowrap;\n top: 0;\n bottom: 0;\n display: flex;\n align-items: center;\n line-height: 1;\n "), Eu("checked", "\n right: 0;\n padding-right: calc(1.25 * var(--n-rail-height) - var(--n-offset));\n "), Eu("unchecked", "\n left: 0;\n justify-content: flex-end;\n padding-left: calc(1.25 * var(--n-rail-height) - var(--n-offset));\n "), Fu("&:focus", [Eu("rail", "\n box-shadow: var(--n-box-shadow-focus);\n ")]), Ou("round", [Eu("rail", "border-radius: calc(var(--n-rail-height) / 2);", [Eu("button", "border-radius: calc(var(--n-button-height) / 2);")])]), Bu("disabled", [Bu("icon", [Ou("rubber-band", [Ou("pressed", [Eu("rail", [Eu("button", "max-width: var(--n-button-width-pressed);")])]), Eu("rail", [Fu("&:active", [Eu("button", "max-width: var(--n-button-width-pressed);")])]), Ou("active", [Ou("pressed", [Eu("rail", [Eu("button", "left: calc(100% - var(--n-offset) - var(--n-button-width-pressed));")])]), Eu("rail", [Fu("&:active", [Eu("button", "left: calc(100% - var(--n-offset) - var(--n-button-width-pressed));")])])])])])]), Ou("active", [Eu("rail", [Eu("button", "left: calc(100% - var(--n-button-width) - var(--n-offset))")])]), Eu("rail", "\n overflow: hidden;\n height: var(--n-rail-height);\n min-width: var(--n-rail-width);\n border-radius: var(--n-rail-border-radius);\n cursor: pointer;\n position: relative;\n transition:\n opacity .3s var(--n-bezier),\n background .3s var(--n-bezier),\n box-shadow .3s var(--n-bezier);\n background-color: var(--n-rail-color);\n ", [Eu("button-icon", "\n color: var(--n-icon-color);\n transition: color .3s var(--n-bezier);\n font-size: calc(var(--n-button-height) - 4px);\n position: absolute;\n left: 0;\n right: 0;\n top: 0;\n bottom: 0;\n display: flex;\n justify-content: center;\n align-items: center;\n line-height: 1;\n ", [Qu()]), Eu("button", '\n align-items: center; \n top: var(--n-offset);\n left: var(--n-offset);\n height: var(--n-button-height);\n width: var(--n-button-width-pressed);\n max-width: var(--n-button-width);\n border-radius: var(--n-button-border-radius);\n background-color: var(--n-button-color);\n box-shadow: var(--n-button-box-shadow);\n box-sizing: border-box;\n cursor: inherit;\n content: "";\n position: absolute;\n transition:\n background-color .3s var(--n-bezier),\n left .3s var(--n-bezier),\n opacity .3s var(--n-bezier),\n max-width .3s var(--n-bezier),\n box-shadow .3s var(--n-bezier);\n ')]), Ou("active", [Eu("rail", "background-color: var(--n-rail-color-active);")]), Ou("loading", [Eu("rail", "\n cursor: wait;\n ")]), Ou("disabled", [Eu("rail", "\n cursor: not-allowed;\n opacity: .5;\n ")])]);
        let hy;
        var vy = Tn({
                name: "Switch",
                props: Object.assign(Object.assign({}, Vu.props), {
                    size: {
                        type: String,
                        default: "medium"
                    },
                    value: {
                        type: [String, Number, Boolean],
                        default: void 0
                    },
                    loading: Boolean,
                    defaultValue: {
                        type: [String, Number, Boolean],
                        default: !1
                    },
                    disabled: {
                        type: Boolean,
                        default: void 0
                    },
                    round: {
                        type: Boolean,
                        default: !0
                    },
                    "onUpdate:value": [Function, Array],
                    onUpdateValue: [Function, Array],
                    checkedValue: {
                        type: [String, Number, Boolean],
                        default: !0
                    },
                    uncheckedValue: {
                        type: [String, Number, Boolean],
                        default: !1
                    },
                    railStyle: Function,
                    rubberBand: {
                        type: Boolean,
                        default: !0
                    },
                    onChange: [Function, Array]
                }),
                setup(e) {
                    void 0 === hy && (hy = "undefined" == typeof CSS || void 0 !== CSS.supports && CSS.supports("width", "max(1px)"));
                    const {
                        mergedClsPrefixRef: t,
                        inlineThemeDisabled: n
                    } = zc(e), o = Vu("Switch", "-switch", py, fy, e, t), r = Uu(e), {
                        mergedSizeRef: i,
                        mergedDisabledRef: l
                    } = r, a = Ft(e.defaultValue), s = df(Dt(e, "value"), a), c = zi((() => s.value === e.checkedValue)), u = Ft(!1), d = Ft(!1), f = zi((() => {
                        const {
                            railStyle: t
                        } = e;
                        if (t) return t({
                            focused: d.value,
                            checked: c.value
                        })
                    }));

                    function p(t) {
                        const {
                            "onUpdate:value": n,
                            onChange: o,
                            onUpdateValue: i
                        } = e, {
                            nTriggerFormInput: l,
                            nTriggerFormChange: s
                        } = r;
                        n && ld(n, t), i && ld(i, t), o && ld(o, t), a.value = t, l(), s()
                    }
                    const h = zi((() => {
                            const {
                                value: e
                            } = i, {
                                self: {
                                    opacityDisabled: t,
                                    railColor: n,
                                    railColorActive: r,
                                    buttonBoxShadow: l,
                                    buttonColor: a,
                                    boxShadowFocus: s,
                                    loadingColor: c,
                                    textColor: u,
                                    iconColor: d,
                                    [Iu("buttonHeight", e)]: f,
                                    [Iu("buttonWidth", e)]: p,
                                    [Iu("buttonWidthPressed", e)]: h,
                                    [Iu("railHeight", e)]: v,
                                    [Iu("railWidth", e)]: g,
                                    [Iu("railBorderRadius", e)]: b,
                                    [Iu("buttonBorderRadius", e)]: m
                                },
                                common: {
                                    cubicBezierEaseInOut: y
                                }
                            } = o.value;
                            let x, w, C;
                            return hy ? (x = `calc((${v} - ${f}) / 2)`, w = `max(${v}, ${f})`, C = `max(${g}, calc(${g} + ${f} - ${v}))`) : (x = pf((ff(v) - ff(f)) / 2), w = pf(Math.max(ff(v), ff(f))), C = ff(v) > ff(f) ? g : pf(ff(g) + ff(f) - ff(v))), {
                                "--n-bezier": y,
                                "--n-button-border-radius": m,
                                "--n-button-box-shadow": l,
                                "--n-button-color": a,
                                "--n-button-width": p,
                                "--n-button-width-pressed": h,
                                "--n-button-height": f,
                                "--n-height": w,
                                "--n-offset": x,
                                "--n-opacity-disabled": t,
                                "--n-rail-border-radius": b,
                                "--n-rail-color": n,
                                "--n-rail-color-active": r,
                                "--n-rail-height": v,
                                "--n-rail-width": g,
                                "--n-width": C,
                                "--n-box-shadow-focus": s,
                                "--n-loading-color": c,
                                "--n-text-color": u,
                                "--n-icon-color": d
                            }
                        })),
                        v = n ? Ku("switch", zi((() => i.value[0])), h, e) : void 0;
                    return {
                        handleClick: function() {
                            e.loading || l.value || (s.value !== e.checkedValue ? p(e.checkedValue) : p(e.uncheckedValue))
                        },
                        handleBlur: function() {
                            d.value = !1,
                                function() {
                                    const {
                                        nTriggerFormBlur: e
                                    } = r;
                                    e()
                                }(), u.value = !1
                        },
                        handleFocus: function() {
                            d.value = !0,
                                function() {
                                    const {
                                        nTriggerFormFocus: e
                                    } = r;
                                    e()
                                }()
                        },
                        handleKeyup: function(t) {
                            e.loading || l.value || " " === t.key && (s.value !== e.checkedValue ? p(e.checkedValue) : p(e.uncheckedValue), u.value = !1)
                        },
                        handleKeydown: function(t) {
                            e.loading || l.value || " " === t.key && (t.preventDefault(), u.value = !0)
                        },
                        mergedRailStyle: f,
                        pressed: u,
                        mergedClsPrefix: t,
                        mergedValue: s,
                        checked: c,
                        mergedDisabled: l,
                        cssVars: n ? void 0 : h,
                        themeClass: null == v ? void 0 : v.themeClass,
                        onRender: null == v ? void 0 : v.onRender
                    }
                },
                render() {
                    const {
                        mergedClsPrefix: e,
                        mergedDisabled: t,
                        checked: n,
                        mergedRailStyle: o,
                        onRender: r,
                        $slots: i
                    } = this;
                    null == r || r();
                    const {
                        checked: l,
                        unchecked: a,
                        icon: s,
                        "checked-icon": c,
                        "unchecked-icon": u
                    } = i, d = !(fd(s) && fd(c) && fd(u));
                    return Ti("div", {
                        role: "switch",
                        "aria-checked": n,
                        class: [`${e}-switch`, this.themeClass, d && `${e}-switch--icon`, n && `${e}-switch--active`, t && `${e}-switch--disabled`, this.round && `${e}-switch--round`, this.loading && `${e}-switch--loading`, this.pressed && `${e}-switch--pressed`, this.rubberBand && `${e}-switch--rubber-band`],
                        tabindex: this.mergedDisabled ? void 0 : 0,
                        style: this.cssVars,
                        onClick: this.handleClick,
                        onFocus: this.handleFocus,
                        onBlur: this.handleBlur,
                        onKeyup: this.handleKeyup,
                        onKeydown: this.handleKeydown
                    }, Ti("div", {
                        class: `${e}-switch__rail`,
                        "aria-hidden": "true",
                        style: o
                    }, dd(l, (t => dd(a, (n => t || n ? Ti("div", {
                        "aria-hidden": !0,
                        class: `${e}-switch__children-placeholder`
                    }, Ti("div", {
                        class: `${e}-switch__rail-placeholder`
                    }, Ti("div", {
                        class: `${e}-switch__button-placeholder`
                    }), t), Ti("div", {
                        class: `${e}-switch__rail-placeholder`
                    }, Ti("div", {
                        class: `${e}-switch__button-placeholder`
                    }), n)) : null)))), Ti("div", {
                        class: `${e}-switch__button`
                    }, dd(s, (t => dd(c, (n => dd(u, (o => Ti(Yu, null, {
                        default: () => this.loading ? Ti(od, {
                            key: "loading",
                            clsPrefix: e,
                            strokeWidth: 20
                        }) : this.checked && (n || t) ? Ti("div", {
                            class: `${e}-switch__button-icon`,
                            key: n ? "checked-icon" : "icon"
                        }, n || t) : this.checked || !o && !t ? null : Ti("div", {
                            class: `${e}-switch__button-icon`,
                            key: o ? "unchecked-icon" : "icon"
                        }, o || t)
                    }))))))), dd(l, (t => t && Ti("div", {
                        key: "checked",
                        class: `${e}-switch__checked`
                    }, t))), dd(a, (t => t && Ti("div", {
                        key: "unchecked",
                        class: `${e}-switch__unchecked`
                    }, t))))))
                }
            }),
            gy = Tn({
                __name: "VueTeleport",
                props: {
                    to: {},
                    disabled: {
                        type: Boolean
                    }
                },
                setup: function(e) {
                    var t = tr,
                        n = e;
                    return function(e, o) {
                        return Ir(), Wr((r = Et(t), k(r) ? Jn(Yn, r, !1) || r : r || Zn), function(e) {
                            if (!e) return null;
                            let {
                                class: t,
                                style: n
                            } = e;
                            return t && !k(t) && (e.class = Q(t)), n && (e.style = G(n)), e
                        }(Zr(n)), {
                            default: dn((function() {
                                return [to(e.$slots, "default")]
                            })),
                            _: 3
                        }, 16);
                        var r
                    }
                }
            });
        var by = gy,
            my = r(461),
            yy = r.n(my);
        var xy = function(e, t, n, o) {
                return new(n || (n = Promise))((function(r, i) {
                    function l(e) {
                        try {
                            s(o.next(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function a(e) {
                        try {
                            s(o.throw(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function s(e) {
                        var t;
                        e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                            e(t)
                        }))).then(l, a)
                    }
                    s((o = o.apply(e, t || [])).next())
                }))
            },
            wy = function(e, t) {
                var n, o, r, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & r[0]) throw r[1];
                        return r[1]
                    },
                    trys: [],
                    ops: []
                };
                return i = {
                    next: a(0),
                    throw: a(1),
                    return: a(2)
                }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                    return this
                }), i;

                function a(a) {
                    return function(s) {
                        return function(a) {
                            if (n) throw new TypeError("Generator is already executing.");
                            for (; i && (i = 0, a[0] && (l = 0)), l;) try {
                                if (n = 1, o && (r = 2 & a[0] ? o.return : a[0] ? o.throw || ((r = o.return) && r.call(o), 0) : o.next) && !(r = r.call(o, a[1])).done) return r;
                                switch (o = 0, r && (a = [2 & a[0], r.value]), a[0]) {
                                    case 0:
                                    case 1:
                                        r = a;
                                        break;
                                    case 4:
                                        return l.label++, {
                                            value: a[1],
                                            done: !1
                                        };
                                    case 5:
                                        l.label++, o = a[1], a = [0];
                                        continue;
                                    case 7:
                                        a = l.ops.pop(), l.trys.pop();
                                        continue;
                                    default:
                                        if (!(r = l.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== a[0] && 2 !== a[0])) {
                                            l = 0;
                                            continue
                                        }
                                        if (3 === a[0] && (!r || a[1] > r[0] && a[1] < r[3])) {
                                            l.label = a[1];
                                            break
                                        }
                                        if (6 === a[0] && l.label < r[1]) {
                                            l.label = r[1], r = a;
                                            break
                                        }
                                        if (r && l.label < r[2]) {
                                            l.label = r[2], l.ops.push(a);
                                            break
                                        }
                                        r[2] && l.ops.pop(), l.trys.pop();
                                        continue
                                }
                                a = t.call(e, l)
                            } catch (e) {
                                a = [6, e], o = 0
                            } finally {
                                n = r = 0
                            }
                            if (5 & a[0]) throw a[1];
                            return {
                                value: a[0] ? a[1] : void 0,
                                done: !0
                            }
                        }([a, s])
                    }
                }
            },
            Cy = function(e) {
                var t = "function" == typeof Symbol && Symbol.iterator,
                    n = t && e[t],
                    o = 0;
                if (n) return n.call(e);
                if (e && "number" == typeof e.length) return {
                    next: function() {
                        return e && o >= e.length && (e = void 0), {
                            value: e && e[o++],
                            done: !e
                        }
                    }
                };
                throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
            },
            Sy = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var o, r, i = n.call(e),
                    l = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(o = i.next()).done;) l.push(o.value)
                } catch (e) {
                    r = {
                        error: e
                    }
                } finally {
                    try {
                        o && !o.done && (n = i.return) && n.call(i)
                    } finally {
                        if (r) throw r.error
                    }
                }
                return l
            },
            ky = function(e, t, n) {
                if (n || 2 === arguments.length)
                    for (var o, r = 0, i = t.length; r < i; r++) !o && r in t || (o || (o = Array.prototype.slice.call(t, 0, r)), o[r] = t[r]);
                return e.concat(o || Array.prototype.slice.call(t))
            },
            $y = function(e) {
                return cn = "data-v-638b8b50", e = e(), cn = null, e
            },
            _y = {
                class: "tc_extension"
            },
            zy = $y((function() {
                return Gr("span", {
                    class: "lui-icon lui-icon--effects"
                }, null, -1)
            })),
            Ty = {
                class: "tc_dialog"
            },
            Py = {
                class: "tc_dialogHeader"
            },
            Fy = $y((function() {
                return Gr("h2", null, "Configure Table", -1)
            })),
            My = $y((function() {
                return Gr("span", {
                    class: "lui-icon lui-icon--close"
                }, null, -1)
            })),
            Ry = {
                style: {
                    "padding-bottom": "10px",
                    display: "flex",
                    gap: "10px"
                }
            },
            Ey = $y((function() {
                return Gr("span", {
                    class: "lui-icon lui-icon--search"
                }, null, -1)
            })),
            Oy = {
                style: {
                    "margin-left": "auto",
                    display: "flex",
                    gap: "10px"
                }
            },
            By = $y((function() {
                return Gr("span", {
                    class: "lui-icon lui-icon--bin"
                }, null, -1)
            })),
            Ay = {
                style: {
                    display: "flex",
                    "flex-flow": "row nowrap",
                    position: "absolute",
                    left: "20px",
                    right: "20px",
                    top: "66px",
                    height: "calc(100% - 77px)"
                }
            },
            Iy = {
                style: {
                    flex: "1",
                    overflow: "auto"
                }
            },
            Dy = $y((function() {
                return Gr("div", {
                    style: {
                        display: "flex",
                        "justify-content": "space-between"
                    }
                }, [Gr("h2", null, "Available Fields"), Gr("span", null, "Rows / Distinct Values")], -1)
            })),
            Ly = {
                style: {
                    overflow: "auto",
                    height: "calc(100% - 33px)",
                    "padding-right": "8px"
                }
            },
            jy = ["onMouseover"],
            Ny = {
                style: {
                    "font-weight": "normal",
                    "font-size": "15px"
                }
            },
            Hy = ["onClick"],
            Wy = ["onClick"],
            Vy = {
                style: {
                    "font-weight": "bolder",
                    "font-size": "15px"
                }
            },
            qy = {
                style: {
                    "padding-left": "50px"
                }
            },
            Uy = {
                style: {
                    display: "flex",
                    "align-items": "center"
                }
            },
            Ky = ["onMouseover"],
            Gy = {
                key: 1,
                style: {
                    "margin-left": "5px"
                },
                title: "Date Field",
                class: "lui-icon lui-icon--calendar"
            },
            Xy = {
                key: 2,
                style: {
                    "margin-left": "5px"
                },
                title: "Time Field",
                class: "lui-icon lui-icon--clock"
            },
            Yy = ["title"],
            Zy = {
                style: {
                    "margin-left": "auto"
                }
            },
            Jy = {
                style: {
                    "place-content": "center",
                    "align-items": "center",
                    display: "flex",
                    flex: "0.28",
                    "border-left": "1px solid lightslategray",
                    "border-right": "1px solid lightslategray",
                    "margin-left": "10px",
                    "margin-right": "10px"
                }
            },
            Qy = $y((function() {
                return Gr("span", {
                    class: "lui-icon lui-icon--plus"
                }, null, -1)
            })),
            ex = {
                style: {
                    flex: "1 1 0%",
                    display: "flex",
                    "flex-flow": "column"
                }
            },
            tx = $y((function() {
                return Gr("div", {
                    style: {
                        display: "flex",
                        "justify-content": "space-between"
                    }
                }, [Gr("h2", null, "Selected Fields"), Gr("span")], -1)
            })),
            nx = {
                style: {
                    display: "flex",
                    "flex-flow": "column",
                    gap: "8px",
                    overflow: "auto",
                    height: "100%"
                }
            },
            ox = {
                class: "selectedRow"
            },
            rx = {
                class: "name"
            },
            ix = $y((function() {
                return Gr("span", {
                    class: "lui-icon lui-icon--bin"
                }, null, -1)
            })),
            lx = {
                style: {
                    "margin-left": "auto",
                    "margin-right": "10px",
                    "margin-top": "auto",
                    "margin-bottom": "5px",
                    display: "flex",
                    gap: "5px",
                    "font-size": "15px"
                }
            },
            ax = $y((function() {
                return Gr("span", null, " Straight Table ", -1)
            })),
            sx = $y((function() {
                return Gr("span", null, " Hide Table Prefix from field label ", -1)
            })),
            cx = {
                class: "tc_dialogFooter"
            },
            ux = ["disabled"],
            dx = Tn({
                __name: "app",
                setup: function(e) {
                    var t = this,
                        n = _o("emitter"),
                        o = ht({
                            layout: {},
                            inEdit: !1,
                            extensionHtmlElement: null,
                            component: null
                        });
                    n.on("updateExtData", (function(e) {
                        e.ba, e.co, o.component = e.co, e.el && (o.extensionHtmlElement = e.el)
                    })), n.on("updateLayout", (function(e) {
                        o.layout = e
                    }));
                    var r = Ft(!1),
                        i = Ft(""),
                        l = Ft(null),
                        a = Ft("true" === function(e) {
                            for (var t = document.cookie.split(";"), n = 0; n < t.length; n++) {
                                var o = t[n].split("=");
                                if (e == o[0].trim()) return decodeURIComponent(o[1])
                            }
                        }("straightTableMode"));
                    vr(a, (function(e) {
                        ! function(e, t, n) {
                            var o = new Date;
                            o.setTime(o.getTime() + 24 * n * 60 * 60 * 1e3);
                            var r = "expires=" + o.toUTCString();
                            document.cookie = e + "=" + encodeURIComponent(t) + ";" + r + ";path=/"
                        }("straightTableMode", a.value.toString(), 365)
                    }));
                    var s = {
                            common: {
                                primaryColor: "#009845"
                            }
                        },
                        c = ht({
                            active: !1,
                            tables: [],
                            selectedColumns: [],
                            hoverField: void 0,
                            hoverTable: void 0,
                            tableTitle: void 0,
                            hideTablePrefix: !0
                        }),
                        u = ["Dimension", "Measure", "Measure | Sum", "Measure | Count", "Measure | Max", "Measure | Min", "Measure | Avg"].map((function(e) {
                            return {
                                label: e,
                                value: e
                            }
                        }));

                    function d(e) {
                        "Escape" === e.key && (c.active = !1)
                    }

                    function f(e) {
                        return xy(this, void 0, void 0, (function() {
                            var t, n, i, l, s, u, d;
                            return wy(this, (function(f) {
                                switch (f.label) {
                                    case 0:
                                        return r.value = !0, t = e.map((function(e) {
                                            var t = e.name;
                                            (null == t ? void 0 : t.includes(".")) && c.hideTablePrefix && (t = t.split(".").splice(1).join(""));
                                            var n = e.name;
                                            return /^([A-Z]|[a-z])*$/.test(n) || (n = "[".concat(n, "]")), "Dimension" === e.type ? {
                                                qDef: {
                                                    qFieldDefs: [n],
                                                    qFieldLabels: [t]
                                                }
                                            } : "Measure" === e.type ? {
                                                qDef: {
                                                    qDef: "".concat(n),
                                                    qLabel: "".concat(t)
                                                }
                                            } : "Measure | Sum" === e.type ? {
                                                qDef: {
                                                    qDef: "Sum(".concat(n, ")"),
                                                    qLabel: "Sum(".concat(t, ")")
                                                }
                                            } : "Measure | Count" === e.type ? {
                                                qDef: {
                                                    qDef: "Count(".concat(n, ")"),
                                                    qLabel: "Count(".concat(t, ")")
                                                }
                                            } : "Measure | Max" === e.type ? {
                                                qDef: {
                                                    qDef: "Max(".concat(n, ")"),
                                                    qLabel: "Max(".concat(t, ")")
                                                }
                                            } : "Measure | Min" === e.type ? {
                                                qDef: {
                                                    qDef: "Min(".concat(n, ")"),
                                                    qLabel: "Min(".concat(t, ")")
                                                }
                                            } : "Measure | Avg" === e.type ? {
                                                qDef: {
                                                    qDef: "Avg(".concat(n, ")"),
                                                    qLabel: "Avg(".concat(t, ")")
                                                }
                                            } : "Counter" == e.type ? {
                                                qDef: {
                                                    qDef: "=1",
                                                    qLabel: "Counter"
                                                }
                                            } : void 0
                                        })), [4, yy().currApp().model.enigmaModel.getObject(o.layout.qInfo.qId)];
                                    case 1:
                                        return n = f.sent(), [4, yy().currApp().visualization.create(a.value ? "sn-table" : "table", t, {
                                            title: c.tableTitle,
                                            components: [{
                                                key: "theme",
                                                content: {
                                                    hoverEffect: !0
                                                },
                                                scrollbar: {
                                                    size: "medium"
                                                }
                                            }]
                                        })];
                                    case 2:
                                        return [4, (i = f.sent()).model.getProperties()];
                                    case 3:
                                        return (l = f.sent()).qInfo.qId = o.layout.qInfo.qId, [4, n.setProperties(l)];
                                    case 4:
                                        return f.sent(), i.close(), s = yy().navigation.getCurrentSheetId(), [4, yy().currApp().model.enigmaModel.getObject(s.sheetId)];
                                    case 5:
                                        return [4, (u = f.sent()).getProperties()];
                                    case 6:
                                        return (d = f.sent()).cells.forEach((function(e) {
                                            e.name == o.layout.qInfo.qId && (e.type = "table")
                                        })), u.setProperties(d), [2]
                                }
                            }))
                        }))
                    }

                    function p(e) {
                        e.showPreview = !e.showPreview, e.showPreview && function(e) {
                            var t, n;
                            xy(this, void 0, void 0, (function() {
                                var o, r, i, l, a, s, c;
                                return wy(this, (function(u) {
                                    switch (u.label) {
                                        case 0:
                                            u.trys.push([0, 5, 6, 7]), o = Cy(e.qFields), r = o.next(), u.label = 1;
                                        case 1:
                                            return r.done ? [3, 4] : (i = r.value, [4, yy().currApp().model.engineApp.getFieldAndColumnSamples({
                                                qFieldsOrColumnsWithWildcards: [{
                                                    qFieldName: i.qName,
                                                    qTableName: e.qName
                                                }],
                                                qMaxNumberOfValues: 6
                                            })]);
                                        case 2:
                                            l = u.sent(), i.samples = null === (n = null === (t = l[0]) || void 0 === t ? void 0 : t.qValues) || void 0 === n ? void 0 : n.map((function(e) {
                                                return (null == e ? void 0 : e.qText) || (null == e ? void 0 : e.qNum) || (null == e ? void 0 : e.qNumber)
                                            })), u.label = 3;
                                        case 3:
                                            return r = o.next(), [3, 1];
                                        case 4:
                                            return [3, 7];
                                        case 5:
                                            return a = u.sent(), s = {
                                                error: a
                                            }, [3, 7];
                                        case 6:
                                            try {
                                                r && !r.done && (c = o.return) && c.call(o)
                                            } finally {
                                                if (s) throw s.error
                                            }
                                            return [7];
                                        case 7:
                                            return [2]
                                    }
                                }))
                            }))
                        }(e)
                    }
                    return Nn((function() {
                            return xy(t, void 0, void 0, (function() {
                                var e;
                                return wy(this, (function(t) {
                                    switch (t.label) {
                                        case 0:
                                            return e = c, [4, yy().currApp().model.engineApp.getTablesAndKeys({
                                                qSyntheticMode: !1
                                            })];
                                        case 1:
                                            return e.tables = t.sent().qtr.sort((function(e, t) {
                                                return e.qName.localeCompare(t.qName)
                                            })), c.active = !0, r.value = !1, window.addEventListener("keydown", d), [2]
                                    }
                                }))
                            }))
                        })), qn((function() {
                            window.removeEventListener("keydown", d)
                        })), document.onkeydown = function(e) {
                            "f" === e.key && (e.ctrlKey || e.metaKey) && c.active && (e.preventDefault(), l.value.focus())
                        },
                        function(e, t) {
                            return Ir(), Hr("div", _y, [Xr(Et(Tc), {
                                "theme-overrides": s,
                                "preflight-style-disabled": !0
                            }, {
                                default: dn((function() {
                                    return [Xr(Et(uf), {
                                        type: "primary",
                                        onClick: t[0] || (t[0] = function(e) {
                                            c.active = !0, r.value = !1
                                        })
                                    }, {
                                        icon: dn((function() {
                                            return [zy]
                                        })),
                                        default: dn((function() {
                                            return [Qr(" Quick Table ")]
                                        })),
                                        _: 1
                                    }), c.active ? (Ir(), Wr(by, {
                                        key: 0,
                                        to: "body"
                                    }, {
                                        default: dn((function() {
                                            return [Gr("div", Ty, [Gr("div", Py, [Fy, Xr(Et(uf), {
                                                quaternary: "",
                                                circle: "",
                                                onClick: t[1] || (t[1] = function(e) {
                                                    return c.active = !1
                                                })
                                            }, {
                                                icon: dn((function() {
                                                    return [My]
                                                })),
                                                _: 1
                                            })]), Gr("div", {
                                                class: "tc_dialogBody",
                                                onClick: t[10] || (t[10] = Pl((function() {}), ["stop", "prevent"]))
                                            }, [Gr("div", Ry, [Xr(Et(zh), {
                                                placeholder: "Search ...",
                                                clearable: "",
                                                value: i.value,
                                                "onUpdate:value": t[2] || (t[2] = function(e) {
                                                    return i.value = e
                                                }),
                                                ref_key: "searchElement",
                                                ref: l,
                                                style: {
                                                    "max-width": "200px"
                                                }
                                            }, {
                                                prefix: dn((function() {
                                                    return [Ey]
                                                })),
                                                _: 1
                                            }, 8, ["value"]), Xr(Et(uf), {
                                                onClick: t[3] || (t[3] = function(e) {
                                                    return function() {
                                                        var e, t, n, o;
                                                        try {
                                                            for (var r = Cy(c.tables), i = r.next(); !i.done; i = r.next()) {
                                                                var l = i.value;
                                                                try {
                                                                    for (var a = (n = void 0, Cy(l.qFields)), s = a.next(); !s.done; s = a.next()) s.value.selected = !0
                                                                } catch (e) {
                                                                    n = {
                                                                        error: e
                                                                    }
                                                                } finally {
                                                                    try {
                                                                        s && !s.done && (o = a.return) && o.call(a)
                                                                    } finally {
                                                                        if (n) throw n.error
                                                                    }
                                                                }
                                                            }
                                                        } catch (t) {
                                                            e = {
                                                                error: t
                                                            }
                                                        } finally {
                                                            try {
                                                                i && !i.done && (t = r.return) && t.call(r)
                                                            } finally {
                                                                if (e) throw e.error
                                                            }
                                                        }
                                                    }()
                                                })
                                            }, {
                                                default: dn((function() {
                                                    return [Qr("Select All")]
                                                })),
                                                _: 1
                                            }), Xr(Et(uf), {
                                                onClick: t[4] || (t[4] = function(e) {
                                                    return function() {
                                                        var e, t, n, o;
                                                        try {
                                                            for (var r = Cy(c.tables), i = r.next(); !i.done; i = r.next()) {
                                                                var l = i.value;
                                                                try {
                                                                    for (var a = (n = void 0, Cy(l.qFields)), s = a.next(); !s.done; s = a.next()) s.value.selected = !1
                                                                } catch (e) {
                                                                    n = {
                                                                        error: e
                                                                    }
                                                                } finally {
                                                                    try {
                                                                        s && !s.done && (o = a.return) && o.call(a)
                                                                    } finally {
                                                                        if (n) throw n.error
                                                                    }
                                                                }
                                                            }
                                                        } catch (t) {
                                                            e = {
                                                                error: t
                                                            }
                                                        } finally {
                                                            try {
                                                                i && !i.done && (t = r.return) && t.call(r)
                                                            } finally {
                                                                if (e) throw e.error
                                                            }
                                                        }
                                                    }()
                                                })
                                            }, {
                                                default: dn((function() {
                                                    return [Qr("Unselect All")]
                                                })),
                                                _: 1
                                            }), Gr("div", Oy, [Xr(Et(uf), {
                                                disabled: 0 == c.selectedColumns.length || "Counter" == c.selectedColumns[0].type,
                                                type: "info",
                                                title: "Add Counter Column",
                                                onClick: t[5] || (t[5] = function(e) {
                                                    c.selectedColumns = ky([{
                                                        name: "Counter",
                                                        type: "Counter"
                                                    }], Sy(c.selectedColumns), !1)
                                                })
                                            }, {
                                                default: dn((function() {
                                                    return [Qr(" 1 ")]
                                                })),
                                                _: 1
                                            }, 8, ["disabled"]), Xr(Et(uf), {
                                                disabled: 0 == c.selectedColumns.length,
                                                type: "error",
                                                title: "Reset selected fields",
                                                onClick: t[6] || (t[6] = function(e) {
                                                    c.selectedColumns = []
                                                })
                                            }, {
                                                icon: dn((function() {
                                                    return [By]
                                                })),
                                                _: 1
                                            }, 8, ["disabled"])])]), Gr("div", Ay, [Gr("div", Iy, [Dy, Gr("div", Ly, [Xr(Et(Ah), null, {
                                                default: dn((function() {
                                                    return [(Ir(!0), Hr(Mr, null, eo(c.tables, (function(e, n) {
                                                        return Ir(), Wr(Et(Wh), {
                                                            name: n,
                                                            disabled: r.value || 0 == e.qFields.filter((function(e) {
                                                                return e.qName.toLowerCase().includes(i.value.toLowerCase())
                                                            })).length
                                                        }, {
                                                            header: dn((function() {
                                                                return [Gr("div", {
                                                                    style: {
                                                                        width: "100%",
                                                                        height: "100%"
                                                                    },
                                                                    onMouseover: function(t) {
                                                                        return c.hoverTable = e.qName
                                                                    },
                                                                    onMouseleave: t[7] || (t[7] = function(e) {
                                                                        return c.hoverTable = void 0
                                                                    })
                                                                }, [Xr(Et(Zh), {
                                                                    onClick: Pl((function(t) {
                                                                        return function(e) {
                                                                            var t, n, o, r;
                                                                            if (e.qFields.every((function(e) {
                                                                                    return e.selected
                                                                                }))) try {
                                                                                for (var i = Cy(e.qFields), l = i.next(); !l.done; l = i.next()) l.value.selected = !1
                                                                            } catch (e) {
                                                                                t = {
                                                                                    error: e
                                                                                }
                                                                            } finally {
                                                                                try {
                                                                                    l && !l.done && (n = i.return) && n.call(i)
                                                                                } finally {
                                                                                    if (t) throw t.error
                                                                                }
                                                                            } else try {
                                                                                for (var a = Cy(e.qFields), s = a.next(); !s.done; s = a.next()) s.value.selected = !0
                                                                            } catch (e) {
                                                                                o = {
                                                                                    error: e
                                                                                }
                                                                            } finally {
                                                                                try {
                                                                                    s && !s.done && (r = a.return) && r.call(a)
                                                                                } finally {
                                                                                    if (o) throw o.error
                                                                                }
                                                                            }
                                                                        }(e)
                                                                    }), ["prevent", "stop"]),
                                                                    disabled: r.value || 0 == e.qFields.filter((function(e) {
                                                                        return e.qName.toLowerCase().includes(i.value.toLowerCase())
                                                                    })).length,
                                                                    checked: e.qFields.every((function(e) {
                                                                        return e.selected || !e.qName.toLowerCase().includes(i.value.toLowerCase())
                                                                    })) && e.qFields.filter((function(e) {
                                                                        return e.selected
                                                                    })).length > 0,
                                                                    indeterminate: e.qFields.some((function(e) {
                                                                        return e.selected && e.qName.toLowerCase().includes(i.value.toLowerCase())
                                                                    })) && !e.qFields.every((function(e) {
                                                                        return e.selected || !e.qName.toLowerCase().includes(i.value.toLowerCase())
                                                                    })),
                                                                    size: "medium"
                                                                }, null, 8, ["onClick", "disabled", "checked", "indeterminate"]), Gr("span", {
                                                                    class: Q({
                                                                        textGlow: e.qFields.some((function(e) {
                                                                            return e.qName == c.hoverField
                                                                        })),
                                                                        disabled: 0 == e.qFields.filter((function(e) {
                                                                            return e.qName.toLowerCase().includes(i.value.toLowerCase())
                                                                        })).length
                                                                    }),
                                                                    style: {
                                                                        "padding-left": "5px",
                                                                        "font-weight": "bold",
                                                                        "font-size": "16px"
                                                                    }
                                                                }, [Gr("span", null, re(e.qName + " "), 1), Gr("span", Ny, "(" + re((i.value ? e.qFields.filter((function(e) {
                                                                    return e.qName.toLowerCase().includes(i.value.toLowerCase())
                                                                })).length.toString() + "/" : "") + e.qFields.length) + ")", 1)], 2), e.qName == c.hoverTable || e.showPreview ? (Ir(), Hr("span", {
                                                                    key: 0,
                                                                    class: "lui-icon lui-icon--view tableIcon",
                                                                    title: "Preview random values",
                                                                    onClick: Pl((function(t) {
                                                                        return p(e)
                                                                    }), ["stop"])
                                                                }, null, 8, Hy)) : ei("v-if", !0), e.qName != c.hoverTable || i.value ? ei("v-if", !0) : (Ir(), Hr("span", {
                                                                    key: 1,
                                                                    title: "Create Table",
                                                                    class: "lui-icon lui-icon--table tableIcon",
                                                                    onClick: Pl((function(t) {
                                                                        r.value = !0,
                                                                            function(e) {
                                                                                xy(this, void 0, void 0, (function() {
                                                                                    var t;
                                                                                    return wy(this, (function(n) {
                                                                                        return c.tableTitle = e.qName, t = e.qFields.map((function(e) {
                                                                                            return e.qName
                                                                                        })), f(ky([], Sy(new Set(t)), !1).map((function(e) {
                                                                                            return {
                                                                                                name: e,
                                                                                                type: "Dimension"
                                                                                            }
                                                                                        }))), [2]
                                                                                    }))
                                                                                }))
                                                                            }(e)
                                                                    }), ["stop"])
                                                                }, null, 8, Wy))], 40, jy)]
                                                            })),
                                                            "header-extra": dn((function() {
                                                                return [Gr("span", Vy, re(Number(e.qNoOfRows).toLocaleString()), 1)]
                                                            })),
                                                            default: dn((function() {
                                                                return [Gr("div", qy, [(Ir(!0), Hr(Mr, null, eo(e.qFields.filter((function(e) {
                                                                    return e.qName.toLowerCase().includes(i.value.toLowerCase())
                                                                })), (function(n) {
                                                                    var o;
                                                                    return Ir(), Hr("div", Uy, [Xr(Et(Zh), {
                                                                        disabled: r.value,
                                                                        "theme-overrides": {
                                                                            textColor: n.qName == c.hoverField ? "#009844" : void 0
                                                                        },
                                                                        size: "small",
                                                                        checked: n.selected,
                                                                        "onUpdate:checked": function(e) {
                                                                            return n.selected = e
                                                                        },
                                                                        label: n.qName
                                                                    }, null, 8, ["disabled", "theme-overrides", "checked", "onUpdate:checked", "label"]), ["$key", "$keypart", "$syn", "$synthetic"].some((function(e) {
                                                                        return n.qTags.includes(e)
                                                                    })) || "ANY_KEY" == n.qKeyType ? (Ir(), Hr("span", {
                                                                        key: 0,
                                                                        style: G([{
                                                                            color: n.qName == c.hoverField ? "#009844" : "unset"
                                                                        }, {
                                                                            "margin-left": "10px"
                                                                        }]),
                                                                        title: "Key Field",
                                                                        onMouseover: function(e) {
                                                                            return c.hoverField = n.qName
                                                                        },
                                                                        onMouseleave: t[8] || (t[8] = function(e) {
                                                                            return c.hoverField = void 0
                                                                        }),
                                                                        class: "lui-icon lui-icon--key"
                                                                    }, null, 44, Ky)) : ei("v-if", !0), n.qTags.includes("$date") ? (Ir(), Hr("span", Gy)) : ei("v-if", !0), n.qTags.includes("$timestamp") ? (Ir(), Hr("span", Xy)) : ei("v-if", !0), e.showPreview && (null === (o = n.samples) || void 0 === o ? void 0 : o.length) ? (Ir(), Hr("div", {
                                                                        key: 3,
                                                                        style: {
                                                                            "margin-left": "10px",
                                                                            overflow: "hidden",
                                                                            flex: "1",
                                                                            "text-overflow": "ellipsis",
                                                                            "white-space": "nowrap",
                                                                            "margin-right": "10px"
                                                                        },
                                                                        title: n.samples.join("\n") + (n.samples.length < n.qnTotalDistinctValues ? "\n..." : "")
                                                                    }, " (" + re(n.samples.join(", ") + (n.samples.length < n.qnTotalDistinctValues ? ", ..." : "")) + ") ", 9, Yy)) : ei("v-if", !0), Gr("span", Zy, re(Number(n.qnTotalDistinctValues).toLocaleString()), 1)])
                                                                })), 256))])]
                                                            })),
                                                            _: 2
                                                        }, 1032, ["name", "disabled"])
                                                    })), 256))]
                                                })),
                                                _: 1
                                            })])]), Gr("div", Jy, [Xr(Et(uf), {
                                                type: "info",
                                                disabled: !c.tables.some((function(e) {
                                                    return e.qFields.some((function(e) {
                                                        return e.selected
                                                    }))
                                                })) || r.value,
                                                "icon-placement": "right",
                                                onClick: t[9] || (t[9] = function(e) {
                                                    return function() {
                                                        var e, t, n, o, r = [];
                                                        try {
                                                            for (var i = Cy(c.tables), l = i.next(); !l.done; l = i.next()) {
                                                                var a = l.value;
                                                                try {
                                                                    for (var s = (n = void 0, Cy(a.qFields)), u = s.next(); !u.done; u = s.next()) {
                                                                        var d = u.value;
                                                                        d.selected && (r.push(d.qName), d.selected = !1)
                                                                    }
                                                                } catch (e) {
                                                                    n = {
                                                                        error: e
                                                                    }
                                                                } finally {
                                                                    try {
                                                                        u && !u.done && (o = s.return) && o.call(s)
                                                                    } finally {
                                                                        if (n) throw n.error
                                                                    }
                                                                }
                                                            }
                                                        } catch (t) {
                                                            e = {
                                                                error: t
                                                            }
                                                        } finally {
                                                            try {
                                                                l && !l.done && (t = i.return) && t.call(i)
                                                            } finally {
                                                                if (e) throw e.error
                                                            }
                                                        }
                                                        c.selectedColumns = c.selectedColumns.concat(ky([], Sy(new Set(r)), !1).map((function(e) {
                                                            return {
                                                                name: e,
                                                                type: "Dimension"
                                                            }
                                                        })))
                                                    }()
                                                })
                                            }, {
                                                icon: dn((function() {
                                                    return [Qy]
                                                })),
                                                _: 1
                                            }, 8, ["disabled"])]), Gr("div", ex, [tx, Gr("div", nx, [(Ir(!0), Hr(Mr, null, eo(c.selectedColumns, (function(e, t) {
                                                return Ir(), Hr("div", ox, [Gr("span", rx, re(e.name), 1), Xr(Et(uy), {
                                                    class: "type",
                                                    disabled: "Counter" == e.type,
                                                    value: e.type,
                                                    "onUpdate:value": function(t) {
                                                        return e.type = t
                                                    },
                                                    options: Et(u),
                                                    size: "small",
                                                    filterable: ""
                                                }, null, 8, ["disabled", "value", "onUpdate:value", "options"]), Xr(Et(uf), {
                                                    quaternary: "",
                                                    circle: "",
                                                    type: "error",
                                                    style: {
                                                        "margin-left": "5px"
                                                    },
                                                    disabled: r.value,
                                                    onClick: function(e) {
                                                        return c.selectedColumns.splice(t, 1)
                                                    }
                                                }, {
                                                    icon: dn((function() {
                                                        return [ix]
                                                    })),
                                                    _: 2
                                                }, 1032, ["disabled", "onClick"])])
                                            })), 256))])])])]), Gr("div", lx, [Xr(Et(vy), {
                                                value: a.value,
                                                "onUpdate:value": t[11] || (t[11] = function(e) {
                                                    return a.value = e
                                                }),
                                                round: !1,
                                                size: "small"
                                            }, null, 8, ["value"]), ax, Xr(Et(vy), {
                                                value: c.hideTablePrefix,
                                                "onUpdate:value": t[12] || (t[12] = function(e) {
                                                    return c.hideTablePrefix = e
                                                }),
                                                round: !1,
                                                size: "small",
                                                style: {
                                                    "margin-left": "5px"
                                                }
                                            }, null, 8, ["value"]), sx]), Gr("div", cx, [Gr("button", {
                                                class: "qlikButton defaultQlikButton",
                                                onClick: t[13] || (t[13] = function(e) {
                                                    return c.active = !1
                                                }),
                                                disabled: r.value
                                            }, "Close", 8, ux), Xr(Et(uf), {
                                                type: "primary",
                                                loading: r.value,
                                                disabled: 0 == c.selectedColumns.length,
                                                onClick: t[14] || (t[14] = function(e) {
                                                    return f(c.selectedColumns)
                                                })
                                            }, {
                                                default: dn((function() {
                                                    return [Qr(" Create ")]
                                                })),
                                                _: 1
                                            }, 8, ["loading", "disabled"])])]), Gr("div", {
                                                onClick: t[15] || (t[15] = Pl((function() {}), ["stop", "prevent"])),
                                                class: "qt-dialog-bg",
                                                onKeyup: t[16] || (t[16] = Ml(Pl((function(e) {
                                                    c.active = !1
                                                }), ["stop", "prevent"]), ["esc"]))
                                            }, null, 32)]
                                        })),
                                        _: 1
                                    })) : ei("v-if", !0)]
                                })),
                                _: 1
                            })])
                        }
                }
            });
        var fx = (0, r(479).A)(dx, [
            ["__scopeId", "data-v-638b8b50"]
        ]);
        var px = a().toUrl(".") + "/My QuickTable.css";
        a()(["css!" + px]);
        var hx = {
            definition: s,
            initialProperties: {
                version: 1,
                showTitles: !1,
                disableNavMenu: !0
            },
            paint: function(e, t) {
                var n;
                this.vueState || (this.vueState = {}), e[0].getElementsByClassName("tc_extension")[0] || (this.vueState.initialized = !1), this.vueState.initialized || (this.vueState.initialized = !0, this.backendApi.setCacheOptions({
                    enabled: !1
                }), this.vueState.emitter = {
                    all: n = n || new Map,
                    on: function(e, t) {
                        var o = n.get(e);
                        o ? o.push(t) : n.set(e, [t])
                    },
                    off: function(e, t) {
                        var o = n.get(e);
                        o && (t ? o.splice(o.indexOf(t) >>> 0, 1) : n.set(e, []))
                    },
                    emit: function(e, t) {
                        var o = n.get(e);
                        o && o.slice().map((function(e) {
                            e(t)
                        })), (o = n.get("*")) && o.slice().map((function(n) {
                            n(e, t)
                        }))
                    }
                }, this.vueState.app = ((...e) => {
                    const t = Ol().createApp(...e),
                        {
                            mount: n
                        } = t;
                    return t.mount = e => {
                        const o = Al(e);
                        if (!o) return;
                        const r = t._component;
                        S(r) || r.render || r.template || (r.template = o.innerHTML), o.innerHTML = "";
                        const i = n(o, !1, Bl(o));
                        return o instanceof Element && (o.removeAttribute("v-cloak"), o.setAttribute("data-v-app", "")), i
                    }, t
                })(fx, {
                    layout: t
                }), this.vueState.app.provide("emitter", this.vueState.emitter), this.vueState.app.mount(e[0]), this.vueState.emitter.emit("updateExtData", {
                    ba: this.backendApi,
                    co: this.$scope.component,
                    el: e[0]
                }), this.vueState.emitter.emit("updateLayout", JSON.parse(JSON.stringify(t))))
            },
            beforeDestroy: function() {
                this.vueState.app.unmount()
            }
        };
        return i
    }()
}));